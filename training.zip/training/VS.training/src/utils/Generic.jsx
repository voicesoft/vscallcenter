export const userDetails = (propName = null) => {
  let UserInfo = localStorage.getItem("UserData");
  UserInfo = UserInfo ? JSON.parse(UserInfo) : null;
  if (!UserInfo) return null;
  return propName ? UserInfo[propName] : UserInfo;
};

export const agentExtension = (propName = null) => {
  let agentext = localStorage.getItem("Agentextension");
  if (!agentext) return null;
  return agentext;
};
