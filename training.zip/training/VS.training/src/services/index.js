import axios from "axios";
const serviceBase = axios.create({
  baseURL: "https://ap.voicehuddle.com/callcenter/api/",
  headers: {
    "content-type": "application/json",
  },
});
export default serviceBase;
