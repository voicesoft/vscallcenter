export const VALIDATE_LOGIN = {
  LOGIN: "VSR/ValidateagentLogin",
};

export const DASHBOARD = {
  REQUESTSTARTSTOP: "callstatus/starttraining",
};
