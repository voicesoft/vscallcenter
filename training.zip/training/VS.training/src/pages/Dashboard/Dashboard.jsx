import React from "react";
import "../common.css";
import { useState } from "react";
import AppTopBar from "../Layouts/AppTopBar";

const Dashboard = () => {
  const [tostify, setTostify] = useState("");
  const handleAlert = (row) => {
    setTostify(row);
  };
  return (
    <div>
      <AppTopBar setAlert={handleAlert} />
      {tostify === "Y"
        ? [
            <div>
              <p className="text-status">Started successfully...</p>
            </div>,
          ]
        : tostify === "N"
        ? [
            <div>
              <p className="text-status">Stoped successfully...</p>
            </div>,
          ]
        : [""]}
    </div>
  );
};

export default Dashboard;
