import React from "react";
import "../common.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import istudiologo from "../../assets/vslogo.png";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import { userDetails, agentExtension } from "../../utils/Generic";
import { Overlay, Popover } from "react-bootstrap";
import { stringAvatar } from "../../components/avatar";
import apiconfig from "../../services/index";
import { DASHBOARD } from "../../services/apimethods";
import { ToastContainer, toast } from "react-toastify";

const AppTopBar = ({ setAlert }) => {
  const menuId = "primary-search-account-menu";
  let navigate = useNavigate();
  const [show, setShow] = useState(false);
  const [target, setTarget] = useState(null);

  const onSubmit = (prop) => {
    let param = {
      agentid: userDetails("agentid"),
      extension: agentExtension("agentextension"),
      action: prop,
    };
    apiconfig
      .post(DASHBOARD.REQUESTSTARTSTOP, param)
      .then((response) => {
        if (response.data.data.status === 1 && prop === "start") {
          toast.success("Started successfully!", {
            autoClose: 1000,
          });
          setAlert("Y");
        } else if (response.data.data.status === 1 && prop === "stop") {
          toast.success("Stoped successfully!", {
            autoClose: 1000,
          });
          setAlert("N");
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // PROFILE MENU
  const handleProfileMenuOpen = (event) => {
    setShow(!show);
    setTarget(event.target);
  };

  const signouthandler = () => {
    navigate("/");
  };

  return (
    <div>
      <div className="dashboard-header">
        <img
          alt="logo"
          src={istudiologo}
          style={{ marginLeft: "20px", height: "50px" }}
        />
        <Button
          variant="contained"
          color="success"
          onClick={() => {
            onSubmit("start");
          }}
        >
          Start
        </Button>
        <Button
          variant="contained"
          color="error"
          onClick={() => {
            onSubmit("stop");
          }}
        >
          Stop
        </Button>
        {/* <div className="col-md-4"> */}
        <IconButton
          sx={{ float: "right", p: 2 }}
          size="large"
          aria-label="account of current user"
          aria-controls={menuId}
          aria-haspopup="true"
          color="white"
          onClick={handleProfileMenuOpen}
        >
          <Avatar
            className="profile-img"
            {...stringAvatar(userDetails("username"))}
          ></Avatar>
        </IconButton>
        {/* </div> */}
      </div>
      <Overlay
        show={show}
        target={target}
        placement="bottom"
        containerPadding={10}
        rootClose
        onHide={() => setShow(false)}
      >
        <Popover className="profile-menu" id="popover-contained">
          <Popover.Body>
            <h5>{userDetails("username")}</h5>
            <p className="email_name">{userDetails("usermobile")}</p>
            {/* &nbsp; */}
            <Button
              variant="outlined"
              color="error"
              style={{
                fontSize: "15px",
                textTransform: "none",
              }}
              onClick={signouthandler}
            >
              Sign out
            </Button>
          </Popover.Body>
        </Popover>
      </Overlay>
      <ToastContainer theme="colored" position="bottom-center" />
    </div>
  );
};

export default AppTopBar;
