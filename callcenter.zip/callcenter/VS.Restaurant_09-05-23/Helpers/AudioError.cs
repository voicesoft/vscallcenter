﻿namespace VS.Restaurant.Helpers
{
    public enum AudioError
    {
        UserMobileCannotBeEmptyOrNull = 1001,
        UserPasswordCannotBeEmptyOrNull = 1002,
        UserRoleCannotBeEmptyOrNull = 1003,
        AudioFileCannotBeEmptyOrNull = 1005,
        AudioTitleCannotBeEmptyOrNull = 1006,
        AudioTextCannotBeEmptyOrNull = 1007,
        UseridCannotBeEmptyOrNull = 1008,
        FileidCannotBeEmptyOrNull = 1009,
        ReplyCannotBeEmptyOrNull = 1010,
        Info = 1,
        Warning = 2
    }
}
