﻿namespace VS.Restaurant.Helpers
{
    public enum Severity
    {
        Error = -1,
        Warning = 0,
        Info = 1,
        Success = 2,
    }
}
