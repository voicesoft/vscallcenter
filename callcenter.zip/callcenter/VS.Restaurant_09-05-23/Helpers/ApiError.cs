﻿namespace VS.Restaurant.Helpers
{
    public class ApiError
    {
        public enum Pizzacornererror
        {
            error = -1,
            warning = 0,
            info = 1,
            success = 2,
            resturantidcannotbenull = 1001,
            basenamecannotbenull = 1002,
            basecodecannotbenull = 1003,
            createdbycannotbenull = 1004,
            operationtypecannotbenull = 1005,
            baseidcannotbenull = 1006,
            customeritemcodecannotbenull = 1007,
            topingnamecannotbenull = 1008,
            fullpricecannotbenull = 1009,
            halfpricecannotbenull = 1010,
            topingidcannotbenull = 1011,
            itemdatacannotbenull = 1012,
            filenamecannotbenull = 1013,
            itemcodecannotbenull = 1014,
            itemtypecannotbenull = 1015
        }
        public string? ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }
        public Severity Severity { get; set; }
    }
}
