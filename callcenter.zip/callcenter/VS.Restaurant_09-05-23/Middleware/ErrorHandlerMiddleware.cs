﻿using System.Dynamic;
using System.Net;
using System.Reflection;
using System.Text.Json;
using VS.Restaurant.Helpers;
using VS.Restaurant.Modal;
using System.Resources;

namespace VS.Restaurant.Middleware
{
    public class ErrorHandlerMiddleware
    {
        private readonly RequestDelegate _next;


        public ErrorHandlerMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception error)
            {
                var response = context.Response;
                response.ContentType = "application/json";
                string result = string.Empty;
                dynamic expando = new ExpandoObject();
                GenericResponse _GResponse = new();
                ResourceManager rm = new ResourceManager("VS.Restaurant.Resources.ErrorResource", Assembly.GetExecutingAssembly());

                // Retrieve the value of the string resource named "welcome".
                // The resource manager will retrieve the value of the  
                // localized resource using the caller's current culture setting.
                //String str = rm.GetString("welcome");

                switch (error)
                {
                    case AppException e:
                        // custom application error
                        var exception = (AppException)error;
                        var apiError = new ApiError
                        {
                            ErrorCode = exception.ErrorCode.ToString(),
                            ErrorMessage = rm.GetString(exception.ErrorMessage),
                            Severity = Severity.Error
                        };
                        expando.Status = -2;
                        expando.Error = apiError;
                        _GResponse.Data = expando;
                        response.StatusCode = (int)HttpStatusCode.Created;
                        result = JsonSerializer.Serialize(_GResponse);
                        break;
                    default:
                        // unhandled error
                        var exceptionmsg = (AppException)error;
                        var genericError = new ApiError
                        {
                            ErrorCode = "-5000",
                            ErrorMessage = "new connection exception",
                            Severity = Severity.Error
                        };
                        expando.Status = -2;
                        expando.Error = genericError;
                        _GResponse.Data = expando;
                        response.StatusCode = (int)HttpStatusCode.Created;
                        result = JsonSerializer.Serialize(_GResponse);
                        break;
                }
                await response.WriteAsync(result);
            }
        }

    }
}
