﻿using Microsoft.AspNetCore.Mvc;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Controllers
{
    [ApiController]
    public class VSRAdminWebAPI : ControllerBase
    {
        private readonly VSRAdminProviderInterface vSRAdminProviderInterface;
        private readonly IAgentInterface agentInterface;
        public VSRAdminWebAPI(VSRAdminProviderInterface _vSRAdminProviderInterface, IAgentInterface _agentInterface)
        {
            vSRAdminProviderInterface = _vSRAdminProviderInterface;
            agentInterface = _agentInterface;
        }
        [HttpPost, Route("api/VSRAdmin/AddCompany")]
        public ActionResult AddCompany(Customer customer)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.AddCompany(customer);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRAdmin/AddCustomerinfo")]
        public ActionResult Customerinfo(Addcustomerinfo addcustomerinfo)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.Customerinfo(addcustomerinfo);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRadmin/LoadCompany")]
        public ActionResult LoadCompany(LoadcompanyInput loadcompanyInput)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.LoadCompany(loadcompanyInput);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/VSRadmin/LoadAgents")]
        public ActionResult GetAllAgents(LoadagentsIP loadagentsIP)
        {            
            GenericResponse genericResponse = agentInterface.GetAllAgents(loadagentsIP.userid);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRAdmin/AddAgent")]
        public ActionResult CreateAgent(CreateAgents agent)
        {
            GenericResponse genericResponse = agentInterface.AddAgent(agent);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRAdmin/Welcomeaudio")]
        public ActionResult Welcomeaudio([FromForm] ReqWelcomeAudio reqwelcomeaudio)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.Welcomeaudio(reqwelcomeaudio);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRAdmin/Loadwelcomeaudio")]
        public ActionResult Loadwelcomeaudio(LoadwelcomeAudio loadwelcomeAudio)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.Loadwelcomeaudio(loadwelcomeAudio);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRAdmin/Deletewelcomeaudio")]
        public ActionResult Deletewelcomeaudio(DeletewelcomeAudio deletewelcomeAudio)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.Deletewelcomeaudio(deletewelcomeAudio);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSRAdmin/updateagentavailability")]
        public ActionResult UpdateagentAvailability(string extension)
        {
            GenericResponse genericResponse = vSRAdminProviderInterface.UpdateagentAvailability(extension);
            return Ok(genericResponse);
        }
    }
}
