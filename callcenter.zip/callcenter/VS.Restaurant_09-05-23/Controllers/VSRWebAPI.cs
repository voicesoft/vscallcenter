﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Controllers
{
    [ApiController]
    public class VSRWebAPI : ControllerBase
    {
        private readonly VSRProviderInterface vSRProviderInterface;
        public VSRWebAPI(VSRProviderInterface _vSRProviderInterface)
        {
            vSRProviderInterface = _vSRProviderInterface;
        }

        [HttpPost, Route("api/VSR/ValidateLogin")]
        public ActionResult ValidateLogin(LoginValues loginvalues)
        {
            GenericResponse genericResponse = vSRProviderInterface.ValidateLogin(loginvalues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/ValidateagentLogin")]
        public ActionResult ValidateagentLogin(Agentloign agentloign)
        {
            GenericResponse genericResponse = vSRProviderInterface.ValidateagentLogin(agentloign);
            return Ok(genericResponse);
        }
        #region Itemtype
        [HttpPost, Route("api/VSR/Additemtype")]
        public ActionResult AddItemtype(AdditemValues additemValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.AddItemtype(additemValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Loaditemtype")]
        public ActionResult Loaditemtype(LoaditemValues loaditemValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.LoadItemtype(loaditemValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Edititemtype")]
        public ActionResult Edititemtype(EdititemValues edititemValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.EditItemtype(edititemValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Deleteitemtype")]
        public ActionResult Deleteitemtype(DeleteitemValues deleteitemValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.DeleteItemtype(deleteitemValues);
            return Ok(genericResponse);
        }
        #endregion
        #region Itemsize
        [HttpPost, Route("api/VSR/Additemsize")]
        public ActionResult AddItemsize(AddsizeValues addsizeValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.AddItemsize(addsizeValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Loaditemsize")]
        public ActionResult Loaditemsize(LoadsizeValues loadsizeValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.LoadItemsize(loadsizeValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Edititemsize")]
        public ActionResult Edititemsize(EditsizeValues editsizeValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.EditItemsize(editsizeValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Deleteitemsize")]
        public ActionResult Deleteitemsize(DeletesizeValues deletesizeValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.DeleteItemsize(deletesizeValues);
            return Ok(genericResponse);
        }
        #endregion
        #region Itemmaster
        //[HttpPost, Route("api/VSR/Additemmaster")]
        //public ActionResult AddItemmaster(AddmasterValues addmasterValues)
        //{
        //    GenericResponse genericResponse = vSRProviderInterface.AddItemmaster(addmasterValues);
        //    return Ok(genericResponse);
        //}
        [HttpPost, DisableRequestSizeLimit, Route("api/VSR/Additemmaster")]
        public ActionResult AddItemmaster([FromForm] Addmasterfromdata addmasterfromdata)
        {
            GenericResponse genericResponse = vSRProviderInterface.AddItemmaster(addmasterfromdata); ;
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Loaditemmaster")]
        public ActionResult Loaditemmaster(LoadmasterValues loadmasterValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.LoadItemmaster(loadmasterValues);
            return Ok(genericResponse);
        }
        //[HttpPost, Route("api/VSR/Edititemmaster")]
        //public ActionResult Edititemmaster(EditmasterValues editmasterValues)
        //{
        //    GenericResponse genericResponse = vSRProviderInterface.EditItemmaster(editmasterValues);
        //    return Ok(genericResponse);
        //}
        [HttpPost, DisableRequestSizeLimit, Route("api/VSR/Edititemmaster")]
        public ActionResult Edititemmaster([FromForm] Addmasterfromdata addmasterfromdata)
        {
            GenericResponse genericResponse = vSRProviderInterface.EditItemmaster(addmasterfromdata); ;
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Deleteitemmaster")]
        public ActionResult Deleteitemmaster(DeletemasterValues deletemasterValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.DeleteItemmaster(deletemasterValues);
            return Ok(genericResponse);
        }
        #endregion
        #region Itemprice
        [HttpPost, Route("api/VSR/Additemprice")]
        public ActionResult AddItemprice(AddpriceValues addpriceValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.AddItemprice(addpriceValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Loaditemprice")]
        public ActionResult Loaditemprice(LoadpriceValues loadpriceValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.LoadItemprice(loadpriceValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Edititemprice")]
        public ActionResult Edititemprice(EditpriceValues editpriceValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.EditItemprice(editpriceValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Deleteitemprice")]
        public ActionResult Deleteitemprice(DeletepriceValues deletepriceValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.DeleteItemprice(deletepriceValues);
            return Ok(genericResponse);
        }
        #endregion
        #region Itempackage
        [HttpPost, Route("api/VSR/AddItempackage")]
        public ActionResult AddItempackageformdata([FromForm] Addmasterfromdata addmasterfromdata)
        {
            GenericResponse genericResponse = vSRProviderInterface.AddItempackage(addmasterfromdata);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/VSR/Loaditempackage")]
        public ActionResult Loaditempackage(LoadpackageValues loadpackageValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.LoadItempackage(loadpackageValues);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Edititempackage")]
        public ActionResult Edititempackage([FromForm] Addmasterfromdata addmasterfromdata)
        {//EditpackageValues editpackageValues
            GenericResponse genericResponse = vSRProviderInterface.EditItempackage(addmasterfromdata);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/VSR/Deleteitempackage")]
        public ActionResult Deleteitempackage(DeletepackageValues deletepackageValues)
        {
            GenericResponse genericResponse = vSRProviderInterface.DeleteItempackage(deletepackageValues);
            return Ok(genericResponse);
        }
        #endregion
    }
}
