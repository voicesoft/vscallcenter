﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
namespace VS.Restaurant.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Pizzacorner : ControllerBase
    {
        public readonly IPizzacornerProvider ipizzacornerProvider;
        public Pizzacorner(IPizzacornerProvider _ipizzacornerProvider)
        {
            ipizzacornerProvider = _ipizzacornerProvider;
        }
        #region Itembase
        [HttpGet, Route("[action]")]
        public IActionResult Loadpizzabase(int restraurantid)
        {

            GenericResponse genericResponse = ipizzacornerProvider.Loadpizzabase(restraurantid);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        [HttpPost, Route("[action]")]
        public IActionResult Addpizzabase(OperatemasterbaseReq operatemasterbaseReq)
        {
            GenericResponse genericResponse = ipizzacornerProvider.Addpizzabase(operatemasterbaseReq);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        [HttpPut, Route("[action]")]
        public IActionResult Updatepizzabase(OperatemasterbaseReq operatemasterbaseReq)
        {
            GenericResponse genericResponse = ipizzacornerProvider.Updatepizzabase(operatemasterbaseReq);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        [HttpDelete, Route("[action]")]
        public IActionResult Deletepizzabase(int restraurantid, int userid, Int64 baseid)
        {
            DeletemasterbaseReq operatemasterbaseReq = new DeletemasterbaseReq();
            operatemasterbaseReq.Restaurantid = restraurantid;
            operatemasterbaseReq.Baseid = baseid;
            operatemasterbaseReq.Createdby = userid;
            GenericResponse genericResponse = ipizzacornerProvider.Deletepizzabase(operatemasterbaseReq);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        #endregion
        #region Toppings
        [HttpGet, Route("[action]")]
        public IActionResult Loadpizzatoppings(int restraurantid, int userid)
        {
            GenericResponse genericResponse = ipizzacornerProvider.LoadpizzaToppings(restraurantid, userid);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        [HttpPost, Route("[action]")]
        public IActionResult Addpizzatoppings(AddmasttertopingsReq addmasttertopingsReq)
        {
            GenericResponse genericResponse = ipizzacornerProvider.AddpizzaToppings(addmasttertopingsReq);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        [HttpPut, Route("[action]")]
        public IActionResult Updatepizzatoppings(UpdatemasttertopingsReq updatemasttertopings)
        {
            GenericResponse genericResponse = ipizzacornerProvider.UpdatepizzaToppings(updatemasttertopings);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        [HttpDelete, Route("[action]")]
        public IActionResult Deletepizzatoppings(int restraurantid, int userid, Int64 topingid)
        {
            GenericResponse genericResponse = ipizzacornerProvider.DeletepizzaToppings(restraurantid, userid, topingid);
            if (genericResponse == null)
                return NotFound();
            else
                return Ok(JsonConvert.SerializeObject(genericResponse, Formatting.Indented));
        }
        #endregion
        #region Itemmaster
        [HttpPost, Route("[action]")]
        public ActionResult AddItemmaster([FromForm] Addmasterpizzafromdata addmasterfromdata)
        {
            GenericResponse genericResponse = ipizzacornerProvider.AddItemmaster(addmasterfromdata); ;
            return Ok(genericResponse);
        }
        [HttpPost, Route("[action]")]
        public ActionResult Loaditemmaster(LoadmasterpizzaValues loadmasterValues)
        {
            GenericResponse genericResponse = ipizzacornerProvider.LoadItemmaster(loadmasterValues);
            return Ok(genericResponse);
        }

        [HttpPut, Route("[action]")]
        public ActionResult Edititemmaster([FromForm] Addmasterpizzafromdata addmasterfromdata)
        {
            GenericResponse genericResponse = ipizzacornerProvider.EditItemmaster(addmasterfromdata); ;
            return Ok(genericResponse);
        }
        [HttpDelete, Route("[action]")]
        public ActionResult Deleteitemmaster(Int32 Customerid, Int64 itemcode, string? Reason, Int32 Userid)
        {
            DeletemasterpizzaValues deletemasterValues = new();
            deletemasterValues.Customerid = Customerid;
            deletemasterValues.Itemcode = itemcode;
            deletemasterValues.Reason = Reason;
            deletemasterValues.Userid = Userid;
            GenericResponse genericResponse = ipizzacornerProvider.DeleteItemmaster(deletemasterValues);
            return Ok(genericResponse);
        }
        #endregion
        #region Itempackage
        [HttpPost, Route("[action]")]
        public ActionResult AddItempackageformdata([FromForm] Addmasterpizzafromdata addmasterfromdata)
        {
            GenericResponse genericResponse = ipizzacornerProvider.AddItempackagepizza(addmasterfromdata);
            return Ok(genericResponse);
        }

        [HttpPost, Route("[action]")]
        public ActionResult Loaditempackage(LoadpackagepizzaValues loadpackageValues)
        {
            GenericResponse genericResponse = ipizzacornerProvider.LoadItempackagepizza(loadpackageValues);
            return Ok(genericResponse);
        }
        [HttpPut, Route("[action]")]
        public ActionResult Edititempackage([FromForm] Addmasterpizzafromdata addmasterfromdata)
        {
            GenericResponse genericResponse = ipizzacornerProvider.EditItempackagepizza(addmasterfromdata);
            return Ok(genericResponse);
        }
        [HttpDelete, Route("[action]")]
        public ActionResult Deleteitempackage(Int32 Customerid, Int64 Masteritemid, string? Reason, Int32 Userid)
        {
            DeletepackagepizzaValues deletepackageValues = new DeletepackagepizzaValues();
            deletepackageValues.Customerid = Customerid;
            deletepackageValues.Masteritemid = Masteritemid;
            deletepackageValues.Reason = Reason;
            deletepackageValues.Userid = Userid;
            GenericResponse genericResponse = ipizzacornerProvider.DeleteItempackagepizza(deletepackageValues);
            return Ok(genericResponse);
        }
        #endregion
        #region Loaditemdata
        [HttpGet, Route("[action]")]
        public ActionResult Loaditeminfo(Int64 itemcode)
        {
            GenericResponse genericResponse = ipizzacornerProvider.Loaditeminfo(itemcode);
            return Ok(genericResponse);
        }
        #endregion
        #region Itemtypeddl
        [HttpGet, Route("[action]")]
        public IActionResult Loaditemtypeddl(Int64 restaurantid) {
            GenericResponse genericResponse = ipizzacornerProvider.Loaditemtypeddl(restaurantid);
            return Ok(genericResponse);
        }
        [HttpGet, Route("[action]")]
        public IActionResult Loaditemnameddl(Int64 restaurantid, Int64 itemtype)
        {
            GenericResponse genericResponse = ipizzacornerProvider.Loaditemnameddl(restaurantid, itemtype);
            return Ok(genericResponse);
        }
        #endregion
    }
}
