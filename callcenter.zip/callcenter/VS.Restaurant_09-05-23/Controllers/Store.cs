﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class Store : ControllerBase
    {
        private readonly IStoreSettings storeSettings;
        public Store(IStoreSettings _storeSettings)
        {
            storeSettings = _storeSettings;
        }

        [HttpPost, Route("api/store/additempromotion")]
        public ActionResult AddItemPromotion(ReqItemPromotion reqItemPromotion)
        {
            GenericResponse genericResponse = storeSettings.AddItemPromotion(reqItemPromotion);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/removeitempromotion")]
        public ActionResult RemoveItemPromotion(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = storeSettings.RemoveItemPromotion(reqRemoveItem);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/getitempromotion")]
        public ActionResult GetItemPromotion(ReqItemList reqItemList)
        {
            GenericResponse genericResponse = storeSettings.GetItemPromotion(reqItemList);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/additemdelay")]
        public ActionResult AddItemDelay(ReqItemDelays reqItemDelays)
        {
            GenericResponse genericResponse = storeSettings.AddItemDelay(reqItemDelays);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/removeitemdelay")]
        public ActionResult RemoveItemDelay(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = storeSettings.RemoveItemDelay(reqRemoveItem);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/getitemdelaylist")]
        public ActionResult GetItemDelayList(ReqItemList reqItemList)
        {
            GenericResponse genericResponse = storeSettings.GetItemDelayList(reqItemList);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/addfactorypausetimings")]
        public ActionResult AddFactoryPauseTimings(ReqFactoryPause reqFactoryPause)
        {
            GenericResponse genericResponse = storeSettings.AddFactoryPauseTimings(reqFactoryPause);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/removefactorypausetimings")]
        public ActionResult RemoveFactoryPauseTimings(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = storeSettings.RemoveFactoryPauseTimings(reqRemoveItem);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/getfactorypausetimings")]
        public ActionResult GetFactoryPauseTimings(ReqDelay reqDelay)
        {
            GenericResponse genericResponse = storeSettings.GetFactoryPauseTimings(reqDelay);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/additemoftheday")]
        public ActionResult AddItemOfTheDay(ReqItemOfTheDay reqItemOfTheDay)
        {
            GenericResponse genericResponse = storeSettings.AddItemOfTheDay(reqItemOfTheDay);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/removeitemoftheday")]
        public ActionResult RemoveItemOfTheDay(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = storeSettings.RemoveItemOfTheDay(reqRemoveItem);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/getitemoftheday")]
        public ActionResult GetItemOfTheDay(ReqItemList reqItemList)
        {
            GenericResponse genericResponse = storeSettings.GetItemOfTheDay(reqItemList);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/addblacklist")]
        public ActionResult AddBlackList(ReqBlackList reqBlack)
        {
            GenericResponse genericResponse = storeSettings.AddBlackList(reqBlack);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/removeblacklist")]
        public ActionResult RemoveBlackList(ReqRemoveBlackList reqRemoveBlackList)
        {
            GenericResponse genericResponse = storeSettings.RemoveBlackList(reqRemoveBlackList);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/store/getblacklist")]
        public ActionResult GetBlackList(ReqLoadBlacList reqLoadBlacList)
        {
            GenericResponse genericResponse = storeSettings.GetBlackList(reqLoadBlacList);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/getoverallorderdelay")]
        public ActionResult GetOverAllOrderDelay(ReqDelay reqDelay)
        {
            GenericResponse genericResponse = storeSettings.GetOverAllOrderDelay(reqDelay);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/addoverallorderdelay")]
        public ActionResult AddOverAllOrderDelay(ReqAddOverAllDelay reqAddOverAllDelay)
        {
            GenericResponse genericResponse = storeSettings.AddOverAllOrderDelay(reqAddOverAllDelay);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/removeoverallorderdelay")]
        public ActionResult RemoveOverAllOrderDelay(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = storeSettings.RemoveOverAllOrderDelay(reqRemoveItem);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/store/getBlacklistmembers")]
        public ActionResult getBlacklistmembers(ReqAddBalcklistmembers reqRemoveItem)
        {
            GenericResponse genericResponse = storeSettings.getBlacklistmembers(reqRemoveItem);
            return Ok(genericResponse);
        }
    }
}
