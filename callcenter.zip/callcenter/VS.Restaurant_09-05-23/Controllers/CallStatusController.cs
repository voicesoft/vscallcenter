﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Providers;

namespace VS.Restaurant.Controllers
{
 
    [ApiController]
    public class CallStatusController : ControllerBase
    {
        public readonly ICallStatusUpdateBase callStatusUpdateBase;
        public CallStatusController(ICallStatusUpdateBase _callStatusUpdateBase)
        {
            callStatusUpdateBase = _callStatusUpdateBase;
        }
        [HttpPost, Route("api/callstatus/queuelogs")]
        public ActionResult UpdateQueueLogs(ReqQueueLog req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.UpdateQueueLogs(req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/agentstausupdate")]
        public ActionResult AgentStausUpdate(AgentStatusUpdate req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.AgentStausUpdate(req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/agentcallstatus")]
        public ActionResult AgentCallStatus(LiveAgents req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.AgentCallStatus(req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/getactiveagent")]
        public ActionResult GetActiveAgent(IncomingCall req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.GetorSetAgenQueueData(req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/postcalllog")]
        public ActionResult UpdateCallLog(CallLog req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.UpdateCallLog(req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/updatecurrentggentgtatus")]
        public ActionResult UpdateCurrentAgentStatus(List<AgentList> _req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.UpdateCurrentAgentStatus(_req);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/callstatus/starttraining")]
        public ActionResult Starttraining(RequestStartStop _req)
        {
            GenericResponse genericResponse = callStatusUpdateBase.InitiateTraining(_req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/loadcompanyddl")]
        public IActionResult Loadcompanyddl()
        {
            try
            {
                GenericResponse genericResponse = callStatusUpdateBase.Loadcompany();
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpPost, Route("api/callstatus/posttrainingcalllog")]
        public ActionResult UpdateTrainingCallLog(TCallLog req)
        {
            AudioData genericResponse = callStatusUpdateBase.UpdateTrainingCallLog(req);
            try
            {
                if (genericResponse.status == null)
                {
                    genericResponse.status = "0";
                    genericResponse.extesion = "";
                    genericResponse.did = "";
                    genericResponse.cid = "";
                    genericResponse.audio = "";
                }
               else if (genericResponse.status == "0")
                {
                    genericResponse.extesion = "";
                    genericResponse.did = "";
                    genericResponse.cid = "";
                    genericResponse.audio = "";
                }
                
            }
            catch
            {
                genericResponse.status = "0";
                genericResponse.extesion = "";
                genericResponse.did = "";
                genericResponse.cid = "";
                genericResponse.audio = "";
            }
           
            string JSONContent = Newtonsoft.Json.JsonConvert.SerializeObject(genericResponse);
            return Ok(JSONContent);
        }
        [HttpPost, Route("api/callstatus/uploadaudio")]
        public ActionResult Uploadaudio([FromForm] ReqUploadTrainingAudio requploadaudio)
        {
            GenericResponse genericResponse = callStatusUpdateBase.Uploadaudio(requploadaudio);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/callstatus/loadallaudio")]
        public ActionResult Loadallaudio(LoadcompanyInput loadcompanyInput)
        {
            GenericResponse genericResponse = callStatusUpdateBase.Loadallaudio(loadcompanyInput);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/callstatus/deleteaudiofile")]
        public ActionResult Deleteaudiofile(DeleteaudiofileIP deleteaudiofileValues)
        {
            GenericResponse genericResponse = callStatusUpdateBase.Deleteaudiofile(deleteaudiofileValues);
            return Ok(genericResponse);
        }

    }
}
