﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Controllers
{

    [ApiController]
    public class OrderController : ControllerBase
    {
        public readonly IOrderCreation orderCreation;
        public OrderController(IOrderCreation _orderCreation)
        {
            orderCreation = _orderCreation;
        }

        [HttpPost, Route("api/order/createorder")]
        public ActionResult CreateOrder(OrderHeader ReqOrder)
        {
            GenericResponse genericResponse = orderCreation.CreateOrder(ReqOrder);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/order/getfinisheditems")]
        public ActionResult GetFinishedItems(ReqSearchItems ReqSearch)
        {
            GenericResponse genericResponse = orderCreation.GetFinishedItems(ReqSearch.UserId, ReqSearch.DID);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/order/getsearchitems")]
        public ActionResult GetSearchItems(ReqLoadItems ReqSearch)
        {
            GenericResponse genericResponse = orderCreation.GetSearchItems(ReqSearch.UserId, ReqSearch.CustomerId);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/order/getitemsizebyitemcode")]
        public ActionResult GetItemsizebyItemcode(ReqLoadItems ReqSearch)
        {
            GenericResponse genericResponse = orderCreation.GetItemsizebyItemcode(ReqSearch.UserId, ReqSearch.CustomerId, ReqSearch.Itemcode);
            return Ok(genericResponse);
        }

        [HttpGet, Route("api/order/getorderheaderinfo")]
        public ActionResult GetOrderHeaderInfo(string CustomerId)
        {
            GenericResponse genericResponse = orderCreation.GetOrderHeaderInfo(Convert.ToInt32(CustomerId));
            return Ok(genericResponse);
        }

        [HttpGet, Route("api/order/getorderdetailsbyorderno")]
        public ActionResult GetOrderDetailsbyOrderno(string CustomerId, string OrderNo)
        {
            GenericResponse genericResponse = orderCreation.GetOrderDetailsbyOrderno(Convert.ToInt32(CustomerId), Convert.ToInt64(OrderNo));
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/order/updateorderstatus")]
        public ActionResult UpdateOrderStatus(ReqUpdateStatus req)
        {
            GenericResponse genericResponse = orderCreation.UpdateOrderStatus(req);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/order/updateordertiming")]
        public ActionResult Updateordertiming(ReqUpdateStatus req)
        {
            GenericResponse genericResponse = orderCreation.Updateordertiming(req);
            return Ok(genericResponse);
        }
        /*Out of order*/
        [HttpPost, Route("api/order/loadItemmasterforOOS")]
        public ActionResult LoadItemmasterforOOS(outofstockIP customerid)
        {
            GenericResponse genericResponse = orderCreation.LoadItemmasterforOOS(customerid);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/order/addOutofstocks")]
        public ActionResult AddOutofstocks(addoutofstock req)
        {
            GenericResponse genericResponse = orderCreation.AddOutofstocks(req);
            return Ok(genericResponse);
        }

        [HttpPost, Route("api/order/loadOutofstocks")]
        public ActionResult LoadOutofstocks(outofstockIP customerid)
        {
            GenericResponse genericResponse = orderCreation.LoadOutofstocks(customerid);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/order/updateoutofstock")]
        public ActionResult Updateoutofstock(stockIP stockid)
        {
            GenericResponse genericResponse = orderCreation.Updateoutofstock(stockid);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/order/loadmasteritemddl")]
        public ActionResult LoadmasteritemDDL(LoadmasteritemDDLIP customerid)
        {
            GenericResponse genericResponse = orderCreation.LoadmasteritemDDL(customerid);
            return Ok(genericResponse);
        }
        /*End*/
        /*Conference call*/
        [HttpPost, Route("api/order/makeconferencecall")]
        public ActionResult Makeconferencecall(ConferenceCallIP conferenceCallIP)
        {
            GenericResponse genericResponse = orderCreation.Makeconferencecall(conferenceCallIP);
            return Ok(genericResponse);
        }
        [HttpPost,Route("api/order/playaudiofile")]
        public ActionResult Playaudiofile(Playaudioip playaudioip)
        {
            GenericResponse genericResponse = orderCreation.Playaudiofile(playaudioip);
            return Ok(genericResponse);
        }
        [HttpPost, Route("api/order/stopaudiofile")]
        public ActionResult Stopaudiofile(Stopaudioip stopaudioip)
        {
            GenericResponse genericResponse = orderCreation.Stopaudiofile(stopaudioip);
            return Ok(genericResponse);
        }
        /*End*/
        [HttpGet, Route("api/order/getconsumername")]
        public ActionResult GetConsumername(string consumermobile, string customermobile)
        {
            GenericResponse genericResponse = orderCreation.GetConsumername(consumermobile, customermobile);
            return Ok(genericResponse);
        }

    }
}
