﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Dynamic;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AgentmonitorWebAPI : ControllerBase
    {
        private readonly IAgentmonitorProvider agentmonitorProvider;
        public AgentmonitorWebAPI(IAgentmonitorProvider _agentmonitorProvider)
        {
            agentmonitorProvider = _agentmonitorProvider;
        }
        [HttpPost, Route("[action]")]
        public IActionResult Validatelogin(LoginReq loginReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Validatelogin(loginReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpPost, Route("[action]")]
        public IActionResult Loadagentcallstatus(LoadagentstatusReq loadagentstatusReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentcallstatus(loadagentstatusReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpGet, Route("[action]")]
        public IActionResult Loadagentddl()
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentddl();
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

        [HttpGet, Route("[action]")]
        public IActionResult Loadagentlanguage()
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentlanguage();
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpPost, Route("[action]")]
        public IActionResult Loadagentcalldetail(LoadagenthistoryReq loadagenthistoryReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentcallhistory(loadagenthistoryReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpPost, Route("[action]")]
        public IActionResult Loadagentcallsummary(LoadagenthistoryReq loadagenthistoryReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentcallsummary(loadagenthistoryReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpGet, Route("[action]")]
        public IActionResult Loadagentbyrmddl(int reportingmanagerid)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentbyrmddl(reportingmanagerid);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpPost, Route("[action]")]
        public IActionResult Loadagentcallsummarystatus(LoadagenthistoryReq loadagenthistoryReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentcallsummarystatus(loadagenthistoryReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpPost, Route("[action]")]
        public IActionResult Loadagentcalldetailstatus(LoadagenthistoryReq loadagenthistoryReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.Loadagentcalldetailstatus(loadagenthistoryReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpGet, Route("[action]")]
        public IActionResult DownloadItems(string Customerid)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.DowloadItemMaster(Convert.ToInt32(Customerid));
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpGet, Route("[action]")]
        public IActionResult downloadpackageitems(string Customerid)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.downloadpackageitems(Convert.ToInt32(Customerid));
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }
        [HttpPost, Route("[action]")]
        public IActionResult downloadagentcallstatus(downloadagentcallReq downloadagentcallReq)
        {
            try
            {
                GenericResponse genericResponse = agentmonitorProvider.downloadagentcallstatus(downloadagentcallReq);
                if (genericResponse == null)
                    return NotFound();
                else
                    return Ok(genericResponse);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message.ToString());
            }
        }

    }
}
