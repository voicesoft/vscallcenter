﻿using System.Dynamic;
using System;
using System.IO;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using MimeKit;
using MailKit.Net.Smtp;
using VS.Restaurant.Repository;
using Newtonsoft.Json;
using System.Text;
using VS.Restaurant.Helpers;
using VS.Restaurant.Repository.Interfaces;
using static Org.BouncyCastle.Math.EC.ECCurve;
using static System.Net.Mime.MediaTypeNames;

namespace VS.Restaurant.Providers
{
    public class VSRAdminProvider : VSRAdminProviderInterface
    {
        private readonly VSRAdminRepositoryInterface vSRAdminRepositoryInterface;
        public VSRAdminProvider(VSRAdminRepositoryInterface _vSRAdminRepositoryInterface)
        {
            vSRAdminRepositoryInterface = _vSRAdminRepositoryInterface;
            //dbConfig = _dbConfig;
        }
        public GenericResponse AddCompany(Customer customer)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            dynamic dbConfig = "";
            List<Defaultresultset> defaultresultset = vSRAdminRepositoryInterface.AddCompany(customer, ref dbConfig);
            if (Convert.ToInt32(defaultresultset.Count) > 0 && defaultresultset[0].Status > 0)
            {
                if (customer.Type == 1|| customer.Type == 2)
                {
                    string _fromName = dbConfig.GetSection("MailFromName").Value;
                    string _fromAddress = dbConfig.GetSection("MailFromAddress").Value;
                    string _Password = dbConfig.GetSection("FromPass").Value;
                    string _ToAddress = customer.Email ?? "";
                    string _ToName = customer.ContactPerson ?? "";
                    string _Subject = dbConfig.GetSection("CreateSubject").Value;
                    string _TextBody = "Login details:";
                    string _TextLink = dbConfig.GetSection("CreateLink").Value; ;
                    string _TextPassword = dbConfig.GetSection("CreatePassword").Value;
                    string _Welcomegreeting = dbConfig.GetSection("Welcomegreeting").Value;

                    string _HtmlBody = "<div style='box-shadow:0px 2px 3px #ddd;padding:3px 3px 10px 0px;margin:10px auto;width:800px;font-family: serif;background:rgba(238, 238, 238, 0.59);'>"
                                        +
                                        "<br/>"
                                        +
                                        "<h3> &nbsp;&nbsp;Hi&nbsp;"
                                        +
                                       customer.ContactPerson
                                        +
                                        ",<br/><br/> &nbsp;&nbsp;Thanks for signing up with " + _Welcomegreeting + "!"
                                        +
                                        " <br/><br/> &nbsp;&nbsp;Here are the details for your dashboard,"
                                        +
                                        " <br/><br/> &nbsp;&nbsp;Link :" + _TextLink
                                        +
                                        "<br/> &nbsp;&nbsp;Username :" + customer.Username
                                        +
                                        "<br/> &nbsp;&nbsp;Password :" + _TextPassword
                                        +
                                        "<br/><br/> &nbsp;&nbsp;As always, our support team can be reached at[sales@voicesnap.com] if you ever get stuck."
                                        +
                                        "<br/><br/> &nbsp;&nbsp;Have a great day!"
                                        +
                                        "</h3></div>";

                    bool boolval = Send_SMTP_Mail(_fromAddress, _fromName, _Password, _ToName, _ToAddress, _Subject, _HtmlBody, _TextBody);

                    if (boolval == true)
                    {
                        defaultresultset[0].Status = 1;
                        defaultresultset[0].Message = defaultresultset[0].Message + " & Mail Sent to client";
                        dynamic.resultSet = defaultresultset;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        defaultresultset[0].Status = 2;
                        defaultresultset[0].Message = defaultresultset[0].Message + " & Mail not Sent to client. Please check email id";
                        dynamic.resultSet = defaultresultset;
                        genericResponse.Data = dynamic;

                    }
                }
                else
                {
                    dynamic.resultSet = defaultresultset;
                    genericResponse.Data = dynamic;
                }
            }
            else
            {
                dynamic.resultSet = defaultresultset;
                genericResponse.Data = dynamic;
            }

            return genericResponse;
        }
        public GenericResponse LoadCompany(LoadcompanyInput loadcompanyInput)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            //List<LoadcompanyOutput> defaultresultset = new List<LoadcompanyOutput>();
            int totalrow = 0;
            List<LoadcompanyOutput> defaultresultset = vSRAdminRepositoryInterface.LoadCompany(loadcompanyInput, ref totalrow);
            dynamic.totalrow = totalrow;
            dynamic.resultset = defaultresultset;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Customerinfo(Addcustomerinfo addcustomerinfo)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            dynamic dbConfig = "";
            //List<LoadcompanyOutput> defaultresultset = new List<LoadcompanyOutput>();
            List<Defaultresultset> defaultresultset = vSRAdminRepositoryInterface.Customerinfo(addcustomerinfo, ref dbConfig);
            dynamic.resultset = defaultresultset;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse UpdateagentAvailability(string agentextension)
        {
            List<Defaultresultset> lstdefalutresultsets = new List<Defaultresultset>();
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            lstdefalutresultsets = vSRAdminRepositoryInterface.UpdateagentAvailability(agentextension);
            dynamic.data = lstdefalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Welcomeaudio(ReqWelcomeAudio reqwelcomeaudio)
        {
            if (string.IsNullOrEmpty(Convert.ToString(reqwelcomeaudio.Itemdata)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                GenericResponse genericResponse = new GenericResponse();
                dynamic dynamic = new ExpandoObject();
                try
                {
                    string URL = "";
                    string audioURL = "";
                    string audioURLWithExtension = "";
                    VSRAdminRepository vsrr = new VSRAdminRepository();
                    string audiopath = vsrr.getConnection().GetSection("connectionStrings").GetSection("welcomeAudioPath").Value;
                    string withextension = vsrr.getConnection().GetSection("connectionStrings").GetSection("withextension").Value;
                    string audiouploadurl = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioupload").Value;
                    string audiodownload = vsrr.getConnection().GetSection("connectionStrings").GetSection("welcomeAudioDownload").Value;
                    string audioconversionurl = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioconversion").Value;
                    var audio = reqwelcomeaudio.Audiofile;

                    AddReqUploadTrainingAudio objContact = new AddReqUploadTrainingAudio();
                    var contactdata = Convert.ToString(reqwelcomeaudio.Itemdata);
                    objContact = JsonConvert.DeserializeObject<AddReqUploadTrainingAudio>(contactdata);
                    StreamWriter sw;

                    if (audio == null)
                    {
                    }
                    else
                    { 
                        if (!Directory.Exists(audiopath + objContact.CustomerId.ToString()))
                        {
                            Directory.CreateDirectory(audiopath + objContact.CustomerId.ToString());
                        }
                        using var fileStream = new FileStream(audiopath + objContact.CustomerId.ToString() + "/" + audio.FileName, FileMode.Create);
                        audio.CopyTo(fileStream);
                    }
                    audioURLWithExtension = Path.GetFileNameWithoutExtension(audio.FileName);
                    if (withextension == "1")
                        audioURLWithExtension += Path.GetExtension(audio.FileName);
                    audiopath += audioURLWithExtension;
                    objContact.Audiofile = audioURL;
                    objContact.Audiofilewithextension = audioURLWithExtension;
                    //defalutresultsets = vSRAdminRepositoryInterface.Welcomeaudio(objContact);
                 
                    try
                    {
                        AudioUpload audioUpload = new AudioUpload();
                        audioUpload.link = audiodownload + objContact.CustomerId.ToString() + "/" + audioURLWithExtension;
                        audioUpload.filename = audioURLWithExtension;
                        string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(audioUpload);
                        using (var httpClient = new HttpClient())
                        {
                            StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                            var response = httpClient.PostAsync(audiouploadurl, content).Result;
                            if (response.IsSuccessStatusCode)
                            {
                                AudioConvert audioConvert = new AudioConvert();
                                audioConvert.current = System.IO.Path.GetFileNameWithoutExtension(audioURLWithExtension);
                                audioConvert.convert = System.IO.Path.GetFileNameWithoutExtension(audioURLWithExtension);
                                audioConvert.format = System.IO.Path.GetExtension(audioURLWithExtension);
                                audioConvert.cformat = ".wav";
                                using (var httpWebClient = new HttpClient())
                                {
                                    JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(audioConvert);
                                    StringContent Webcontent = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                                    var webresponse = httpWebClient.PostAsync(audioconversionurl, Webcontent).Result;
                                    if (webresponse.IsSuccessStatusCode)
                                    {
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {

                    }
                    dynamic.status = 1;
                    dynamic.message = "Uploaded successfully ...!";
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
                catch (Exception ex)
                {
                    defalutresultsets[0].Message = ex.Message.ToString();
                    defalutresultsets[0].Status = -1;
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
            }
            throw new AppException();
        }
        public GenericResponse Loadwelcomeaudio(LoadwelcomeAudio loadwelcomeAudio)
        {            
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();            
            VSRAdminRepository vsrr = new VSRAdminRepository();
            var welcomeAudioPath = vsrr.getConnection().GetSection("connectionStrings").GetSection("welcomeAudioPath").Value;
            string audiodownload = vsrr.getConnection().GetSection("connectionStrings").GetSection("welcomeAudioDownload").Value;            
            List<ListWelcomefile> _defaultList = new List<ListWelcomefile>();

            if (System.IO.Directory.Exists(welcomeAudioPath + loadwelcomeAudio.CustomerId.ToString()))
            {
                string[] files = System.IO.Directory.GetFiles(welcomeAudioPath + loadwelcomeAudio.CustomerId.ToString());
                foreach (string filePath in files)
                {
                    _defaultList.Add(new ListWelcomefile { Audio = System.IO.Path.GetFileName(filePath), AudioURL = audiodownload + loadwelcomeAudio.CustomerId.ToString() + "/" + System.IO.Path.GetFileName(filePath) });
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = _defaultList;
                genericResponse.Data = dynamic;
            }
            dynamic.status = 1;
            dynamic.message = "Listed successfully ...!";
            dynamic.resultset = _defaultList;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Deletewelcomeaudio(DeletewelcomeAudio deletewelcomeAudio)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            VSRAdminRepository vsrr = new VSRAdminRepository();
            var welcomeAudioPath = vsrr.getConnection().GetSection("connectionStrings").GetSection("welcomeAudioPath").Value;
            string audiodownload = vsrr.getConnection().GetSection("connectionStrings").GetSection("welcomeAudioDownload").Value;
            List<Defaultresultset> lstdefalutresultsets = new List<Defaultresultset>();

            if (System.IO.Directory.Exists(welcomeAudioPath + deletewelcomeAudio.CustomerId.ToString()))
            {
                string files = (welcomeAudioPath + deletewelcomeAudio.CustomerId.ToString() +"/"+ deletewelcomeAudio.Audio.ToString());
                if (System.IO.File.Exists(files))
                {
                    System.IO.File.Delete(files);
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = lstdefalutresultsets;
                genericResponse.Data = dynamic;
            }
            dynamic.status = 1;
            dynamic.message = "Deleted successfully...!";
            dynamic.resultset = lstdefalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #region Mail functions
        public Boolean Send_SMTP_Mail(string _fromAddress, string _fromName, string _Password, string _ToName, string _ToAddress, string _Subject, string _HtmlBody, string _TextBody)
        {
            try
            {
                MimeMessage message = new MimeMessage();
                BodyBuilder bodyBuilder = new BodyBuilder();

                MailboxAddress from = new MailboxAddress(_fromName, _fromAddress);
                message.From.Add(from);

                MailboxAddress to = new MailboxAddress(_ToName, _ToAddress);
                message.To.Add(to);

                message.Subject = _Subject;

                bodyBuilder.HtmlBody = _HtmlBody;

                bodyBuilder.TextBody = _TextBody;

                message.Body = bodyBuilder.ToMessageBody();

                SmtpClient client = new SmtpClient();
                client.Connect("smtp.gmail.com", 465, true);
                client.Authenticate(_fromAddress, _Password);

                client.Send(message);
                client.Disconnect(true);
                client.Dispose();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        #endregion
    }
}
