﻿using System.Data;
using System.Dynamic;
using VS.Restaurant.Controllers;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Providers
{
    public class AgentmonitorProvider : IAgentmonitorProvider
    {
        private readonly IAgentmonitorRepository agentmonitorRepository;
        public AgentmonitorProvider(IAgentmonitorRepository _agentmonitorRepository)
        {
            agentmonitorRepository = _agentmonitorRepository;
        }
        public GenericResponse Validatelogin(LoginReq loginReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<LoginRes> loginRes = agentmonitorRepository.Validatelogin(loginReq);
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    if (loginRes[0].Userid > 0)
                    {
                        dynamic.status = 1;
                        dynamic.message = "success";
                        dynamic.resultset = loginRes;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        dynamic.status = 0;
                        dynamic.message = loginRes[0].Username;
                        dynamic.resultset = new List<string>();
                        genericResponse.Data = dynamic;
                    }
                }
                return genericResponse;
            }
        }
        public GenericResponse Loadagentcallstatus(LoadagentstatusReq loginReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<LoadagentstatusRes> loginRes = agentmonitorRepository.Loadagentcallstatus(loginReq);
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    if (loginRes[0].Agentid > 0)
                    {
                        dynamic.status = 1;
                        dynamic.message = "success";
                        dynamic.resultset = loginRes;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        dynamic.status = 0;
                        dynamic.message = "No Records Found...!";
                        dynamic.resultset = new List<string>();
                        genericResponse.Data = dynamic;
                    }
                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse Loadagentddl()
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<Agentddl> loginRes = agentmonitorRepository.Loadagentddl();
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    if (loginRes[0].Agentid > 0)
                    {
                        dynamic.status = 1;
                        dynamic.message = "success";
                        dynamic.resultset = loginRes;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        dynamic.status = 0;
                        dynamic.message = "No Records Found...!";
                        dynamic.resultset = new List<string>();
                        genericResponse.Data = dynamic;
                    }
                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse Loadagentlanguage()
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<Languageddl> loginRes = agentmonitorRepository.Loadagentlanguage();
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    if (loginRes[0].Languageid > 0)
                    {
                        dynamic.status = 1;
                        dynamic.message = "success";
                        dynamic.resultset = loginRes;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        dynamic.status = 0;
                        dynamic.message = "No Records Found...!";
                        dynamic.resultset = new List<string>();
                        genericResponse.Data = dynamic;
                    }
                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse Loadagentcallhistory(LoadagenthistoryReq loadagenthistoryReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            string basepath = string.Empty, downloadpath = string.Empty; string fileName = "";
            DataTable dataSet = agentmonitorRepository.Loadagentcallhistory(loadagenthistoryReq, ref basepath, ref downloadpath);
            if (dataSet.Rows.Count > 0)
            {
                DataTable dataTable = dataSet;
                if (dataTable.Rows.Count > 0)
                {
                    string path = basepath;
                    string target = path + "/Reports";
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                    }
                    string tempname = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    string tempname1 = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    fileName = string.Concat(target + "/Calldetailreport_" + loadagenthistoryReq.Agentid + tempname + ".csv");
                    tempname = string.Concat(downloadpath + "/Reports/Calldetailreport_" + loadagenthistoryReq.Agentid + tempname + ".csv");
                    string[] columns = { "RNo", "Agentname", "Agentextension", "Logdate", "Starttime", "Endtime", "Duration", "Callstatus" };
                    ExportToExcel expxl = new ExportToExcel();
                    string a = expxl.ExportExcel(fileName, dataTable, fileName, "Agent call taken report", loadagenthistoryReq.Fromdate, loadagenthistoryReq.Todate, true, columns);
                    if (a.Split("¶").Length == 1)
                    {
                        dynamic.status = 1;
                        dynamic.message = tempname; 
                        dynamic.resultset = new List<string>();
                    }
                    else
                    {
                        dynamic.status = -1;
                        dynamic.message = "Unable to download. Please try again later...";
                        dynamic.resultset = new List<string>();
                    }
                    genericResponse.Data = dynamic;
                }
                else
                {
                    dynamic.status = 0;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = new List<string>();
                genericResponse.Data = dynamic;
            }
            return genericResponse;
        }
        public GenericResponse Loadagentcallsummary(LoadagenthistoryReq loadagenthistoryReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            string basepath = string.Empty, downloadpath = string.Empty; string fileName = "";
            DataTable dataSet = agentmonitorRepository.Loadagentcallsummary(loadagenthistoryReq, ref basepath, ref downloadpath);
            if (dataSet.Rows.Count > 0)
            {
                DataTable dataTable = dataSet;
                if (dataTable.Rows.Count > 0)
                {
                    string path = basepath;
                    string target = path + "/Reports";
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                    }
                    string tempname = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    string tempname1 = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    fileName = string.Concat(target + "/Callsummaryreport_" + loadagenthistoryReq.Agentid + tempname + ".csv");
                    tempname = string.Concat(downloadpath + "/Reports/Callsummaryreport_" + loadagenthistoryReq.Agentid + tempname + ".csv");
                    string[] columns = { "RNo", "Agentname", "Agentextension", "Logdate", "Starttime", "Endtime", "Duration", "Callstatus" };
                    ExportToExcel expxl = new ExportToExcel();
                    string a = expxl.ExportExcel(fileName, dataTable, fileName, "Agent call taken report", loadagenthistoryReq.Fromdate, loadagenthistoryReq.Todate, true, columns);
                    if (a.Split("¶").Length == 1)
                    {
                        dynamic.status = 1;
                        dynamic.message = tempname ;
                        dynamic.resultset = new List<string>();
                    }
                    else
                    {
                        dynamic.status = -1;
                        dynamic.message = "Unable to download. Please try again later...";
                        dynamic.resultset = new List<string>();
                    }
                    genericResponse.Data = dynamic;
                }
                else
                {
                    dynamic.status = 0;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = new List<string>();
                genericResponse.Data = dynamic;
            }
            return genericResponse;
        }
        public GenericResponse Loadagentbyrmddl(int rmid)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<Agentddl> loginRes = agentmonitorRepository.Loadagentbyrmddl(rmid);
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    if (loginRes[0].Agentid > 0)
                    {
                        dynamic.status = 1;
                        dynamic.message = "success";
                        dynamic.resultset = loginRes;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        dynamic.status = 0;
                        dynamic.message = "No Records Found...!";
                        dynamic.resultset = new List<string>();
                        genericResponse.Data = dynamic;
                    }
                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse Loadagentcallsummarystatus(LoadagenthistoryReq loginReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<SummaryreportOP> loginRes = agentmonitorRepository.Loadagentcallsummarystatus(loginReq);
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    dynamic.status = 1;
                    dynamic.message = "success";
                    dynamic.resultset = loginRes;
                    genericResponse.Data = dynamic;

                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse Loadagentcalldetailstatus(LoadagenthistoryReq loginReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<DetailreportOP> loginRes = agentmonitorRepository.Loadagentcalldetailstatus(loginReq);
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    dynamic.status = 1;
                    dynamic.message = "success";
                    dynamic.resultset = loginRes;
                    genericResponse.Data = dynamic;
                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse DowloadItemMaster(int CustomerId)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            string basepath = string.Empty, downloadpath = string.Empty; string fileName = "";
            DataTable dataSet = agentmonitorRepository.DownloadItems(CustomerId, ref basepath, ref downloadpath);
            if (dataSet.Rows.Count > 0)
            {
                DataTable dataTable = dataSet;
                if (dataTable.Rows.Count > 0)
                {
                    string path = basepath;
                    string target = path + "/Reports";
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                    }
                    string tempname = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    string tempname1 = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    fileName = string.Concat(target + "/Itemdetailreport_" + CustomerId.ToString() + tempname + ".csv");
                    tempname = string.Concat(downloadpath + "/Reports/Itemdetailreport_" + CustomerId.ToString() + tempname + ".csv");
                    string[] columns = { "RNo", "Agentname", "Agentextension", "Logdate", "Starttime", "Endtime", "Duration", "Callstatus" };
                    ExportToExcel expxl = new ExportToExcel();
                    string a = expxl.ExportExcel(fileName, dataTable, fileName, "Item Master","", "", true, columns);
                    if (a.Split("¶").Length == 1)
                    {
                        dynamic.status = 1;
                        dynamic.message = tempname;
                        dynamic.resultset = new List<string>();
                    }
                    else
                    {
                        dynamic.status = -1;
                        dynamic.message = "Unable to download. Please try again later...";
                        dynamic.resultset = new List<string>();
                    }
                    genericResponse.Data = dynamic;
                }
                else
                {
                    dynamic.status = 0;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = new List<string>();
                genericResponse.Data = dynamic;
            }
            return genericResponse;
        }
        public GenericResponse downloadpackageitems(int CustomerId)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            string basepath = string.Empty, downloadpath = string.Empty; string fileName = "";
            DataTable dataSet = agentmonitorRepository.downloadpackageitems(CustomerId, ref basepath, ref downloadpath);
            if (dataSet.Rows.Count > 0)
            {
                DataTable dataTable = dataSet;
                if (dataTable.Rows.Count > 0)
                {
                    string path = basepath;
                    string target = path + "/Reports";
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                    }
                    string tempname = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    string tempname1 = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    fileName = string.Concat(target + "/ItemPackagedetail_" + CustomerId.ToString() + tempname + ".csv");
                    tempname = string.Concat(downloadpath + "/Reports/ItemPackagedetail_" + CustomerId.ToString() + tempname + ".csv");
                    string[] columns = { "RNo", "Agentname", "Agentextension", "Logdate", "Starttime", "Endtime", "Duration", "Callstatus" };
                    ExportToExcel expxl = new ExportToExcel();
                    string a = expxl.ExportExcel(fileName, dataTable, fileName, "Item Master", "", "", true, columns);
                    if (a.Split("¶").Length == 1)
                    {
                        dynamic.status = 1;
                        dynamic.message = tempname;
                        dynamic.resultset = new List<string>();
                    }
                    else
                    {
                        dynamic.status = -1;
                        dynamic.message = "Unable to download. Please try again later...";
                        dynamic.resultset = new List<string>();
                    }
                    genericResponse.Data = dynamic;
                }
                else
                {
                    dynamic.status = 0;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = new List<string>();
                genericResponse.Data = dynamic;
            }
            return genericResponse;
        }
        public GenericResponse downloadagentcallstatus(downloadagentcallReq downloadagentcallReq)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            string basepath = string.Empty, downloadpath = string.Empty; string fileName = "";
            DataTable dataSet = agentmonitorRepository.downloadagentcallstatus(downloadagentcallReq, ref basepath, ref downloadpath);
            if (dataSet.Rows.Count > 0)
            {
                DataTable dataTable = dataSet;
                if (dataTable.Rows.Count > 0)
                {
                    string path = basepath;
                    string target = path + "/Reports";
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                    }
                    string tempname = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    string tempname1 = System.DateTime.Now.ToString("yyyymmddhhmmss");
                    fileName = string.Concat(target + "/Agentcallstatus_" + downloadagentcallReq.Agentid + tempname + ".csv");
                    tempname = string.Concat(downloadpath + "/Reports/Agentcallstatus_" + downloadagentcallReq.Agentid + tempname + ".csv");
                    string[] columns = { "Agentname", "Agentextension", "Logdate", "Starttime", "Endtime", "Duration", "Callstatus" };
                    ExportToExcel expxl = new ExportToExcel();
                    string a = expxl.ExportExcel(fileName, dataTable, fileName, "Agent call status report", downloadagentcallReq.Fromdate,downloadagentcallReq.Todate, true, columns);
                    if (a.Split("¶").Length == 1)
                    {
                        dynamic.status = 1;
                        dynamic.message = tempname;
                        dynamic.resultset = new List<string>();
                    }
                    else
                    {
                        dynamic.status = -1;
                        dynamic.message = "Unable to download. Please try again later...";
                        dynamic.resultset = new List<string>();
                    }
                    genericResponse.Data = dynamic;
                }
                else
                {
                    dynamic.status = 0;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
            }
            else
            {
                dynamic.status = 0;
                dynamic.message = "No Records Found...!";
                dynamic.resultset = new List<string>();
                genericResponse.Data = dynamic;
            }
            return genericResponse;
        }

    }
}

