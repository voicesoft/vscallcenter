﻿using System.Dynamic;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Providers
{
    public class StoreSettings : IStoreSettings
    {
        public readonly IFactorySettings factorySettings;
        public StoreSettings(IFactorySettings _factorySettings) 
        {
            factorySettings= _factorySettings;
        }
        public GenericResponse AddBlackList(ReqBlackList reqBlack)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.AddBlackList(reqBlack);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse RemoveBlackList(ReqRemoveBlackList reqRemoveBlackList)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.RemoveBlackList(reqRemoveBlackList);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse GetBlackList(ReqLoadBlacList reqLoadBlacList)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResLoadBlacList> _defaullist = new List<ResLoadBlacList>();
            int totalrows = 0;
            _defaullist = factorySettings.GetBlackList(reqLoadBlacList, ref totalrows);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = totalrows;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AddFactoryPauseTimings(ReqFactoryPause reqFactoryPause)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.AddFactoryPauseTimings(reqFactoryPause);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse RemoveFactoryPauseTimings(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.RemoveFactoryPauseTimings(reqRemoveItem);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse GetFactoryPauseTimings(ReqDelay reqDelay)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResDelayList> _defaullist = new List<ResDelayList>();             
            _defaullist = factorySettings.GetFactoryPauseTimings(reqDelay);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = _defaullist.Count;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AddItemDelay(ReqItemDelays reqItemDelays)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.AddItemDelay(reqItemDelays);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse RemoveItemDelay(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.RemoveItemDelay(reqRemoveItem);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse GetItemDelayList(ReqItemList reqItemList)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResItemList> _defaullist = new List<ResItemList>();
            int totalrows = 0;
            _defaullist = factorySettings.GetItemDelayList(reqItemList, ref totalrows);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = totalrows;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AddItemOfTheDay(ReqItemOfTheDay reqItemOfTheDay)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.AddItemOfTheDay(reqItemOfTheDay);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse RemoveItemOfTheDay(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.RemoveItemOfTheDay(reqRemoveItem);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse GetItemOfTheDay(ReqItemList reqItemList)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResItemList> _defaullist = new List<ResItemList>();
            int totalrows = 0;
            _defaullist = factorySettings.GetItemOfTheDay(reqItemList, ref totalrows);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = totalrows;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AddItemPromotion(ReqItemPromotion reqItemPromotion)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.AddItemPromotion(reqItemPromotion);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse RemoveItemPromotion(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.RemoveItemPromotion(reqRemoveItem);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }        
        public GenericResponse GetItemPromotion(ReqItemList reqItemList)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResItemList> _defaullist = new List<ResItemList>();
            int totalrows = 0;
            _defaullist = factorySettings.GetItemPromotion(reqItemList, ref totalrows);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = totalrows;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse GetOverAllOrderDelay(ReqDelay reqDelay)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResDelayList> _defaullist = new List<ResDelayList>();
            int totalrows = 0;
            _defaullist = factorySettings.GetOverAllOrderDelay(reqDelay);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = _defaullist.Count;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AddOverAllOrderDelay(ReqAddOverAllDelay reqAddOverAllDelay)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.AddOverAllOrderDelay(reqAddOverAllDelay);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse RemoveOverAllOrderDelay(ReqRemoveItem reqRemoveItem)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            DefaultResponse _defaultresponse = new DefaultResponse();
            _defaultresponse = factorySettings.RemoveOverAllOrderDelay(reqRemoveItem);
            dynamic.status = _defaultresponse.Status;
            dynamic.message = _defaultresponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse getBlacklistmembers(ReqAddBalcklistmembers reqmsg)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<ResAddBalcklistmembers> _defaullist = new List<ResAddBalcklistmembers>();
            int totalrows = 0;
            _defaullist = factorySettings.getBlacklistmembers(reqmsg, ref  totalrows);
            dynamic.status = 1;
            dynamic.resultset = _defaullist;
            dynamic.totalrows = totalrows;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
    }
}
