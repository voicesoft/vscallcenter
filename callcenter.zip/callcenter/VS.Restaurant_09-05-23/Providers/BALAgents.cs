﻿using System.Dynamic;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Providers
{
    public class BALAgents : IAgentInterface
    {
        private readonly IAgentRepository agentRepository;

        public BALAgents(IAgentRepository _agentInterface)
        {
            agentRepository = _agentInterface;
        }
        public GenericResponse AddAgent(CreateAgents _agent)
        {
            Defalutresultset defalutresultsets = new Defalutresultset();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = agentRepository.CreateAgent(_agent);
            dynamic.status = defalutresultsets.Status;
            dynamic.message = defalutresultsets.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse GetAllAgents(int userid)
        {
            List<Agents> agents = agentRepository.GetAllAgents(userid);
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            dynamic.status = 1;
            dynamic.resultset = agents;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

    }
}
