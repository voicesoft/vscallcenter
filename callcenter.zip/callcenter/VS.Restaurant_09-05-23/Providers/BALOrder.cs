﻿using System.Collections.Generic;
using System.Dynamic;
using System.Security.Cryptography;
using System.Text.Json.Nodes;
using System.Text;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository;
using VS.Restaurant.Repository.Interfaces;
using static System.Net.Mime.MediaTypeNames;
using System.Diagnostics.CodeAnalysis;

namespace VS.Restaurant.Providers
{
    public class BALOrder : IOrderCreation
    {
        private readonly IOrder order;

        public BALOrder(IOrder _order)
        {
            order = _order;
        }
        public GenericResponse CreateOrder(OrderHeader _Objorder)
        {
            DefaultResponse defalutresultsets = new DefaultResponse();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = order.CreateNewOrder(_Objorder);
            try
            {
                if (defalutresultsets.Status == 1)
                {
                    VSRRepository vsrr = new VSRRepository();
                    string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("orderpath").Value;
                    string path = "";
                    Int32 orderid = Convert.ToInt32(defalutresultsets.OrderId);
                    path = filepath + Convert.ToString(orderid) + ".txt";
                    using (StreamWriter writer = System.IO.File.CreateText(path))
                    {

                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

            dynamic.status = defalutresultsets.Status;
            dynamic.message = defalutresultsets.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse GetFinishedItems(int UserId, string DID)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<FinishedItemDetails> finishedItemDetails = order.GetFinishedItems(UserId, DID);
            dynamic.status = 1;
            dynamic.message = "";
            dynamic.resultset = finishedItemDetails;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse GetSearchItems(int UserId, int CustomerId)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<PckItems> pckItems = order.GetSearchItems(UserId, CustomerId);
            dynamic.status = 1;
            dynamic.message = "";
            dynamic.resultset = pckItems;
            genericResponse.Data = dynamic;
            return genericResponse;

        }
        public GenericResponse GetItemsizebyItemcode(int UserId, int CustomerId, int Itemcode)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<ItemPriceDetails> itemPriceDetails = order.GetItemsizebyItemcode(UserId, CustomerId, Itemcode);
            dynamic.status = 1;
            dynamic.message = "";
            dynamic.resultset = itemPriceDetails;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse GetOrderHeaderInfo(int CustomerId)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<OrderHeaderInfo> orderDetails = order.GetOrderHeaderInfo(CustomerId);
            dynamic.status = 1;
            dynamic.message = "";
            dynamic.resultset = orderDetails;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse GetOrderDetailsbyOrderno(int CustomerId, Int64 OrderNo)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<OrderDetailsInfo> orderDetails = order.GetOrderDetailsbyOrderno(CustomerId, OrderNo);
            dynamic.status = 1;
            dynamic.message = "";
            dynamic.resultset = orderDetails;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse UpdateOrderStatus(ReqUpdateStatus req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            int Result = order.UpdateOrderStatus(req);
            if (Result > 0)
            {
                dynamic.status = 1;
                dynamic.message = "Order status updated successfully.";
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = "Error occurred. Please try again later.";
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Updateordertiming(ReqUpdateStatus req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            int Result = order.Updateordertiming(req);
            if (Result > 0)
            {
                dynamic.status = 1;
                dynamic.message = "Order status updated successfully.";
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = "Error occurred. Please try again later.";
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        /*Out of order*/
        public GenericResponse LoadItemmasterforOOS(outofstockIP customerid)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<loadItemmasterforOOS> oplist = new List<loadItemmasterforOOS>();
            oplist = order.LoadItemmasterforOOS(customerid);
            if (oplist.Count > 0)
            {
                dynamic.status = 1;
                dynamic.data = oplist;
            }
            else
            {
                dynamic.status = -1;
                dynamic.data = oplist;
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AddOutofstocks(addoutofstock req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            int Result = order.AddOutofstocks(req);
            if (Result > 0)
            {
                dynamic.status = 1;
                dynamic.message = "Added successfully.";
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = "Error occurred. Please try again later.";
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse LoadOutofstocks(outofstockIP customerid)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<loadOutofstocksOP> oplist = new List<loadOutofstocksOP>();
            oplist = order.LoadOutofstocks(customerid);
            if (oplist.Count > 0)
            {
                dynamic.status = 1;
                dynamic.data = oplist;
            }
            else
            {
                dynamic.status = -1;
                dynamic.data = oplist;
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Updateoutofstock(stockIP stockid)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            int Result = order.Updateoutofstock(stockid);
            if (Result > 0)
            {
                dynamic.status = 1;
                dynamic.message = "Order status updated successfully.";
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = "Error occurred. Please try again later.";
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse LoadmasteritemDDL(LoadmasteritemDDLIP customerid)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            List<ConferenceCallOP> conferenceCallOPs = new List<ConferenceCallOP>();
            List<LoadmasteritemDDLOP> oplist = new List<LoadmasteritemDDLOP>();
            oplist = order.LoadmasteritemDDL(customerid,ref conferenceCallOPs);
            if (oplist.Count > 0)
            {
                dynamic.status = 1;
                dynamic.data = oplist;
                dynamic.item = conferenceCallOPs;
            }
            else
            {
                dynamic.status = -1;
                dynamic.data = oplist;
                dynamic.item = new List<string>(); 
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        /*End*/
        /*Conference call*/
        public GenericResponse Makeconferencecall(ConferenceCallIP conferenceCallIP)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            string ResponseResult = string.Empty;
            ConferenceCallOP rmsg = new ConferenceCallOP();
            VSRRepository vsrr = new VSRRepository();
            string ApiUrl = vsrr.getConnection().GetSection("connectionStrings").GetSection("confcallAPIurl").Value;
            string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(conferenceCallIP);
            try
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                    var response = httpClient.PostAsync(ApiUrl, content).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var ReValue = response.Content.ReadAsStringAsync().Result;

                        //rmsg = Newtonsoft.Json.JsonConvert.DeserializeObject<ConferenceCallOP>(ReValue);
                        if (Convert.ToString(ReValue) == "200 OK")
                        {
                            ResponseResult = Convert.ToString(ReValue);
                            rmsg.Status = "1";
                            rmsg.Message = ResponseResult;
                        }
                        else
                        {
                            rmsg.Status = "-1";
                            rmsg.Message = ResponseResult;
                        }
                        LogWriter("Input :- " + Environment.NewLine + JsonValue + Environment.NewLine + "Output :- " + Environment.NewLine + ResponseResult, "IOLog", 1);
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter("Exception :- " + ex.Message.ToString(), "ErrorLog", 2);
            }

            if (rmsg.Status == "1")
            {
                dynamic.status = 1;
                dynamic.message = ResponseResult;
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = ResponseResult;
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Playaudiofile(Playaudioip playaudioip)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            string ResponseResult = string.Empty;
            ConferenceCallOP rmsg = new ConferenceCallOP();
            VSRRepository vsrr = new VSRRepository();
            string ApiUrl = vsrr.getConnection().GetSection("connectionStrings").GetSection("playaudiopath").Value;
            string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(playaudioip);
            try
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                    var response = httpClient.PostAsync(ApiUrl, content).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var ReValue = response.Content.ReadAsStringAsync().Result;

                        //rmsg = Newtonsoft.Json.JsonConvert.DeserializeObject<ConferenceCallOP>(ReValue);
                        if (Convert.ToString(ReValue) == "200 OK")
                        {
                            ResponseResult = Convert.ToString(ReValue);
                            rmsg.Status = "1";
                            rmsg.Message = ResponseResult;
                        }
                        else
                        {
                            rmsg.Status = "-1";
                            rmsg.Message = ResponseResult;
                        }
                        LogWriter("Input :- " + Environment.NewLine + JsonValue + Environment.NewLine + "Output :- " + Environment.NewLine + ResponseResult, "IOLog", 1);
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter("Exception :- " + ex.Message.ToString(), "ErrorLog", 2);
            }

            if (rmsg.Status == "1")
            {
                dynamic.status = 1;
                dynamic.message = ResponseResult;
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = ResponseResult;
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Stopaudiofile(Stopaudioip stopaudioip)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            string ResponseResult = string.Empty;
            ConferenceCallOP rmsg = new ConferenceCallOP();
            VSRRepository vsrr = new VSRRepository();
            string ApiUrl = vsrr.getConnection().GetSection("connectionStrings").GetSection("stopaudiopath").Value;
            string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(stopaudioip);
            try
            {
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                    var response = httpClient.PostAsync(ApiUrl, content).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var ReValue = response.Content.ReadAsStringAsync().Result;

                        //rmsg = Newtonsoft.Json.JsonConvert.DeserializeObject<ConferenceCallOP>(ReValue);
                        if (Convert.ToString(ReValue) == "200 OK")
                        {
                            ResponseResult = Convert.ToString(ReValue);
                            rmsg.Status = "1";
                            rmsg.Message = ResponseResult;
                        }
                        else
                        {
                            rmsg.Status = "-1";
                            rmsg.Message = ResponseResult;
                        }
                        LogWriter("Input :- " + Environment.NewLine + JsonValue + Environment.NewLine + "Output :- " + Environment.NewLine + ResponseResult, "IOLog", 1);
                    }
                }
            }
            catch (Exception ex)
            {
                LogWriter("Exception :- " + ex.Message.ToString(), "ErrorLog", 2);
            }

            if (rmsg.Status == "1")
            {
                dynamic.status = 1;
                dynamic.message = ResponseResult;
            }
            else
            {
                dynamic.status = -1;
                dynamic.message = ResponseResult;
            }

            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public void LogWriter(string ReceivedValue, string FileName, int Type)
        {
            string LogFile, fileContent, LogPath, curHr;

            curHr = System.DateTime.Now.ToString("HH");
            VSRRepository vsrr = new VSRRepository();
            string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("logpath").Value;
            LogPath = filepath + "/Logs/";
            FileName = FileName.Replace(':', '-');
            if (Type == 1)
            {
                LogPath = LogPath + "/IOLogs/";
                LogFile = LogPath + FileName.Replace('.', '_') + "_" + System.DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
            }
            else
            {
                LogPath = LogPath + "/ErrorLogs/";
                LogFile = LogPath + FileName.Replace('.', '_') + "_" + System.DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
            }
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            StreamWriter sw;

            if (!File.Exists(LogFile))
                using (sw = File.CreateText(LogFile))
                { }
            fileContent = System.DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss.fff") + " : " + ReceivedValue;
            sw = File.AppendText(LogFile);
            sw.WriteLine(fileContent);
            sw.Close();
            fileContent = string.Empty;
        }
        /*End*/

        public GenericResponse GetConsumername(string consumermobile, string customermobile)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            string consumername = "";
            consumername = order.GetConsumername(consumermobile,customermobile,ref consumername);
            dynamic.status = 1;
            dynamic.message = "";
            dynamic.resultset = consumername;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
    }
}
