﻿using MailKit;
using Newtonsoft.Json;
using System.Dynamic;
using VS.Restaurant.Helpers;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository;
using VS.Restaurant.Repository.Interfaces;
using static VS.Restaurant.Helpers.ApiError;

namespace VS.Restaurant.Providers
{
    public class PizzacornerProvider : IPizzacornerProvider
    {
        public readonly IPizzacornerRepository pizzacornerRepository;
        public PizzacornerProvider(IPizzacornerRepository _pizzacornerRepository)
        {
            pizzacornerRepository = _pizzacornerRepository;
        }
        #region Itembase
        public GenericResponse Loadpizzabase(int restraurantid)
        {
            if (string.IsNullOrEmpty(Convert.ToString(restraurantid)) || restraurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                List<LoadmasterbaseRes> loadmasterbaseRes = pizzacornerRepository.Loadpizzabase(restraurantid);
                if (loadmasterbaseRes.Count == 0)
                {
                    dyn.Status = 0;
                    dyn.Resultset = new List<string>();
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = loadmasterbaseRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse Addpizzabase(OperatemasterbaseReq operatemasterbaseReq)
        {
            if (string.IsNullOrEmpty(Convert.ToString(operatemasterbaseReq.Restaurantid)) || operatemasterbaseReq.Restaurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(operatemasterbaseReq.Basename))
            {
                throw new AppException((int)ApiError.Pizzacornererror.basenamecannotbenull, Convert.ToString(ApiError.Pizzacornererror.basenamecannotbenull));
            }
            else if (string.IsNullOrEmpty(operatemasterbaseReq.Basecode))
            {
                throw new AppException((int)ApiError.Pizzacornererror.basecodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.basecodecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(operatemasterbaseReq.Createdby)) || operatemasterbaseReq.Createdby < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.createdbycannotbenull, Convert.ToString(ApiError.Pizzacornererror.createdbycannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                OPRes oPRes = pizzacornerRepository.Addpizzabase(operatemasterbaseReq);
                if (oPRes.Status < 1)
                {
                    oPRes.Status = 0;
                    oPRes.Message = "Unable to add data. Please try again";
                    dyn.Status = 0;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse Updatepizzabase(OperatemasterbaseReq operatemasterbaseReq)
        {
            if (string.IsNullOrEmpty(Convert.ToString(operatemasterbaseReq.Restaurantid)) || operatemasterbaseReq.Restaurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(operatemasterbaseReq.Basename))
            {
                throw new AppException((int)ApiError.Pizzacornererror.basenamecannotbenull, Convert.ToString(ApiError.Pizzacornererror.basenamecannotbenull));
            }
            else if (string.IsNullOrEmpty(operatemasterbaseReq.Basecode))
            {
                throw new AppException((int)ApiError.Pizzacornererror.basecodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.basecodecannotbenull));
            }

            else if (string.IsNullOrEmpty(Convert.ToString(operatemasterbaseReq.Createdby)) || operatemasterbaseReq.Createdby < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.createdbycannotbenull, Convert.ToString(ApiError.Pizzacornererror.createdbycannotbenull));
            }
            else if (operatemasterbaseReq.Baseid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.baseidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.baseidcannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                OPRes oPRes = pizzacornerRepository.Updatepizzabase(operatemasterbaseReq);
                if (oPRes.Status < 1)
                {
                    oPRes.Status = 0;
                    oPRes.Message = "Unable to update data. Please try again";
                    dyn.Status = 0;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse Deletepizzabase(DeletemasterbaseReq operatemasterbaseReq)
        {
            if (string.IsNullOrEmpty(Convert.ToString(operatemasterbaseReq.Restaurantid)) || operatemasterbaseReq.Restaurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }

            else if (string.IsNullOrEmpty(Convert.ToString(operatemasterbaseReq.Createdby)) || operatemasterbaseReq.Createdby < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.createdbycannotbenull, Convert.ToString(ApiError.Pizzacornererror.createdbycannotbenull));
            }
            else if (operatemasterbaseReq.Baseid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.baseidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.baseidcannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                OPRes oPRes = pizzacornerRepository.Deletepizzabase(operatemasterbaseReq);
                if (oPRes.Status < 1)
                {
                    oPRes.Status = 0;
                    oPRes.Message = "Unable to delete data. Please try again";
                    dyn.Status = 0;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        #endregion
        #region Itemtoping
        public GenericResponse LoadpizzaToppings(int restraurantid, int userid)
        {
            if (string.IsNullOrEmpty(Convert.ToString(restraurantid)) || restraurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                List<LoadmastertopingsRes> loadmasterbaseRes = pizzacornerRepository.LoadpizzaToppings(restraurantid, userid);
                if (loadmasterbaseRes.Count == 0)
                {
                    dyn.Status = 0;
                    dyn.Resultset = new List<string>();
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = loadmasterbaseRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse AddpizzaToppings(AddmasttertopingsReq addmasttertopingsReq)
        {
            if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Resturantid)) || addmasttertopingsReq.Resturantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(addmasttertopingsReq.Customeritemcode))
            {
                throw new AppException((int)ApiError.Pizzacornererror.customeritemcodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.customeritemcodecannotbenull));
            }
            else if (string.IsNullOrEmpty(addmasttertopingsReq.Topingname))
            {
                throw new AppException((int)ApiError.Pizzacornererror.topingnamecannotbenull, Convert.ToString(ApiError.Pizzacornererror.topingnamecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Fullprice)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.fullpricecannotbenull, Convert.ToString(ApiError.Pizzacornererror.fullpricecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Halfprice)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.halfpricecannotbenull, Convert.ToString(ApiError.Pizzacornererror.halfpricecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Createdby)) || addmasttertopingsReq.Createdby < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.createdbycannotbenull, Convert.ToString(ApiError.Pizzacornererror.createdbycannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                OPRes oPRes = pizzacornerRepository.AddpizzaToppings(addmasttertopingsReq);
                if (oPRes.Status < 1)
                {
                    oPRes.Status = 0;
                    oPRes.Message = "Unable to add data. Please try again";
                    dyn.Status = 0;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse UpdatepizzaToppings(UpdatemasttertopingsReq addmasttertopingsReq)
        {
            if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Resturantid)) || addmasttertopingsReq.Resturantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(addmasttertopingsReq.Customeritemcode))
            {
                throw new AppException((int)ApiError.Pizzacornererror.customeritemcodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.customeritemcodecannotbenull));
            }
            else if (string.IsNullOrEmpty(addmasttertopingsReq.Topingname))
            {
                throw new AppException((int)ApiError.Pizzacornererror.topingnamecannotbenull, Convert.ToString(ApiError.Pizzacornererror.topingnamecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Fullprice)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.fullpricecannotbenull, Convert.ToString(ApiError.Pizzacornererror.fullpricecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Halfprice)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.halfpricecannotbenull, Convert.ToString(ApiError.Pizzacornererror.halfpricecannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Createdby)) || addmasttertopingsReq.Createdby < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.createdbycannotbenull, Convert.ToString(ApiError.Pizzacornererror.createdbycannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(addmasttertopingsReq.Topingid)) || addmasttertopingsReq.Topingid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.topingidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.topingidcannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                OPRes oPRes = pizzacornerRepository.UpdatepizzaToppings(addmasttertopingsReq);
                if (oPRes.Status < 1)
                {
                    oPRes.Status = 0;
                    oPRes.Message = "Unable to update data. Please try again";
                    dyn.Status = 0;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse DeletepizzaToppings(int restraurantid, int userid, Int64 topingid)
        {
            if (string.IsNullOrEmpty(Convert.ToString(restraurantid)) || restraurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(userid)) || userid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.createdbycannotbenull, Convert.ToString(ApiError.Pizzacornererror.createdbycannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(topingid)) || topingid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.topingidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.topingidcannotbenull));
            }
            else
            {
                GenericResponse genericResponse = new();
                dynamic dyn = new ExpandoObject();
                OPRes oPRes = pizzacornerRepository.DeletepizzaToppings(restraurantid, userid, topingid);
                if (oPRes.Status < 1)
                {
                    oPRes.Status = 0;
                    oPRes.Message = "Unable to delete data. Please try again";
                    dyn.Status = 0;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                else
                {
                    dyn.Status = 1;
                    dyn.Resultset = oPRes;
                    genericResponse.Data = dyn;
                }
                return genericResponse;
            }
            throw new AppException();
        }
        #endregion
        #region Itemmaster
        public GenericResponse AddItemmaster(Addmasterpizzafromdata addmasterfromdata)
        {
            if (string.IsNullOrEmpty(Convert.ToString(addmasterfromdata.Itemdata)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                GenericResponse genericResponse = new GenericResponse();
                dynamic dynamic = new ExpandoObject();
                try
                {
                    string URL = "";
                    string audioURL = "";
                    VSRRepository vsrr = new VSRRepository();
                    string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                    string audiopath = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioPath").Value;
                    string withextension = vsrr.getConnection().GetSection("connectionStrings").GetSection("withextension").Value;
                    // Getting Image
                    var image = addmasterfromdata.Filename;
                    var audio = addmasterfromdata.Audiofile;
                    // Saving Image on Server
                    AddmasterpizzaValues objContact = new AddmasterpizzaValues();
                    var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                    objContact = JsonConvert.DeserializeObject<AddmasterpizzaValues>(contactdata);
                    StreamWriter sw;

                    if (image != null)
                    {
                        URL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                        filepath = filepath + URL;
                        using var fileStream = new FileStream(filepath, FileMode.Create);
                        image.CopyTo(fileStream);


                    }
                    if (audio != null)
                    {
                        audioURL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + Path.GetFileNameWithoutExtension(audio.FileName);
                        if (withextension == "1")
                            audioURL += Path.GetExtension(audio.FileName);
                        audiopath += audioURL;
                        using var fileStream = new FileStream(audiopath, FileMode.Create);
                        audio.CopyTo(fileStream);

                    }
                    objContact.imagepath = URL;
                    objContact.Audiofile = audioURL;

                    defalutresultsets = pizzacornerRepository.AddItemmaster(objContact);
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
                catch (Exception ex)
                {
                    defalutresultsets[0].Message = ex.Message.ToString();
                    defalutresultsets[0].Status = -1;
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
            }
            throw new AppException();
        }
        public GenericResponse LoadItemmaster(LoadmasterpizzaValues loadmasterValues)
        {
            if (string.IsNullOrEmpty(Convert.ToString(loadmasterValues.Customerid)) || loadmasterValues.Customerid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.customeritemcodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.customeritemcodecannotbenull));
            }
            else
            {
                List<LoadmasterpizzaResultset> loadmasterResultsets = new List<LoadmasterpizzaResultset>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();
                Int32 totalrow = 0;
                loadmasterResultsets = pizzacornerRepository.LoadItemmaster(loadmasterValues, ref totalrow);
                dynamic.data = loadmasterResultsets;
                dynamic.totalrow = totalrow;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse EditItemmaster(Addmasterpizzafromdata addmasterfromdata)
        {
            if (string.IsNullOrEmpty(Convert.ToString(addmasterfromdata.Itemdata)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                GenericResponse genericResponse = new GenericResponse();
                dynamic dynamic = new ExpandoObject();
                try
                {
                    string URL = "";
                    string audioURL = "";
                    VSRRepository vsrr = new VSRRepository();
                    string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                    string audiopath = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioPath").Value;
                    // Getting Image
                    var image = addmasterfromdata.Filename;
                    var audio = addmasterfromdata.Audiofile;
                    // Saving Image on Server
                    EditmasterpizzaValues objContact = new EditmasterpizzaValues();
                    var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                    objContact = JsonConvert.DeserializeObject<EditmasterpizzaValues>(contactdata);

                    if (image != null)
                    {
                        URL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                        filepath = filepath + "\\" + URL;

                        using (var fileStream = new FileStream(filepath, FileMode.Create))
                        {
                            image.CopyTo(fileStream);
                        }
                    }
                    if (audio != null)
                    {
                        audioURL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + Path.GetFileNameWithoutExtension(audio.FileName) + Path.GetExtension(audio.FileName);
                        audiopath = audiopath + "\\" + audioURL;

                        using var fileStream = new FileStream(audiopath, FileMode.Create);
                        audio.CopyTo(fileStream);

                    }

                    objContact.Imagepath = URL;
                    objContact.Audiofile = audioURL;

                    defalutresultsets = pizzacornerRepository.EditItemmaster(objContact);
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
                catch (Exception ex)
                {

                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
            }
            throw new AppException();
        }
        public GenericResponse DeleteItemmaster(DeletemasterpizzaValues deletemasterValues)
        {
            if (string.IsNullOrEmpty(Convert.ToString(deletemasterValues.Customerid)) || deletemasterValues.Customerid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(deletemasterValues.Itemcode)) || deletemasterValues.Itemcode < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();
                defalutresultsets = pizzacornerRepository.DeleteItemmaster(deletemasterValues);
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        #endregion
        #region Itempackage
        public GenericResponse AddItempackagepizza(Addmasterpizzafromdata addmasterfromdata)
        {
            if (string.IsNullOrEmpty(addmasterfromdata.Itemdata))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            //else if (string.IsNullOrEmpty(Convert.ToString(addmasterfromdata.Filename)))
            //{

            //}
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                GenericResponse genericResponse = new GenericResponse();
                dynamic dynamic = new ExpandoObject();
                try
                {
                    string URL = "";
                    VSRRepository vsrr = new VSRRepository();
                    string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                    // Getting Image
                    var image = addmasterfromdata.Filename;
                    // Saving Image on Server
                    AddpackageitempizzaValues objContact = new AddpackageitempizzaValues();
                    var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                    objContact = JsonConvert.DeserializeObject<AddpackageitempizzaValues>(contactdata);

                    if (image != null)
                    {
                        URL = objContact.Customerid + "_" + objContact.Masteritem + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                        filepath = filepath + "\\" + URL;

                        using (var fileStream = new FileStream(filepath, FileMode.Create))
                        {
                            image.CopyTo(fileStream);
                        }
                    }
                    objContact.Imagepath = URL;

                    defalutresultsets = pizzacornerRepository.AddItempackagepizza(objContact);
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;

                }
                catch (Exception ex)
                {

                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
            }
            throw new AppException();
        }
        public GenericResponse LoadItempackagepizza(LoadpackagepizzaValues loadpackageValues)
        {
            if (string.IsNullOrEmpty(Convert.ToString(loadpackageValues.Customerid)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.customeritemcodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.customeritemcodecannotbenull));
            }
            else
            {
                List<LoadpackagepizzaResultset> loadpackageResultsets = new List<LoadpackagepizzaResultset>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();
                Int32 totalrow = 0;
                loadpackageResultsets = pizzacornerRepository.LoadItempackagepizza(loadpackageValues, ref totalrow);
                dynamic.data = loadpackageResultsets;
                dynamic.totalrow = totalrow;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse EditItempackagepizza(Addmasterpizzafromdata addmasterfromdata)//EditpackageValues editpackageValues
        {
            if (string.IsNullOrEmpty(addmasterfromdata.Itemdata))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                GenericResponse genericResponse = new GenericResponse();
                dynamic dynamic = new ExpandoObject();
                try
                {
                    string URL = "";
                    VSRRepository vsrr = new VSRRepository();
                    string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                    // Getting Image
                    var image = addmasterfromdata.Filename;
                    // Saving Image on Server
                    EditpackagepizzaValues objContact = new EditpackagepizzaValues();
                    var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                    objContact = JsonConvert.DeserializeObject<EditpackagepizzaValues>(contactdata);

                    if (image != null)
                    {
                        URL = objContact.Customerid + "_" + objContact.Masteritem + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                        filepath = filepath + "\\" + URL;

                        using (var fileStream = new FileStream(filepath, FileMode.Create))
                        {
                            image.CopyTo(fileStream);
                        }
                    }
                    objContact.Imagepath = URL;

                    defalutresultsets = pizzacornerRepository.EditItempackagepizza(objContact);
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;

                }
                catch (Exception ex)
                {

                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
            }
            throw new AppException();
        }
        public GenericResponse DeleteItempackagepizza(DeletepackagepizzaValues deletepackageValues)
        {
            if (string.IsNullOrEmpty(Convert.ToString(deletepackageValues.Customerid)) || deletepackageValues.Customerid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.customeritemcodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.customeritemcodecannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();
                defalutresultsets = pizzacornerRepository.DeleteItempackagepizza(deletepackageValues);
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        #endregion
        #region Itemdata
        public GenericResponse Loaditeminfo(Int64 itemcode)
        {
            if (string.IsNullOrEmpty(Convert.ToString(itemcode)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemcodecannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemcodecannotbenull));
            }
            else
            {
                List<itemdatares> loadpackageResultsets = new List<itemdatares>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();

                loadpackageResultsets = pizzacornerRepository.Loaditeminfo(itemcode);
                dynamic.data = loadpackageResultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        #endregion
        #region Itemtypeddl
        public GenericResponse Loaditemtypeddl(Int64 restaurantid)
        {
            if (string.IsNullOrEmpty(Convert.ToString(restaurantid)) || restaurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else
            {
                List<Loaditemtyperes> loadpackageResultsets = new List<Loaditemtyperes>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();

                loadpackageResultsets = pizzacornerRepository.Loaditemtypeddl(restaurantid);
                dynamic.data = loadpackageResultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        public GenericResponse Loaditemnameddl(Int64 restaurantid, Int64 itemtype)
        {
            if (string.IsNullOrEmpty(Convert.ToString(restaurantid)) || restaurantid < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.resturantidcannotbenull, Convert.ToString(ApiError.Pizzacornererror.resturantidcannotbenull));
            }
            else if (string.IsNullOrEmpty(Convert.ToString(itemtype)) || itemtype < 1)
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemtypecannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemtypecannotbenull));
            }
            else
            {
                List<Loaditemnameres> loadpackageResultsets = new List<Loaditemnameres>();
                dynamic dynamic = new ExpandoObject();
                GenericResponse genericResponse = new GenericResponse();

                loadpackageResultsets = pizzacornerRepository.Loaditemnameddl(restaurantid, itemtype);
                dynamic.data = loadpackageResultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
            throw new AppException();
        }
        #endregion
        

    }
}
