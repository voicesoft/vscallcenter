﻿using Newtonsoft.Json;
using Org.BouncyCastle.Ocsp;
using System.Collections.Generic;
using System.Dynamic;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using VS.Restaurant.Helpers;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Providers
{
    public class BALCallStatus : ICallStatusUpdateBase
    {
        private readonly ICallStatus callStatus;

        public BALCallStatus(ICallStatus _callStatus)
        {
            callStatus = _callStatus;
        }
        public GenericResponse UpdateQueueLogs(ReqQueueLog reqQueueLog)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            DefaultResponse _defaultResponse = new DefaultResponse();
            _defaultResponse = callStatus.UpdateQueueLogs(reqQueueLog);
            string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(reqQueueLog);
            LogWriter("Input QueueLogs :- " + Environment.NewLine + JsonValue + Environment.NewLine + "Output :- " + Environment.NewLine + _defaultResponse.Message, "UpdateQueueLogs", 1);
            dynamic.status = _defaultResponse.Status;
            dynamic.message = _defaultResponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse AgentCallStatus(LiveAgents _req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            DefaultResponse _defaultResponse = new DefaultResponse();
            _defaultResponse = callStatus.AgentCallStatus(_req);
            dynamic.status = _defaultResponse.Status;
            dynamic.message = _defaultResponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }

        public GenericResponse AgentStausUpdate(AgentStatusUpdate _req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            DefaultResponse _defaultResponse = new DefaultResponse();
            _defaultResponse = callStatus.AgentStausUpdate(_req);
            dynamic.status = _defaultResponse.Status;
            dynamic.message = _defaultResponse.Message;
           

            List<AgentStatusResultset> lstLanguage = new List<AgentStatusResultset>();
            lstLanguage = callStatus.GetLanguage(_req.AgentId);
            VSRRepository vsrr = new VSRRepository();
            string ApiUrl = vsrr.getConnection().GetSection("connectionStrings").GetSection("agentstatusAPIurl").Value;
            string lstresponse = "";
            for (int icurrentRow = 0; icurrentRow < lstLanguage.Count; icurrentRow++)
            {
                reqqueue reqmsg = new reqqueue();
                reqmsg.member = _req.Extension;
                reqmsg.queuename = lstLanguage[icurrentRow].Languagelist;
                if(_req.Registered.ToLower()=="connected")
                {
                    reqmsg.value = "1";
                }
                else
                {
                    reqmsg.value = "-1";
                }
                string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(reqmsg);
                try
                {
                    using (var httpClient = new HttpClient())
                    {
                        StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                        var response = httpClient.PostAsync(ApiUrl, content).Result;
                        if (response.IsSuccessStatusCode)
                        {
                            var ReValue = response.Content.ReadAsStringAsync().Result;
                            lstresponse = lstresponse +"-"+ reqmsg.queuename + ":" + ReValue + ",";
                            if (Convert.ToString(ReValue) == "200 OK")
                            {
                                
                            } 
                        }
                        else
                        {
                            var ReValue = response.Content.ReadAsStringAsync().Result;
                            lstresponse = reqmsg.queuename + ":" + lstresponse + ReValue + ",";
                        }
                    }
                }
                catch(Exception ex)
                {
                    lstresponse = lstresponse + ex.Message;
                }               
            }
            dynamic.queue = lstresponse;
            genericResponse.Data = dynamic;
            return genericResponse;
        }        
        public void LogWriter(string ReceivedValue, string FileName, int Type)
        {
            string LogFile, fileContent, LogPath, curHr;

            curHr = System.DateTime.Now.ToString("HH");
            VSRRepository vsrr = new VSRRepository();
            string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("logpath").Value;
            LogPath = filepath + "/Logs/";
            FileName = FileName.Replace(':', '-');
            if (Type == 1)
            {
                LogPath = LogPath + "/UpdateCallLogs/";
                LogFile = LogPath + FileName.Replace('.', '_') + "_" + System.DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
            }
            else
            {
                LogPath = LogPath + "/ErrorLogs/";
                LogFile = LogPath + FileName.Replace('.', '_') + "_" + System.DateTime.Now.ToString("yyyy_MM_dd") + ".txt";
            }
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            StreamWriter sw;

            if (!File.Exists(LogFile))
                using (sw = File.CreateText(LogFile))
                { }
            fileContent = System.DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss.fff") + " : " + ReceivedValue;
            sw = File.AppendText(LogFile);
            sw.WriteLine(fileContent);
            sw.Close();
            fileContent = string.Empty;
        }
        public GenericResponse GetorSetAgentData(IncomingCall _req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            AllocatedExtension allocatedExtension = new AllocatedExtension();
            allocatedExtension = callStatus.GetorSetAgentData(_req);
            dynamic.Extension = allocatedExtension.Extension;
            dynamic.Record = allocatedExtension.Record;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse GetorSetAgenQueueData(IncomingCall _req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            AllocatedExtension allocatedExtension = new AllocatedExtension();
            allocatedExtension = callStatus.GetorSetAgenQueueData(_req);
            dynamic.Extension = allocatedExtension.Extension;
            dynamic.Record = allocatedExtension.Record;
            dynamic.Manager = allocatedExtension.Manager;
            dynamic.Queue = allocatedExtension.Queue;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        //public GenericResponse UpdateCallLog(CallLog req)
        //{
        //    dynamic dynamic = new ExpandoObject();
        //    GenericResponse genericResponse = new GenericResponse();
        //    DefaultResponse _defaultResponse = new DefaultResponse();
        //    _defaultResponse = callStatus.UpdateCallLog(req);
        //    dynamic.status = _defaultResponse.Status;
        //    dynamic.message = _defaultResponse.Message;
        //    genericResponse.Data = dynamic;
        //    return genericResponse;
        //}
        public GenericResponse UpdateCallLog(CallLog req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            DefaultResponse _defaultResponse = new DefaultResponse();
            _defaultResponse = callStatus.UpdateCallLog(req);
            VSRRepository vsrr = new VSRRepository();
            string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(req);
            try
            {
                    if (_defaultResponse.Status == 1)
                    {
                     dynamic.status = 1;
                     dynamic.message = _defaultResponse.Message;
                    }
                    else
                    {
                     dynamic.status = -1;
                     dynamic.message = _defaultResponse.Message;
                     }
                     LogWriter("Input :- " + Environment.NewLine + JsonValue + Environment.NewLine + "Output :- " + Environment.NewLine + _defaultResponse.Message, "UpdateCallLog", 1);
                
            }
            catch (Exception ex)
            {
                LogWriter("Exception :- " + ex.Message.ToString(), "ErrorLog", 2);
            }
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public AudioData UpdateTrainingCallLog(TCallLog req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            AudioData _defaultResponse = new AudioData();
            _defaultResponse = callStatus.UpdateTrainingCallLog(req);
            return _defaultResponse;
        }        
        public GenericResponse UpdateCurrentAgentStatus(List<AgentList> _req)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            DefaultResponse _defaultResponse = new DefaultResponse();
            _defaultResponse = callStatus.UpdateCurrentAgentStatus(_req);
            dynamic.status = _defaultResponse.Status;
            dynamic.message = _defaultResponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse InitiateTraining(RequestStartStop requestStartStop)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            AudioData _defaultResponse = new AudioData();
            _defaultResponse = callStatus.InitiateTraining(requestStartStop);

            try
            {
                string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(_defaultResponse);
                VSRRepository vsrr = new VSRRepository();
                string ApiUrl = vsrr.getConnection().GetSection("connectionStrings").GetSection("playaudiopath").Value;
                using (var httpClient = new HttpClient())
                {
                    StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                    var response = httpClient.PostAsync(ApiUrl, content).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        var ReValue = response.Content.ReadAsStringAsync().Result;
                      
                        if (Convert.ToString(ReValue) == "200 OK")
                        {

                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
            dynamic.status = 1;
            dynamic.message = "Success";
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Loadcompany()
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            List<Companyddl> loginRes = callStatus.Loadcompany();
            if (loginRes == null)
            {
                return genericResponse;
            }
            else
            {
                if (loginRes.Count > 0)
                {
                    if (loginRes[0].Restaurantid > 0)
                    {
                        dynamic.status = 1;
                        dynamic.message = "success";
                        dynamic.resultset = loginRes;
                        genericResponse.Data = dynamic;
                    }
                    else
                    {
                        dynamic.status = 0;
                        dynamic.message = "No Records Found...!";
                        dynamic.resultset = new List<string>();
                        genericResponse.Data = dynamic;
                    }
                }
                else
                {
                    dynamic.status = -1;
                    dynamic.message = "No Records Found...!";
                    dynamic.resultset = new List<string>();
                    genericResponse.Data = dynamic;
                }
                return genericResponse;
            }
        }
        public GenericResponse Uploadaudio(ReqUploadTrainingAudio requploadaudio)
        {
            if (string.IsNullOrEmpty(Convert.ToString(requploadaudio.Itemdata)))
            {
                throw new AppException((int)ApiError.Pizzacornererror.itemdatacannotbenull, Convert.ToString(ApiError.Pizzacornererror.itemdatacannotbenull));
            }
            else
            {
                List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
                GenericResponse genericResponse = new GenericResponse();
                dynamic dynamic = new ExpandoObject();
                try
                {
                    string URL = "";
                    string audioURL = "";
                    string audioURLWithExtension = "";
                    VSRRepository vsrr = new VSRRepository();
                    string audiopath = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioPath").Value;
                    string withextension = vsrr.getConnection().GetSection("connectionStrings").GetSection("withextension").Value;
                    string audiouploadurl = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioupload").Value;
                    string audiodownload = vsrr.getConnection().GetSection("connectionStrings").GetSection("audiodownload").Value;
                    string audioconversionurl = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioconversion").Value;
                    var audio = requploadaudio.Audiofile;

                    AddReqUploadTrainingAudio objContact = new AddReqUploadTrainingAudio();
                    var contactdata = Convert.ToString(requploadaudio.Itemdata);
                    objContact = JsonConvert.DeserializeObject<AddReqUploadTrainingAudio>(contactdata);
                    StreamWriter sw;

                    if (audio != null)
                    {
                        audioURL = Path.GetFileNameWithoutExtension(audio.FileName);
                        audioURLWithExtension = Path.GetFileNameWithoutExtension(audio.FileName);
                        if (withextension == "1")
                        audioURLWithExtension += Path.GetExtension(audio.FileName);
                        audiopath += audioURLWithExtension;
                        using var fileStream = new FileStream(audiopath, FileMode.Create);
                        audio.CopyTo(fileStream);
                    }
                    objContact.Audiofile = audioURL;
                    objContact.Audiofilewithextension = audioURLWithExtension;
                    defalutresultsets = callStatus.Uploadaudio(objContact);

                    try
                    {
                        AudioUpload audioUpload = new AudioUpload();
                        audioUpload.link= audiodownload + audioURLWithExtension;
                        audioUpload.filename = audioURLWithExtension;
                        string JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(audioUpload); 
                        using (var httpClient = new HttpClient())
                        {
                            StringContent content = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                            var response = httpClient.PostAsync(audiouploadurl, content).Result;
                            if (response.IsSuccessStatusCode)
                            {
                                    AudioConvert audioConvert = new AudioConvert();
                                    audioConvert.current = audioURL;
                                    audioConvert.convert = audioURL;
                                    audioConvert.format = System.IO.Path.GetExtension(audioURLWithExtension);
                                    audioConvert.cformat = ".wav";
                                    using (var httpWebClient = new HttpClient())
                                    {
                                    JsonValue = Newtonsoft.Json.JsonConvert.SerializeObject(audioConvert);
                                    StringContent Webcontent = new StringContent(JsonValue, Encoding.UTF8, "application/json");
                                        var webresponse = httpWebClient.PostAsync(audioconversionurl, Webcontent).Result;
                                        if (webresponse.IsSuccessStatusCode)
                                        {
                                        }
                                    }
                            }
                        }
                    }
                    catch
                    {

                    }
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
                catch (Exception ex)
                {
                    defalutresultsets[0].Message = ex.Message.ToString();
                    defalutresultsets[0].Status = -1;
                    dynamic.data = defalutresultsets;
                    genericResponse.Data = dynamic;
                    return genericResponse;
                }
            }
            throw new AppException();
        }
        public GenericResponse Loadallaudio(LoadcompanyInput loadcompanyInput)
        {
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            int totalrow = 0;
            List<Loadallaudioop> defaultresultset = callStatus.Loadallaudio(loadcompanyInput, ref totalrow);
            dynamic.totalrow = totalrow;
            dynamic.resultset = defaultresultset;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse Deleteaudiofile(DeleteaudiofileIP deleteaudiofileValues)
        {
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            Defalutresultset _defaultResponse = new Defalutresultset();
            _defaultResponse = callStatus.Deleteaudiofile(deleteaudiofileValues);
            dynamic.status = _defaultResponse.Status;
            dynamic.message = _defaultResponse.Message;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
    }

}
