﻿using Newtonsoft.Json;
using System.Dynamic;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository;

namespace VS.Restaurant.Providers
{
    public class VSRProvder : VSRProviderInterface
    {
        private readonly VSRRepositoryInterface vSRRepositoryInterface;
        public VSRProvder(VSRRepositoryInterface _vSRRepositoryInterface)
        {
            vSRRepositoryInterface = _vSRRepositoryInterface;
        }

        public GenericResponse ValidateLogin(LoginValues loginValues)
        {
            List<LoginResultset> loginResultsets = new List<LoginResultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            loginResultsets = vSRRepositoryInterface.ValidateLogin(loginValues);
            dynamic.data = loginResultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse ValidateagentLogin(Agentloign agentloign)
        {
            Agentloignresut loginResultsets = new Agentloignresut();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            loginResultsets = vSRRepositoryInterface.ValidateagentLogin(agentloign);
            dynamic.resultSet = loginResultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #region Itemtype
        public GenericResponse AddItemtype(AdditemValues additemValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.AddItemtype(additemValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse LoadItemtype(LoaditemValues loaditemValues)
        {
            List<LoaditemResultset> loaditemResultsets = new List<LoaditemResultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            Int32 totalrow = 0;
            loaditemResultsets = vSRRepositoryInterface.LoadItemtype(loaditemValues, ref totalrow);
            dynamic.data = loaditemResultsets;
            dynamic.totalrow = totalrow;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse EditItemtype(EdititemValues edititemValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.EditItemtype(edititemValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse DeleteItemtype(DeleteitemValues deleteitemValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.DeleteItemtype(deleteitemValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #endregion
        #region Itemsize
        public GenericResponse AddItemsize(AddsizeValues addsizeValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.AddItemsize(addsizeValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse LoadItemsize(LoadsizeValues loadsizeValues)
        {
            List<LoadsizeResultset> loadsizeResultsets = new List<LoadsizeResultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            Int32 totalrow = 0;
            loadsizeResultsets = vSRRepositoryInterface.LoadItemsize(loadsizeValues, ref totalrow);
            dynamic.data = loadsizeResultsets;
            dynamic.totalrow = totalrow;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse EditItemsize(EditsizeValues editsizeValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.EditItemsize(editsizeValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse DeleteItemsize(DeletesizeValues deletesizeValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.DeleteItemsize(deletesizeValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #endregion
        #region Itemmaster
        public GenericResponse AddItemmaster(Addmasterfromdata addmasterfromdata)
        {
            //List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            //dynamic dynamic = new ExpandoObject();
            //GenericResponse genericResponse = new GenericResponse();
            //defalutresultsets = vSRRepositoryInterface.AddItemmaster(addmasterValues);
            //dynamic.data = defalutresultsets;
            //genericResponse.Data = dynamic;
            //return genericResponse;
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            try
            {
                string URL = "";
                string audioURL = "";
                VSRRepository vsrr = new VSRRepository();
                string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                string audiopath = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioPath").Value;
                // Getting Image
                var image = addmasterfromdata.Filename;
                var audio = addmasterfromdata.Audiofile;
                // Saving Image on Server
                AddmasterValues objContact = new AddmasterValues();
                var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                objContact = JsonConvert.DeserializeObject<AddmasterValues>(contactdata);
                StreamWriter sw;

                if (image != null)
                {
                    URL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                    filepath = filepath +  URL;
                    using var fileStream = new FileStream(filepath, FileMode.Create);
                    image.CopyTo(fileStream);


                }
                if (audio != null)
                {
                    audioURL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + Path.GetFileNameWithoutExtension(audio.FileName) + Path.GetExtension(audio.FileName);
                    audiopath = audiopath + audioURL;

                    using var fileStream = new FileStream(audiopath, FileMode.Create);
                    audio.CopyTo(fileStream);

                }
                objContact.imagepath = URL;
                objContact.Audiofile = audioURL;

                defalutresultsets = vSRRepositoryInterface.AddItemmaster(objContact);
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
                //if (resultOPs.Count > 0)
                //{
                //    dyn.status = 1;
                //    dyn.message = "success";
                //    dyn.result = resultOPs;
                //}
                //else
                //{
                //    dyn.status = 0;
                //    dyn.message = "Unable to add Invoice.";
                //    dyn.result = resultOPs;
                //}
                //genericResponse.data = dyn;
                //return genericResponse;
            }
            catch (Exception ex)
            {
                defalutresultsets[0].Message = ex.Message.ToString();
                defalutresultsets[0].Status = -1;
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
        }
        public GenericResponse LoadItemmaster(LoadmasterValues loadmasterValues)
        {
            List<LoadmasterResultset> loadmasterResultsets = new List<LoadmasterResultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            Int32 totalrow = 0;
            loadmasterResultsets = vSRRepositoryInterface.LoadItemmaster(loadmasterValues, ref totalrow);
            dynamic.data = loadmasterResultsets;
            dynamic.totalrow = totalrow;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse EditItemmaster(Addmasterfromdata addmasterfromdata)
        {
            //List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            //dynamic dynamic = new ExpandoObject();
            //GenericResponse genericResponse = new GenericResponse();
            //defalutresultsets = vSRRepositoryInterface.EditItemmaster(editmasterValues);
            //dynamic.data = defalutresultsets;
            //genericResponse.Data = dynamic;
            //return genericResponse;
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            try
            {
                string URL = "";
                string audioURL = "";
                VSRRepository vsrr = new VSRRepository();
                string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                string audiopath = vsrr.getConnection().GetSection("connectionStrings").GetSection("audioPath").Value;
                // Getting Image
                var image = addmasterfromdata.Filename;
                var audio = addmasterfromdata.Audiofile;
                // Saving Image on Server
                EditmasterValues objContact = new EditmasterValues();
                var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                objContact = JsonConvert.DeserializeObject<EditmasterValues>(contactdata);

                if (image != null)
                {
                    URL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                    filepath = filepath + "\\" + URL;

                    using (var fileStream = new FileStream(filepath, FileMode.Create))
                    {
                        image.CopyTo(fileStream);
                    }
                }
                if (audio != null)
                {
                    audioURL = objContact.Customerid + "_" + objContact.Customeritemcode + "_" + Path.GetFileNameWithoutExtension(audio.FileName) + Path.GetExtension(audio.FileName);
                    audiopath = audiopath + "\\" + audioURL;

                    using var fileStream = new FileStream(audiopath, FileMode.Create);
                    audio.CopyTo(fileStream);

                }
                
                objContact.Imagepath = URL;
                objContact.Audiofile = audioURL;

                defalutresultsets = vSRRepositoryInterface.EditItemmaster(objContact);
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
                //if (resultOPs.Count > 0)
                //{
                //    dyn.status = 1;
                //    dyn.message = "success";
                //    dyn.result = resultOPs;
                //}
                //else
                //{
                //    dyn.status = 0;
                //    dyn.message = "Unable to add Invoice.";
                //    dyn.result = resultOPs;
                //}
                //genericResponse.data = dyn;
                //return genericResponse;
            }
            catch (Exception ex)
            {

                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
        }
        public GenericResponse DeleteItemmaster(DeletemasterValues deletemasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.DeleteItemmaster(deletemasterValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #endregion
        #region Itemprice
        public GenericResponse AddItemprice(AddpriceValues addpriceValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.AddItemprice(addpriceValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse LoadItemprice(LoadpriceValues loadpriceValues)
        {
            List<LoadpriceResultset> loadpriceResultsets = new List<LoadpriceResultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            Int32 totalrow = 0;
            loadpriceResultsets = vSRRepositoryInterface.LoadItemprice(loadpriceValues, ref totalrow);
            dynamic.data = loadpriceResultsets;
            dynamic.totalrow = totalrow;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse EditItemprice(EditpriceValues editpriceValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.EditItemprice(editpriceValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse DeleteItemprice(DeletepriceValues deletepriceValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.DeleteItemprice(deletepriceValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #endregion
        #region Itempackage
        public GenericResponse AddItempackage(Addmasterfromdata addmasterfromdata)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            try
            {
                string URL = "";
                VSRRepository vsrr = new VSRRepository();
                string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                // Getting Image
                var image = addmasterfromdata.Filename;
                // Saving Image on Server
                AddpackageitemValues objContact = new AddpackageitemValues();
                var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                objContact = JsonConvert.DeserializeObject<AddpackageitemValues>(contactdata);

                if (image != null)
                {
                    URL = objContact.Customerid + "_" + objContact.Masteritem + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                    filepath = filepath + "\\" + URL;

                    using (var fileStream = new FileStream(filepath, FileMode.Create))
                    {
                        image.CopyTo(fileStream);
                    }
                }
                objContact.Imagepath = URL;

                defalutresultsets = vSRRepositoryInterface.AddItempackage(objContact);
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;

            }
            catch (Exception ex)
            {

                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
        }
        public GenericResponse LoadItempackage(LoadpackageValues loadpackageValues)
        {
            List<LoadpackageResultset> loadpackageResultsets = new List<LoadpackageResultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            Int32 totalrow = 0;
            loadpackageResultsets = vSRRepositoryInterface.LoadItempackage(loadpackageValues, ref totalrow);
            dynamic.data = loadpackageResultsets;
            dynamic.totalrow = totalrow;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        public GenericResponse EditItempackage(Addmasterfromdata addmasterfromdata)//EditpackageValues editpackageValues
        {
            /*List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.EditItempackage(editpackageValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;*/
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            GenericResponse genericResponse = new GenericResponse();
            dynamic dynamic = new ExpandoObject();
            try
            {
                string URL = "";
                VSRRepository vsrr = new VSRRepository();
                string filepath = vsrr.getConnection().GetSection("connectionStrings").GetSection("imagepath").Value;
                // Getting Image
                var image = addmasterfromdata.Filename;
                // Saving Image on Server
                EditpackageValues objContact = new EditpackageValues();
                var contactdata = Convert.ToString(addmasterfromdata.Itemdata);
                objContact = JsonConvert.DeserializeObject<EditpackageValues>(contactdata);

                if (image != null)
                {
                    URL = objContact.Customerid + "_" + objContact.Masteritem + "_" + DateTime.Now.ToString("yyyyMMddHHMMSS") + "_" + Path.GetFileNameWithoutExtension(image.FileName) + Path.GetExtension(image.FileName);
                    filepath = filepath + "\\" + URL;

                    using (var fileStream = new FileStream(filepath, FileMode.Create))
                    {
                        image.CopyTo(fileStream);
                    }
                }
                objContact.Imagepath = URL;

                defalutresultsets = vSRRepositoryInterface.EditItempackage(objContact);
                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;

            }
            catch (Exception ex)
            {

                dynamic.data = defalutresultsets;
                genericResponse.Data = dynamic;
                return genericResponse;
            }
        }
        public GenericResponse DeleteItempackage(DeletepackageValues deletepackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            dynamic dynamic = new ExpandoObject();
            GenericResponse genericResponse = new GenericResponse();
            defalutresultsets = vSRRepositoryInterface.DeleteItempackage(deletepackageValues);
            dynamic.data = defalutresultsets;
            genericResponse.Data = dynamic;
            return genericResponse;
        }
        #endregion
    }
}
