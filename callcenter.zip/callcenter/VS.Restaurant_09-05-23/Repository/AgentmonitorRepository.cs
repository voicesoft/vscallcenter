﻿using Npgsql;
using Org.BouncyCastle.Ocsp;
using System.Data;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Repository
{
    public class AgentmonitorRepository : DbConfig, IAgentmonitorRepository
    {
        public List<LoginRes> Validatelogin(LoginReq loginReq)
        {
            List<LoginRes> loginReslist = new List<LoginRes>();
            LoginRes loginRes = new LoginRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.validateagentmonitorlogin", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_username", NpgsqlTypes.NpgsqlDbType.Varchar, loginReq.Username ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userpassword", NpgsqlTypes.NpgsqlDbType.Varchar, loginReq.Userpassword ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        loginRes.Userid = Convert.ToInt32(dataReader["o_agentid"]);
                        loginRes.Agentname = Convert.ToString(dataReader["o_agentid"]);
                        loginRes.Username = Convert.ToString(dataReader["o_username"]);
                        loginRes.Usermobile = Convert.ToString(dataReader["o_usermobile"]);
                        loginRes.Userpassword = Convert.ToString(dataReader["o_userpassword"]);
                        loginRes.Userrole = Convert.ToString(dataReader["o_userrole"]);
                        loginRes.Reportmanager = Convert.ToInt32(dataReader["o_reportmanager"]);
                        loginReslist.Add(loginRes);
                        break;
                    }
                }
            }
            return loginReslist;
        }
        public List<LoadagentstatusRes> Loadagentcallstatus(LoadagentstatusReq loadagentstatusReq)
        {
            List<LoadagentstatusRes> resultlist = new List<LoadagentstatusRes>();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getagentLivestatus", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_rmid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Reportingmanagerid);
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Agentid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadagentstatusRes result = new LoadagentstatusRes();
                        result.Rno = Convert.ToInt32(dataReader["o_rno"]);
                        result.Agentid = Convert.ToInt32(dataReader["o_agentid"]);
                        result.Agentname = Convert.ToString(dataReader["o_agentname"]);
                        result.Agentextension = Convert.ToString(dataReader["o_agentextension"]);
                        result.Logdate = Convert.ToString(dataReader["o_logdate"]);
                        result.Starttime = Convert.ToString(dataReader["o_starttime"]);
                        result.Endtime = Convert.ToString(dataReader["o_endtime"]);
                        result.Duration = Convert.ToString(dataReader["o_duration"]);
                        result.Callstatus = Convert.ToString(dataReader["o_callstatus"]);
                        resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public List<Agentddl> Loadagentddl()
        {
            List<Agentddl> resultlist = new List<Agentddl>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                string query = "select idagent as agentid,agentname agentname from agents WHERE isactive=1 and coalesce(isadmin,0)=1  order by agentname asc";
                var npgsqlcmd = new NpgsqlCommand(query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Agentddl result = new Agentddl();
                        result.Agentid = Convert.ToInt32(dataReader["agentid"]);
                        result.Agentname = Convert.ToString(dataReader["agentname"]);
                        resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public List<Languageddl> Loadagentlanguage()
        {
            List<Languageddl> resultlist = new List<Languageddl>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                string query = "select languageid,languagename from masterlanguage";
                var npgsqlcmd = new NpgsqlCommand(query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Languageddl result = new Languageddl();
                        result.Languageid = Convert.ToInt32(dataReader["languageid"]);
                        result.Languagename = Convert.ToString(dataReader["languagename"]);
                        resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public DataTable Loadagentcallhistory(LoadagenthistoryReq loadagentstatusReq, ref string basepath, ref string downloadpath)
        {
            DataTable dttemp = new DataTable();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getagentcallhistory", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_rmid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Reportingmanagerid);
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Agentid);
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Todate ?? "");
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlcmd);
                dataAdapter.Fill(dttemp);
                npgsqlcon.Close();
                basepath = getConnection().GetSection("connectionStrings").GetSection("basicPath").Value;
                downloadpath = getConnection().GetSection("connectionStrings").GetSection("downloadPath").Value;
            }
            return dttemp;
        }

        public DataTable DownloadItems(int CustomerId, ref string basepath, ref string downloadpath)
        {
            DataTable dttemp = new DataTable();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.downloaditems", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, CustomerId);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlcmd);
                dataAdapter.Fill(dttemp);
                npgsqlcon.Close();
                basepath = getConnection().GetSection("connectionStrings").GetSection("basicPath").Value;
                downloadpath = getConnection().GetSection("connectionStrings").GetSection("downloadPath").Value;
            }
            return dttemp;
        }
        public DataTable downloadpackageitems(int CustomerId, ref string basepath, ref string downloadpath)
        {
            DataTable dttemp = new DataTable();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.downloadpackageitems", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, CustomerId);
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlcmd);
                dataAdapter.Fill(dttemp);
                npgsqlcon.Close();
                basepath = getConnection().GetSection("connectionStrings").GetSection("basicPath").Value;
                downloadpath = getConnection().GetSection("connectionStrings").GetSection("downloadPath").Value;
            }
            return dttemp;
        }

        public DataTable Loadagentcallsummary(LoadagenthistoryReq loadagentstatusReq, ref string basepath, ref string downloadpath)
        {
            DataTable dttemp = new DataTable();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getagentcallhistorysummery", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_rmid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Reportingmanagerid);
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Agentid);
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Todate ?? "");
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlcmd);
                dataAdapter.Fill(dttemp);
                npgsqlcon.Close();

                basepath = getConnection().GetSection("connectionStrings").GetSection("basicPath").Value;
                downloadpath = getConnection().GetSection("connectionStrings").GetSection("downloadPath").Value;
            }
            return dttemp;
        }
        public List<Agentddl> Loadagentbyrmddl(int rmid)
        {
            List<Agentddl> resultlist = new List<Agentddl>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                string query = "select idagent,agentname from agents WHERE isactive=1 and reportingmanager=@rmid  order by agentname asc";
                var npgsqlcmd = new NpgsqlCommand(query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                npgsqlcmd.Parameters.AddWithValue("@rmid", Convert.ToInt32(rmid));
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Agentddl result = new Agentddl();
                        result.Agentid = Convert.ToInt32(dataReader["idagent"]);
                        result.Agentname = Convert.ToString(dataReader["agentname"]);
                        resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public List<SummaryreportOP> Loadagentcallsummarystatus(LoadagenthistoryReq loadagentstatusReq)
        {
            List<SummaryreportOP> resultlist = new List<SummaryreportOP>();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getagentcallhistorysummery", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_rmid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Reportingmanagerid);
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Agentid);
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Todate ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        SummaryreportOP result = new SummaryreportOP();
                        result.Agentname = Convert.ToString(dataReader["agentname"]);
                        result.Agentextension = Convert.ToString(dataReader["agentextension"]);
                        result.Logdate = Convert.ToString(dataReader["logdate"]);
                        result.Duration = Convert.ToString(dataReader["duration"]);
                        result.Connected = Convert.ToString(dataReader["connected"]);
                        result.Missed = Convert.ToString(dataReader["missed"]);
                        result.Avgcalltime = Convert.ToString(dataReader["avgcalltime"]);
                        resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public List<DetailreportOP> Loadagentcalldetailstatus(LoadagenthistoryReq loadagentstatusReq)
        {
            List<DetailreportOP> resultlist = new List<DetailreportOP>();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getagentcallhistory", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_rmid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Reportingmanagerid);
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, loadagentstatusReq.Agentid);
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadagentstatusReq.Todate ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        DetailreportOP result = new DetailreportOP();
                        result.Rno = Convert.ToInt32(dataReader["rno"]);
                        result.Agentname = Convert.ToString(dataReader["agentname"]);
                        result.Agentextension = Convert.ToString(dataReader["agentextension"]);
                        result.Logdate = Convert.ToString(dataReader["logdate"]);
                        result.Starttime = Convert.ToString(dataReader["starttime"]);
                        result.Endtime = Convert.ToString(dataReader["endtime"]);
                        result.Duration = Convert.ToString(dataReader["duration"]);
                        result.Callstatus = Convert.ToString(dataReader["callstatus"]);
                                               resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public DataTable downloadagentcallstatus(downloadagentcallReq downloadagentcallReq, ref string basepath, ref string downloadpath)
        {
            DataTable dttemp = new DataTable();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getallagentcallhistory", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, downloadagentcallReq.Agentid);
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, downloadagentcallReq.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, downloadagentcallReq.Todate ?? "");
                NpgsqlDataAdapter dataAdapter = new NpgsqlDataAdapter(npgsqlcmd);
                dataAdapter.Fill(dttemp);
                npgsqlcon.Close();
                basepath = getConnection().GetSection("connectionStrings").GetSection("basicPath").Value;
                downloadpath = getConnection().GetSection("connectionStrings").GetSection("downloadPath").Value;
            }
            return dttemp;
        }
    }
}
