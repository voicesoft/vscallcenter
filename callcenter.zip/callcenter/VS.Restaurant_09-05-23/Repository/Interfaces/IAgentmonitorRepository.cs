﻿using System.Data;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository.Interfaces
{
    public interface IAgentmonitorRepository
    {
        List<LoginRes> Validatelogin(LoginReq loginReq);
        List<LoadagentstatusRes> Loadagentcallstatus(LoadagentstatusReq loadagentstatusReq);
        List<Agentddl> Loadagentddl();
        List<Languageddl> Loadagentlanguage();
        DataTable Loadagentcallhistory(LoadagenthistoryReq loadagenthistoryReq, ref string basepath, ref string downloadpath);
        DataTable Loadagentcallsummary(LoadagenthistoryReq loadagenthistoryReq, ref string basepath, ref string downloadpath);
        List<Agentddl> Loadagentbyrmddl(int rmid);
        List<SummaryreportOP> Loadagentcallsummarystatus(LoadagenthistoryReq loadagentstatusReq);
        List<DetailreportOP> Loadagentcalldetailstatus(LoadagenthistoryReq loadagentstatusReq);
        DataTable DownloadItems(int CustomerId, ref string basepath, ref string downloadpath);
        DataTable downloadpackageitems(int CustomerId, ref string basepath, ref string downloadpath);
        DataTable downloadagentcallstatus(downloadagentcallReq downloadagentcallReq, ref string basepath, ref string downloadpath);
    }
}
