﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository.Interfaces
{
    public interface IAgentRepository
    {
        public Defalutresultset CreateAgent(CreateAgents _agent);
        public List<Agents> GetAllAgents(int userid);

    }
}
