﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository.Interfaces
{
    public interface IOrder
    {
        public DefaultResponse CreateNewOrder(OrderHeader _agent);
        public List<FinishedItemDetails> GetFinishedItems(int UserId, string DID);
        public List<PckItems> GetSearchItems(int UserId, int CustomerId);
        public List<ItemPriceDetails> GetItemsizebyItemcode(int UserId, int CustomerId, Int64 Itemcode);
        public List<OrderHeaderInfo> GetOrderHeaderInfo(int CustomerId);
        public List<OrderDetailsInfo> GetOrderDetailsbyOrderno(int CustomerId, Int64 OrderNo);
        public int UpdateOrderStatus(ReqUpdateStatus req);
        public int Updateordertiming(ReqUpdateStatus req);
        public List<LoadmasteritemDDLOP> LoadmasteritemDDL(LoadmasteritemDDLIP customerid,ref List<ConferenceCallOP> conferenceCallOPs);
        
        /*Out of order*/
        public List<loadItemmasterforOOS> LoadItemmasterforOOS(outofstockIP customerid );
        public int AddOutofstocks(addoutofstock req);
        public List<loadOutofstocksOP> LoadOutofstocks(outofstockIP customerid);
        public int Updateoutofstock(stockIP stockid);
        /*End*/
        public string GetConsumername(string consumermobile, string customermobile, ref string consumername);
    }
}
