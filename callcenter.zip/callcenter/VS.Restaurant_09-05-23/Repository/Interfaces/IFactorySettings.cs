﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository.Interfaces
{
    public interface IFactorySettings
    {
        public DefaultResponse AddItemPromotion(ReqItemPromotion reqItemPromotion);
        public DefaultResponse RemoveItemPromotion(ReqRemoveItem reqRemoveItem);
        public List<ResItemList> GetItemPromotion(ReqItemList reqItemList, ref int totalrows);
        public DefaultResponse AddItemDelay(ReqItemDelays reqItemDelays);
        public DefaultResponse RemoveItemDelay(ReqRemoveItem reqRemoveItem);
        public List<ResItemList> GetItemDelayList(ReqItemList reqItemList, ref int totalrows);
        public DefaultResponse AddFactoryPauseTimings(ReqFactoryPause reqFactoryPause);
        public DefaultResponse RemoveFactoryPauseTimings(ReqRemoveItem reqRemoveItem);
        public List<ResDelayList> GetFactoryPauseTimings(ReqDelay reqDelay);
        public DefaultResponse RemoveItemOfTheDay(ReqRemoveItem reqRemoveItem);
        public List<ResItemList> GetItemOfTheDay(ReqItemList reqItemList, ref int totalrows);
        public DefaultResponse AddItemOfTheDay(ReqItemOfTheDay reqItemOfTheDay);
        public DefaultResponse AddBlackList(ReqBlackList reqBlack);
        public DefaultResponse RemoveBlackList(ReqRemoveBlackList reqRemoveBlackList);
        public List<ResLoadBlacList> GetBlackList(ReqLoadBlacList reqLoadBlacList, ref int totalrows);
        public List<ResDelayList> GetOverAllOrderDelay(ReqDelay reqDelay);
        public DefaultResponse AddOverAllOrderDelay(ReqAddOverAllDelay reqAddOverAllDelay);
        public DefaultResponse RemoveOverAllOrderDelay(ReqRemoveItem reqRemoveItem);
        public List<ResAddBalcklistmembers> getBlacklistmembers(ReqAddBalcklistmembers reqRemoveItem, ref int totalrows);
    }
}
