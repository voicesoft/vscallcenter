﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository.Interfaces
{
    public interface ICallStatus
    {
        public DefaultResponse AgentStausUpdate(AgentStatusUpdate _req);
        public DefaultResponse AgentCallStatus(LiveAgents _req);
        public AllocatedExtension GetorSetAgentData(IncomingCall _req);
        public DefaultResponse UpdateCallLog(CallLog req);
        public DefaultResponse UpdateCurrentAgentStatus(List<AgentList> _req);
        public AllocatedExtension GetorSetAgenQueueData(IncomingCall _req);
        public List<AgentStatusResultset> GetLanguage(int agentid);
        public DefaultResponse UpdateQueueLogs(ReqQueueLog reqQueueLog);
        public AudioData UpdateTrainingCallLog(TCallLog req); 
        public List<Companyddl> Loadcompany();
        public AudioData InitiateTraining(RequestStartStop requestStartStop);
        public List<Defalutresultset> Uploadaudio(AddReqUploadTrainingAudio requploadaudio);
        public List<Loadallaudioop> Loadallaudio(LoadcompanyInput loadcompanyInput, ref int totalrow);
        public Defalutresultset Deleteaudiofile(DeleteaudiofileIP deleteaudiofileValues);
    }
}
