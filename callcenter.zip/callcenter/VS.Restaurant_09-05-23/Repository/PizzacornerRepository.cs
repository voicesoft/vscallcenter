﻿using Npgsql;
using System.Data;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository
{
    public class PizzacornerRepository : DbConfig, IPizzacornerRepository
    {
        #region Itembase
        public List<LoadmasterbaseRes> Loadpizzabase(int restraurantid)
        {
            List<LoadmasterbaseRes> listloadmasterbaseRes = new List<LoadmasterbaseRes>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("loagmasterbase", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_resturantid", NpgsqlTypes.NpgsqlDbType.Integer, restraurantid);
            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    LoadmasterbaseRes loadmasterbaseRes = new LoadmasterbaseRes();
                    loadmasterbaseRes.SNo = Convert.ToInt32(dataReader["o_sno"]);
                    loadmasterbaseRes.Baseid = Convert.ToInt32(dataReader["o_idbase"]);
                    loadmasterbaseRes.Basecode = Convert.ToString(dataReader["o_basecode"]);
                    loadmasterbaseRes.Basename = Convert.ToString(dataReader["o_basename"]);
                    loadmasterbaseRes.Createdby = Convert.ToString(dataReader["o_cratedby"]);
                    loadmasterbaseRes.Createdon = Convert.ToString(dataReader["o_createdon"]);
                    listloadmasterbaseRes.Add(loadmasterbaseRes);
                }
            }
            npgsqlcon.Close();
            return listloadmasterbaseRes;
        }
        public OPRes Addpizzabase(OperatemasterbaseReq operatemasterbaseReq)
        {
            OPRes oPRes = new OPRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("operatemasterbase", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_resturantid", NpgsqlTypes.NpgsqlDbType.Integer, operatemasterbaseReq.Restaurantid);
            npgsqlcmd.Parameters.AddWithValue("i_baseid", NpgsqlTypes.NpgsqlDbType.Numeric, operatemasterbaseReq.Baseid);
            npgsqlcmd.Parameters.AddWithValue("i_basename", NpgsqlTypes.NpgsqlDbType.Varchar, operatemasterbaseReq.Basename ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_basecode", NpgsqlTypes.NpgsqlDbType.Varchar, operatemasterbaseReq.Basecode ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_createdby", NpgsqlTypes.NpgsqlDbType.Integer, operatemasterbaseReq.Createdby);
            npgsqlcmd.Parameters.AddWithValue("i_type", NpgsqlTypes.NpgsqlDbType.Integer, 1);
            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    oPRes.Status = Convert.ToInt32(dataReader["o_status"]);
                    oPRes.Message = Convert.ToString(dataReader["o_message"]);
                    break;
                }
            }
            npgsqlcon.Close();
            return oPRes;
        }
        public OPRes Updatepizzabase(OperatemasterbaseReq operatemasterbaseReq)
        {
            OPRes oPRes = new OPRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("operatemasterbase", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_resturantid", NpgsqlTypes.NpgsqlDbType.Integer, operatemasterbaseReq.Restaurantid);
            npgsqlcmd.Parameters.AddWithValue("i_baseid", NpgsqlTypes.NpgsqlDbType.Numeric, operatemasterbaseReq.Baseid);
            npgsqlcmd.Parameters.AddWithValue("i_basename", NpgsqlTypes.NpgsqlDbType.Varchar, operatemasterbaseReq.Basename ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_basecode", NpgsqlTypes.NpgsqlDbType.Varchar, operatemasterbaseReq.Basecode ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_createdby", NpgsqlTypes.NpgsqlDbType.Integer, operatemasterbaseReq.Createdby);
            npgsqlcmd.Parameters.AddWithValue("i_type", NpgsqlTypes.NpgsqlDbType.Integer, 2);
            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    oPRes.Status = Convert.ToInt32(dataReader["o_status"]);
                    oPRes.Message = Convert.ToString(dataReader["o_message"]);
                    break;
                }
            }
            npgsqlcon.Close();
            return oPRes;
        }
        public OPRes Deletepizzabase(DeletemasterbaseReq operatemasterbaseReq)
        {
            OPRes oPRes = new OPRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("operatemasterbase", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_resturantid", NpgsqlTypes.NpgsqlDbType.Integer, operatemasterbaseReq.Restaurantid);
            npgsqlcmd.Parameters.AddWithValue("i_baseid", NpgsqlTypes.NpgsqlDbType.Numeric, operatemasterbaseReq.Baseid);
            npgsqlcmd.Parameters.AddWithValue("i_basename", NpgsqlTypes.NpgsqlDbType.Varchar, "");
            npgsqlcmd.Parameters.AddWithValue("i_basecode", NpgsqlTypes.NpgsqlDbType.Varchar, "");
            npgsqlcmd.Parameters.AddWithValue("i_createdby", NpgsqlTypes.NpgsqlDbType.Integer, operatemasterbaseReq.Createdby);
            npgsqlcmd.Parameters.AddWithValue("i_type", NpgsqlTypes.NpgsqlDbType.Integer, 3);
            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    oPRes.Status = Convert.ToInt32(dataReader["o_status"]);
                    oPRes.Message = Convert.ToString(dataReader["o_message"]);
                    break;
                }
            }
            npgsqlcon.Close();
            return oPRes;
        }
        #endregion
        #region Itemtopping
        public List<LoadmastertopingsRes> LoadpizzaToppings(int restraurantid, int userid)
        {
            List<LoadmastertopingsRes> listloadmasterbaseRes = new List<LoadmastertopingsRes>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("getmastertopings", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, restraurantid);
            npgsqlcmd.Parameters.AddWithValue("i_userid", NpgsqlTypes.NpgsqlDbType.Integer, userid);
            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    LoadmastertopingsRes resobj = new LoadmastertopingsRes();
                    resobj.SNo = Convert.ToInt32(dataReader["o_serialno"]);
                    resobj.Topingid = Convert.ToInt32(dataReader["o_topingid"]);
                    resobj.Custoemritemcode = Convert.ToString(dataReader["o_customeritemcode"]);
                    resobj.Topingname = Convert.ToString(dataReader["o_topingname"]);
                    resobj.Fullprice = Convert.ToString(dataReader["o_fullprice"]);
                    resobj.Halfprice = Convert.ToString(dataReader["o_halfprice"]);
                    resobj.Createdby = Convert.ToString(dataReader["o_createdby"]);
                    resobj.Createdon = Convert.ToString(dataReader["o_createdon"]);
                    listloadmasterbaseRes.Add(resobj);
                }
            }
            npgsqlcon.Close();
            return listloadmasterbaseRes;
        }
        public OPRes AddpizzaToppings(AddmasttertopingsReq addmasttertopingsReq)
        {
            OPRes oPRes = new OPRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("addtoping", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, addmasttertopingsReq.Resturantid);
            npgsqlcmd.Parameters.AddWithValue("i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, addmasttertopingsReq.Customeritemcode ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_topingname", NpgsqlTypes.NpgsqlDbType.Varchar, addmasttertopingsReq.Topingname ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_fullprice", NpgsqlTypes.NpgsqlDbType.Numeric, addmasttertopingsReq.Fullprice);
            npgsqlcmd.Parameters.AddWithValue("i_halfprice", NpgsqlTypes.NpgsqlDbType.Numeric, addmasttertopingsReq.Halfprice);
            npgsqlcmd.Parameters.AddWithValue("i_createdby", NpgsqlTypes.NpgsqlDbType.Integer, addmasttertopingsReq.Createdby);

            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    oPRes.Status = Convert.ToInt32(dataReader["o_status"]);
                    oPRes.Message = Convert.ToString(dataReader["o_message"]);
                    break;
                }
            }
            npgsqlcon.Close();
            return oPRes;
        }
        public OPRes UpdatepizzaToppings(UpdatemasttertopingsReq addmasttertopingsReq)
        {
            OPRes oPRes = new OPRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("updatetoping", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, addmasttertopingsReq.Resturantid);
            npgsqlcmd.Parameters.AddWithValue("i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, addmasttertopingsReq.Customeritemcode ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_topingname", NpgsqlTypes.NpgsqlDbType.Varchar, addmasttertopingsReq.Topingname ?? "");
            npgsqlcmd.Parameters.AddWithValue("i_fullprice", NpgsqlTypes.NpgsqlDbType.Numeric, addmasttertopingsReq.Fullprice);
            npgsqlcmd.Parameters.AddWithValue("i_halfprice", NpgsqlTypes.NpgsqlDbType.Numeric, addmasttertopingsReq.Halfprice);
            npgsqlcmd.Parameters.AddWithValue("i_createdby", NpgsqlTypes.NpgsqlDbType.Integer, addmasttertopingsReq.Createdby);
            npgsqlcmd.Parameters.AddWithValue("i_topingid", NpgsqlTypes.NpgsqlDbType.Bigint, addmasttertopingsReq.Topingid);

            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    oPRes.Status = Convert.ToInt32(dataReader["o_status"]);
                    oPRes.Message = Convert.ToString(dataReader["o_message"]);
                    break;
                }
            }
            npgsqlcon.Close();
            return oPRes;
        }
        public OPRes DeletepizzaToppings(int restraurantid, int userid, Int64 topingid)
        {
            OPRes oPRes = new OPRes();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using var npgsqlcon = new NpgsqlConnection(conStr);
            npgsqlcon.Open();
            var npgsqlcmd = new NpgsqlCommand("deletetoping", npgsqlcon);
            npgsqlcmd.CommandType = CommandType.StoredProcedure;
            npgsqlcmd.Parameters.AddWithValue("i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, restraurantid);
            npgsqlcmd.Parameters.AddWithValue("i_createdby", NpgsqlTypes.NpgsqlDbType.Integer, userid);
            npgsqlcmd.Parameters.AddWithValue("i_topingid", NpgsqlTypes.NpgsqlDbType.Bigint, topingid);

            using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
            {
                while (dataReader.Read())
                {
                    oPRes.Status = Convert.ToInt32(dataReader["o_status"]);
                    oPRes.Message = Convert.ToString(dataReader["o_message"]);
                    break;
                }
            }
            npgsqlcon.Close();
            return oPRes;
        }
        #endregion
        #region Itemmaster
        public List<Defalutresultset> AddItemmaster(AddmasterpizzaValues addmasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string sizeids = Newtonsoft.Json.JsonConvert.SerializeObject(addmasterValues.Sizeids);
            string defaulttopings = Newtonsoft.Json.JsonConvert.SerializeObject(addmasterValues.Defaulttoppings);
            string pizzabase = Newtonsoft.Json.JsonConvert.SerializeObject(addmasterValues.Itembase);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additemmasterpizza_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemname", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Itemname ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Itemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_sizeid", NpgsqlTypes.NpgsqlDbType.Text, sizeids);
                npgsqlcmd.Parameters.AddWithValue("@i_typeid", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Typeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_haspackage", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Haspackage);
                npgsqlcmd.Parameters.AddWithValue("@i_isaddonitem", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Isaddonitem);
                npgsqlcmd.Parameters.AddWithValue("@i_ismodifier", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Ismodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_applaymodifer", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Applaymodifer);
                npgsqlcmd.Parameters.AddWithValue("@i_imagepath", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_audiopath", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Audiofile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_category", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Category ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_extraaddonlimit", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Extraaddonlimit);
                npgsqlcmd.Parameters.AddWithValue("@i_defaultremovecount", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Defaultremovecount);
                npgsqlcmd.Parameters.AddWithValue("@i_defaulttoppings", NpgsqlTypes.NpgsqlDbType.Text, defaulttopings);
                npgsqlcmd.Parameters.AddWithValue("@i_addonlimit", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Addonlimit);
                npgsqlcmd.Parameters.AddWithValue("@i_isown", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Isown);
                npgsqlcmd.Parameters.AddWithValue("@i_base", NpgsqlTypes.NpgsqlDbType.Text, pizzabase);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoadmasterpizzaResultset> LoadItemmaster(LoadmasterpizzaValues loadmasterValues, ref Int32 totalrow)
        {
            List<LoadmasterpizzaResultset> loadmasterResultsets = new List<LoadmasterpizzaResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemmasterpizza_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_typeid", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Typeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_sizeid", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Sizeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_haspackage", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Haspackage);
                npgsqlcmd.Parameters.AddWithValue("@i_isaddon", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Isaddon);
                npgsqlcmd.Parameters.AddWithValue("@i_ismodifier", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Ismodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_applymodifier", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Applymodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_search", NpgsqlTypes.NpgsqlDbType.Varchar, loadmasterValues.Search ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadmasterValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadmasterValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadmasterpizzaResultset loadmasterResultset = new LoadmasterpizzaResultset();
                        sizeinfo sizeinfo = new sizeinfo();
                        //sizeinfo = Newtonsoft.Json.JsonConvert.DeserializeObject(Convert.ToString(dataReader["o_size"]));
                        loadmasterResultset.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        loadmasterResultset.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        loadmasterResultset.Itemcode = Convert.ToInt32(dataReader["o_itemcode"]);
                        loadmasterResultset.Customeritemcode = Convert.ToString(dataReader["o_customeritemcode"]);
                        loadmasterResultset.Itemname = Convert.ToString(dataReader["o_itemname"]);
                        loadmasterResultset.Itemdescription = Convert.ToString(dataReader["o_itemdescription"]);
                        loadmasterResultset.Size = Convert.ToString(dataReader["o_size"]);
                        loadmasterResultset.Typeid = Convert.ToInt16(dataReader["o_typeid"]);
                        loadmasterResultset.Type = Convert.ToString(dataReader["o_type"]);
                        //loadmasterResultset.Haspackage = Convert.ToString(dataReader["o_haspackage"]);
                        loadmasterResultset.Isaddonitem = Convert.ToString(dataReader["o_isaddonitem"]);
                        loadmasterResultset.Ismodifier = Convert.ToString(dataReader["o_ismodifier"]);
                        loadmasterResultset.Applaymodifer = Convert.ToString(dataReader["o_applaymodifer"]);
                        loadmasterResultset.Imagepath = Convert.ToString(dataReader["o_imagepath"]);
                        loadmasterResultset.Username = Convert.ToString(dataReader["o_username"]);
                        loadmasterResultset.Category = Convert.ToString(dataReader["o_category"]);
                        loadmasterResultset.Audiofile = Convert.ToString(dataReader["o_audiofile"]);
                        loadmasterResultset.Imagepath = Convert.ToString(dataReader["o_imagepath"]);
                        loadmasterResultset.Username = Convert.ToString(dataReader["o_username"]);
                        loadmasterResultset.Category = Convert.ToString(dataReader["o_category"]);
                        loadmasterResultset.Extraaddonlimit = Convert.ToString(dataReader["o_extraaddonlimit"]);
                        loadmasterResultset.Addonremovelimit = Convert.ToString(dataReader["o_addonremovelimit"]);
                        loadmasterResultset.Defaulttoppings = Convert.ToString(dataReader["o_defaulttoppings"]);
                        loadmasterResultset.Isown = Convert.ToString(dataReader["o_isown"]);
                        loadmasterResultset.Addonlimit = Convert.ToString(dataReader["o_addonlimit"]);
                        loadmasterResultset.Defaultbase = Convert.ToString(dataReader["o_defaultbase"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadmasterResultsets.Add(loadmasterResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadmasterResultsets;
        }
        public List<Defalutresultset> EditItemmaster(EditmasterpizzaValues editmasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string defaulttopings = Newtonsoft.Json.JsonConvert.SerializeObject(editmasterValues.Defaulttoppings);
            string sizeids = Newtonsoft.Json.JsonConvert.SerializeObject(editmasterValues.Sizeids);
            string pizzabase = Newtonsoft.Json.JsonConvert.SerializeObject(editmasterValues.Itembase);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititemmasterpizza_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editmasterValues.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemname", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Itemname ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Itemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_sizeid", NpgsqlTypes.NpgsqlDbType.Varchar, sizeids);
                npgsqlcmd.Parameters.AddWithValue("@i_typeid", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Typeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_haspackage", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Haspackage);
                npgsqlcmd.Parameters.AddWithValue("@i_isaddonitem", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Isaddonitem);
                npgsqlcmd.Parameters.AddWithValue("@i_ismodifier", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Ismodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_applaymodifer", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Applaymodifer);
                npgsqlcmd.Parameters.AddWithValue("@i_imagepath", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_audiopath", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Audiofile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_category", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Category ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_extraaddonlimit", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Extraaddonlimit);
                npgsqlcmd.Parameters.AddWithValue("@i_defaultremovecount", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Defaultremovecount);
                npgsqlcmd.Parameters.AddWithValue("@i_defaulttoppings", NpgsqlTypes.NpgsqlDbType.Text, defaulttopings);
                npgsqlcmd.Parameters.AddWithValue("@i_addonlimit", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Addonlimit);
                npgsqlcmd.Parameters.AddWithValue("@i_isown", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Isown);
                npgsqlcmd.Parameters.AddWithValue("@i_base", NpgsqlTypes.NpgsqlDbType.Text, pizzabase);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItemmaster(DeletemasterpizzaValues deletemasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitemmaster", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deletemasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Integer, deletemasterValues.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deletemasterValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deletemasterValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
        #region Itempackage
        public List<Defalutresultset> AddItempackagepizza(AddpackageitempizzaValues addpackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string jsonval = Newtonsoft.Json.JsonConvert.SerializeObject(addpackageValues.Packagevalues);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additempackagepizza_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, addpackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritem", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.Masteritem ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.Masteritemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_imagefile", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.Imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Numeric, addpackageValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_jsonval", NpgsqlTypes.NpgsqlDbType.Text, jsonval);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoadpackagepizzaResultset> LoadItempackagepizza(LoadpackagepizzaValues loadpackageValues, ref Int32 totalrow)
        {
            List<LoadpackagepizzaResultset> loadpackageResultsets = new List<LoadpackagepizzaResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditempackagepizza_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loadpackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemname", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Itemname ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loadpackageValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loadpackageValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadpackagepizzaResultset loadpackageResultset = new LoadpackagepizzaResultset();
                        loadpackageResultset.Sno = Convert.ToInt32(dataReader["sno"]);
                        loadpackageResultset.Customerid = Convert.ToInt32(dataReader["customerid"]);
                        loadpackageResultset.Customeritemcode = Convert.ToString(dataReader["customeritemcode"]);
                        loadpackageResultset.Masteritemid = Convert.ToInt64(dataReader["packageid"]);
                        loadpackageResultset.Itemname = Convert.ToString(dataReader["itemname"]);
                        loadpackageResultset.Itemdescription = Convert.ToString(dataReader["itemdescription"]);
                        loadpackageResultset.Packageitems = Convert.ToString(dataReader["packageitems"]);
                        loadpackageResultset.Createdby = Convert.ToString(dataReader["createby"]);
                        loadpackageResultset.Createdon = Convert.ToString(dataReader["createdon"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadpackageResultsets.Add(loadpackageResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadpackageResultsets;
        }
        public List<Defalutresultset> EditItempackagepizza(EditpackagepizzaValues editpackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string jsonval = Newtonsoft.Json.JsonConvert.SerializeObject(editpackageValues.Packagevalues);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititempackagepizza_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_masteritemid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Masteritemid);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritem", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Masteritem ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Masteritemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_imagefile", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_jsonval", NpgsqlTypes.NpgsqlDbType.Text, jsonval);
                /* npgsqlcmd.CommandType = CommandType.StoredProcedure;
                 npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Customerid);
                 npgsqlcmd.Parameters.AddWithValue("@i_idpackage", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Idpackage);
                 npgsqlcmd.Parameters.AddWithValue("@i_packageitemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Packageitemcode);
                 npgsqlcmd.Parameters.AddWithValue("@i_serialno", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Serialno);
                 npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Itemcode);
                 npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Itemsizeid);
                 npgsqlcmd.Parameters.AddWithValue("@i_itemprice", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Itemprice);
                 npgsqlcmd.Parameters.AddWithValue("@i_discount", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Discount);
                 npgsqlcmd.Parameters.AddWithValue("@i_unitprice", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Unitprice);
                 npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.userid);*/
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItempackagepizza(DeletepackagepizzaValues deletepackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitempackagepizza", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deletepackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_idpackage", NpgsqlTypes.NpgsqlDbType.Integer, deletepackageValues.Masteritemid);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deletepackageValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deletepackageValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
        #region Itemdata
        public List<itemdatares> Loaditeminfo(Int64 itemcode)
        {
            List<itemdatares> loadpackageResultsets = new List<itemdatares>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string imagedownloadPath = getConnection().GetSection("connectionStrings").GetSection("imagedownloadPath").Value;

            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditeminfo", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Integer, itemcode);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        itemdatares loadpackageResultset = new itemdatares();
                        loadpackageResultset.Itemcode = Convert.ToInt64(dataReader["o_itemcode"]);
                        loadpackageResultset.Itemname = Convert.ToString(dataReader["o_itemname"]);
                        loadpackageResultset.Itemdescription = Convert.ToString(dataReader["o_itemdescription"]);
                        loadpackageResultset.Imagepath = imagedownloadPath + Convert.ToString(dataReader["o_imagepath"]);
                        loadpackageResultset.Extraaddonlimit = Convert.ToInt32(dataReader["o_extraaddonlimit"]);
                        loadpackageResultset.Addonremovelimit = Convert.ToInt32(dataReader["o_addonremovelimit"]);
                        loadpackageResultset.Isown = Convert.ToInt32(dataReader["o_isown"]);
                        loadpackageResultset.Addonlimit = Convert.ToInt32(dataReader["o_addonlimit"]);
                        loadpackageResultset.Sizeinfo = Convert.ToString(dataReader["o_sizeinfo"]);
                        loadpackageResultset.Baseinfo = Convert.ToString(dataReader["o_baseinfo"]);
                        loadpackageResultset.Defaulttoppinginfo = Convert.ToString(dataReader["o_defaulttoppinginfo"]);
                        loadpackageResultset.Toppinginfo = Convert.ToString(dataReader["o_toppinginfo"]);
                        loadpackageResultset.Restaurantid = Convert.ToInt64(dataReader["o_companyid"]);
                        loadpackageResultsets.Add(loadpackageResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadpackageResultsets;
        }
        #endregion
        #region Itemtypeddl
        public List<Loaditemtyperes> Loaditemtypeddl(Int64 resturuantid)
        {
            List<Loaditemtyperes> loadpackageResultsets = new List<Loaditemtyperes>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;

            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                string query = "SELECT idtype::bigint,itemtype FROM itemtype WHERE customerid=@i_customerid  and isactive='1'  ORDER BY  itemtype ASC";
                var npgsqlcmd = new NpgsqlCommand(query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", resturuantid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Loaditemtyperes loadpackageResultset = new Loaditemtyperes();
                        loadpackageResultset.Typeid = Convert.ToInt32(dataReader["idtype"]);
                        loadpackageResultset.Typename = Convert.ToString(dataReader["itemtype"]);
                        loadpackageResultsets.Add(loadpackageResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadpackageResultsets;
        }
        public List<Loaditemnameres> Loaditemnameddl(Int64 resturuantid, Int64 itemtype)
        {
            List<Loaditemnameres> loadpackageResultsets = new List<Loaditemnameres>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;

            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                string query = "select itemcode,itemname from itemmaster where idtype=@idtype and customerid=@i_customerid and isactive='1' order by itemname asc";
                var npgsqlcmd = new NpgsqlCommand(query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                npgsqlcmd.Parameters.AddWithValue("@idtype", itemtype);
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", resturuantid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Loaditemnameres loadpackageResultset = new Loaditemnameres();
                        loadpackageResultset.Itemid = Convert.ToInt32(dataReader["itemcode"]);
                        loadpackageResultset.Itemname = Convert.ToString(dataReader["itemname"]);
                        loadpackageResultsets.Add(loadpackageResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadpackageResultsets;
        }
        
        #endregion
    }
}
