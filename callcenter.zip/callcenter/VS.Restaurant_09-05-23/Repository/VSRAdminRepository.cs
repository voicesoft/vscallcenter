﻿using Npgsql;
using System.Data;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository
{
    public class VSRAdminRepository : DbConfig, VSRAdminRepositoryInterface
    {
        public List<Defaultresultset> AddCompany(Customer customer, ref dynamic dbConfig)
        {
            List<Defaultresultset> Defaultresultset = new List<Defaultresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            dbConfig = getConnection().GetSection("connectionStrings");
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.AddCompanyinformation", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_type", NpgsqlTypes.NpgsqlDbType.Numeric, Convert.ToInt32(customer.Type));
                npgsqlcmd.Parameters.AddWithValue("@i_companyid", NpgsqlTypes.NpgsqlDbType.Numeric, Convert.ToInt32(customer.CompanyId));
                npgsqlcmd.Parameters.AddWithValue("@i_companyname", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.CompanyName ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_customername", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.CustomerName ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_username", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Username ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_firstname", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.FirstName ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_lastname", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.LastName ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_email", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Email ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_regnumber", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.RegNumber ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_address1", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Address1 ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_address2", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Address2 ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_address3", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Address3 ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_country", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Country ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_zipcode", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Zipcode ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_contactnumber", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.ContactNumber ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_contactperson", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.ContactPerson ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_contactpersonnumber", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.ContactPersonNumber ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.DID ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_onlineurl", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.OnlineURL ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_deliverytype", NpgsqlTypes.NpgsqlDbType.Numeric, Convert.ToInt32(customer.DeliveryType));
                npgsqlcmd.Parameters.AddWithValue("@i_ordercomission", NpgsqlTypes.NpgsqlDbType.Numeric, Convert.ToDecimal(customer.OrderComission));
                npgsqlcmd.Parameters.AddWithValue("@i_createdby", NpgsqlTypes.NpgsqlDbType.Numeric, Convert.ToInt32(customer.Createdby));
                npgsqlcmd.Parameters.AddWithValue("@i_restauranttype", NpgsqlTypes.NpgsqlDbType.Numeric, Convert.ToInt32(customer.Restauranttype));
                npgsqlcmd.Parameters.AddWithValue("@i_hours", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Hours));
                npgsqlcmd.Parameters.AddWithValue("@i_minutes", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(customer.Minutes));
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defaultresultset _defaultresult = new Defaultresultset();
                        _defaultresult.Status = Convert.ToInt32(dataReader["o_status"]);
                        _defaultresult.Message = Convert.ToString(dataReader["o_message"]);
                        Defaultresultset.Add(_defaultresult);
                    }
                }
                npgsqlcon.Close();
            }
            return Defaultresultset;
        }
        public List<LoadcompanyOutput> LoadCompany(LoadcompanyInput loadcompanyInput, ref int totalrow)
        {
            List<LoadcompanyOutput> loadcompanyOutputs = new List<LoadcompanyOutput>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.LoadCompanyinformation", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_search", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(loadcompanyInput.Search ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, Convert.ToInt32(loadcompanyInput.pageno));
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadcompanyOutput _defaultresult = new LoadcompanyOutput();
                        _defaultresult.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        _defaultresult.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        _defaultresult.Customername = Convert.ToString(dataReader["o_customername"]);
                        _defaultresult.Companyname = Convert.ToString(dataReader["o_companyname"]);
                        _defaultresult.Regnumber = Convert.ToString(dataReader["o_regnumber"]);
                        _defaultresult.Address1 = Convert.ToString(dataReader["o_address1"]);
                        _defaultresult.Address2 = Convert.ToString(dataReader["o_address2"]);
                        _defaultresult.Address3 = Convert.ToString(dataReader["o_address3"]);
                        _defaultresult.Country = Convert.ToString(dataReader["o_country"]);
                        _defaultresult.Zipcode = Convert.ToString(dataReader["o_zipcode"]);
                        _defaultresult.Contactnumber = Convert.ToString(dataReader["o_contactnumber"]);
                        _defaultresult.Contactperson = Convert.ToString(dataReader["o_contactperson"]);
                        _defaultresult.Contactpernum = Convert.ToString(dataReader["o_contactpernum"]);
                        _defaultresult.Did = Convert.ToString(dataReader["o_did"]);
                        _defaultresult.Onlineurl = Convert.ToString(dataReader["o_onlineurl"]);
                        _defaultresult.Delivertype = Convert.ToInt32(dataReader["o_delivertype"]);
                        _defaultresult.Ordercomission = Convert.ToInt32(dataReader["o_ordercomission"]);
                        _defaultresult.Hours = Convert.ToString(dataReader["o_hours"]);
                        _defaultresult.Minutes = Convert.ToString(dataReader["o_minutes"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadcompanyOutputs.Add(_defaultresult);
                    }
                }
                npgsqlcon.Close();
            }
            return loadcompanyOutputs;
        }
        public List<Defaultresultset> Customerinfo(Addcustomerinfo addcustomerinfo, ref dynamic dbConfig)
        {
            List<Defaultresultset> Defaultresultset = new List<Defaultresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            dbConfig = getConnection().GetSection("connectionStrings");
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addcustomerinfo", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, Convert.ToInt32(addcustomerinfo.Companyid));
                npgsqlcmd.Parameters.AddWithValue("@i_merchantid", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(addcustomerinfo.Merchantid ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_clientid", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(addcustomerinfo.Clientid ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_secretkey", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(addcustomerinfo.Secretkey ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_secretcode", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(addcustomerinfo.Secretcode ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_authtoken", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(addcustomerinfo.Authtoken ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_pos", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(addcustomerinfo.Pos ?? ""));
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defaultresultset _defaultresult = new Defaultresultset();
                        _defaultresult.Status = Convert.ToInt32(dataReader["o_status"]);
                        _defaultresult.Message = Convert.ToString(dataReader["o_message"]);
                        Defaultresultset.Add(_defaultresult);
                    }
                }
                npgsqlcon.Close();
            }
            return Defaultresultset;
        }
        public List<Defaultresultset> UpdateagentAvailability(string agentextension)
        {
            int iresult = 0;
            List<Defaultresultset> lstDefaultresultset = new List<Defaultresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
           
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("update agentlivestatus set agentstatus='Disconnected' where agentextension = '"+ agentextension + "'", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                iresult = npgsqlcmd.ExecuteNonQuery();
                npgsqlcon.Close();
            }
            Defaultresultset _defaultresult = new Defaultresultset();
            if(iresult>0)
            {
                _defaultresult.Status = 1;
                _defaultresult.Message = "Success";
                lstDefaultresultset.Add(_defaultresult);
            }
            else
            {
                _defaultresult.Status = -1;
                _defaultresult.Message = "Failed";
                lstDefaultresultset.Add(_defaultresult);
            }
            return lstDefaultresultset;
        }
    }
}
