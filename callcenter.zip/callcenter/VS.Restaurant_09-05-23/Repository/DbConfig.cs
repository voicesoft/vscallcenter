﻿namespace VS.Restaurant.Repository
{
    public class DbConfig
    {
        public IConfigurationRoot getConnection()
        {
            var constr = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
            return constr;
        }
    }
}
