﻿using Newtonsoft.Json.Linq;
using Npgsql;
using System.Data;
using VS.Restaurant.Interface;
using VS.Restaurant.Modal;

namespace VS.Restaurant.Repository
{
    public class VSRRepository : DbConfig, VSRRepositoryInterface
    {

        public List<LoginResultset> ValidateLogin(LoginValues loginValues)
        {
            List<LoginResultset> loginResultset = new List<LoginResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.validatelogin", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_username", NpgsqlTypes.NpgsqlDbType.Varchar, loginValues.UserName ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_password", NpgsqlTypes.NpgsqlDbType.Varchar, loginValues.Password ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoginResultset ret = new LoginResultset();
                        ret.Userid = Convert.ToInt32(dataReader["o_userid"]);
                        ret.Password = Convert.ToInt32(dataReader["o_password"]);
                        ret.Name = Convert.ToString(dataReader["o_name"]);
                        ret.Mobile = Convert.ToString(dataReader["o_mobile"]);
                        ret.Emalid = Convert.ToString(dataReader["o_emailid"]);
                        ret.Company = Convert.ToString(dataReader["o_company"]);
                        ret.Companyid = Convert.ToInt32(dataReader["o_companyid"]);
                        ret.Roleid = Convert.ToInt32(dataReader["o_roleid"]);
                        ret.Rolename = Convert.ToString(dataReader["o_rolename"]);
                        ret.Lastlogin = Convert.ToString(dataReader["o_lastlogin"]);
                        ret.Approvetype = Convert.ToInt32(dataReader["o_approvetype"]);
                        ret.Status = Convert.ToInt32(dataReader["o_status"]);
                        ret.Message = Convert.ToString(dataReader["o_message"]);
                        ret.Issuperadmin = Convert.ToInt32(dataReader["o_issuperadmin"]);
                        ret.Isadmin = Convert.ToInt32(dataReader["o_isadmin"]);
                        ret.Hasapprove = Convert.ToInt32(dataReader["o_hasapprove"]);
                        loginResultset.Add(ret);
                    }
                }
                npgsqlcon.Close();
            }
            return loginResultset;
        }
        public Agentloignresut ValidateagentLogin(Agentloign agentloign)
        {
            //List<Agentloignresut> loginResultset = new List<Agentloignresut>();
            Agentloignresut ret = new Agentloignresut();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.validateAgentlogin", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_username", NpgsqlTypes.NpgsqlDbType.Varchar, agentloign.UserName ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_password", NpgsqlTypes.NpgsqlDbType.Varchar, agentloign.UserPassword ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        //  Agentloignresut ret = new Agentloignresut();
                        ret.AgentID = Convert.ToInt32(dataReader["o_agentid"]);
                        ret.AgentName = Convert.ToString(dataReader["o_agentname"]);
                        ret.UserName = Convert.ToString(dataReader["o_username"]);
                        ret.UserMobile = Convert.ToString(dataReader["o_usermobile"]);
                        ret.Configdata = Convert.ToString(dataReader["o_configdata"]);
                        //loginResultset.Add(ret);
                    }
                }
                npgsqlcon.Close();
            }
            return ret;
        }
        #region Itemtype
        public List<Defalutresultset> AddItemtype(AdditemValues additemValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additemtype", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, additemValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemtype", NpgsqlTypes.NpgsqlDbType.Varchar, additemValues.Itemtype ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, additemValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoaditemResultset> LoadItemtype(LoaditemValues loaditemValues, ref Int32 totalrow)
        {
            List<LoaditemResultset> loaditemResultsets = new List<LoaditemResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemtype", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loaditemValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemtype", NpgsqlTypes.NpgsqlDbType.Varchar, loaditemValues.Itemtype ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loaditemValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loaditemValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loaditemValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loaditemValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoaditemResultset loaditemResultset = new LoaditemResultset();
                        loaditemResultset.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        loaditemResultset.Idtype = Convert.ToInt32(dataReader["o_idtype"]);
                        loaditemResultset.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        loaditemResultset.Itemtype = Convert.ToString(dataReader["o_itemtype"]);
                        loaditemResultset.Createdby = Convert.ToString(dataReader["o_createdby"]);
                        loaditemResultset.Createdon = Convert.ToString(dataReader["o_createdon"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loaditemResultsets.Add(loaditemResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loaditemResultsets;
        }
        public List<Defalutresultset> EditItemtype(EdititemValues edititemValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititemtype", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, edititemValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemtypeid", NpgsqlTypes.NpgsqlDbType.Integer, edititemValues.Itemtypeid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemtype", NpgsqlTypes.NpgsqlDbType.Varchar, edititemValues.Itemtype ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, edititemValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItemtype(DeleteitemValues deleteitemValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitemtype", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deleteitemValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemtypeid", NpgsqlTypes.NpgsqlDbType.Integer, deleteitemValues.Itemtypeid);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deleteitemValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deleteitemValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
        #region Itemsize
        public List<Defalutresultset> AddItemsize(AddsizeValues addsizeValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additemsize", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, addsizeValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsize", NpgsqlTypes.NpgsqlDbType.Varchar, addsizeValues.Itemsize ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_hideagent", NpgsqlTypes.NpgsqlDbType.Integer, addsizeValues.Hideagent);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, addsizeValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoadsizeResultset> LoadItemsize(LoadsizeValues loadsizeValues, ref Int32 totalrow)
        {
            List<LoadsizeResultset> loadsizeResultsets = new List<LoadsizeResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemsize", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loadsizeValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsize", NpgsqlTypes.NpgsqlDbType.Varchar, loadsizeValues.Itemsize ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadsizeValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadsizeValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loadsizeValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loadsizeValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadsizeResultset loadsizeResultset = new LoadsizeResultset();
                        loadsizeResultset.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        loadsizeResultset.Idsize = Convert.ToInt32(dataReader["o_idsize"]);
                        loadsizeResultset.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        loadsizeResultset.Itemsize = Convert.ToString(dataReader["o_sizename"]);
                        loadsizeResultset.Createdby = Convert.ToString(dataReader["o_createdby"]);
                        loadsizeResultset.Createdon = Convert.ToString(dataReader["o_createdon"]);
                        loadsizeResultset.Hideagent = Convert.ToInt32(dataReader["o_hideagent"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadsizeResultsets.Add(loadsizeResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadsizeResultsets;
        }
        public List<Defalutresultset> EditItemsize(EditsizeValues editsizeValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititemsize", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editsizeValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Integer, editsizeValues.Itemsizeid);
                npgsqlcmd.Parameters.AddWithValue("@i_sizename", NpgsqlTypes.NpgsqlDbType.Varchar, editsizeValues.Sizename ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_hideagent", NpgsqlTypes.NpgsqlDbType.Integer, editsizeValues.Hideagent);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, editsizeValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItemsize(DeletesizeValues deletesizeValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitemsize", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deletesizeValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Integer, deletesizeValues.Itemsizeid);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deletesizeValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_hideagent", NpgsqlTypes.NpgsqlDbType.Integer, deletesizeValues.Hideagent);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deletesizeValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
        #region Itemmaster
        public List<Defalutresultset> AddItemmaster(AddmasterValues addmasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string sizeids = Newtonsoft.Json.JsonConvert.SerializeObject(addmasterValues.Sizeids);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additemmaster_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemname", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Itemname ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Itemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_sizeid", NpgsqlTypes.NpgsqlDbType.Text, sizeids);
                npgsqlcmd.Parameters.AddWithValue("@i_typeid", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Typeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_haspackage", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Haspackage);
                npgsqlcmd.Parameters.AddWithValue("@i_isaddonitem", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Isaddonitem);
                npgsqlcmd.Parameters.AddWithValue("@i_ismodifier", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Ismodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_applaymodifer", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Applaymodifer);
                npgsqlcmd.Parameters.AddWithValue("@i_imagepath", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, addmasterValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_audiopath", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Audiofile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_category", NpgsqlTypes.NpgsqlDbType.Varchar, addmasterValues.Category ?? "");

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoadmasterResultset> LoadItemmaster(LoadmasterValues loadmasterValues, ref Int32 totalrow)
        {
            List<LoadmasterResultset> loadmasterResultsets = new List<LoadmasterResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemmaster_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_typeid", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Typeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_sizeid", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Sizeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_haspackage", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Haspackage);
                npgsqlcmd.Parameters.AddWithValue("@i_isaddon", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Isaddon);
                npgsqlcmd.Parameters.AddWithValue("@i_ismodifier", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Ismodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_applymodifier", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Applymodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_search", NpgsqlTypes.NpgsqlDbType.Varchar, loadmasterValues.Search ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadmasterValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadmasterValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loadmasterValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadmasterResultset loadmasterResultset = new LoadmasterResultset();
                        sizeinfo sizeinfo = new sizeinfo();
                        //sizeinfo = Newtonsoft.Json.JsonConvert.DeserializeObject(Convert.ToString(dataReader["o_size"]));
                        loadmasterResultset.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        loadmasterResultset.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        loadmasterResultset.Itemcode = Convert.ToInt32(dataReader["o_itemcode"]);
                        loadmasterResultset.Customeritemcode = Convert.ToString(dataReader["o_customeritemcode"]);
                        loadmasterResultset.Itemname = Convert.ToString(dataReader["o_itemname"]);
                        loadmasterResultset.Itemdescription = Convert.ToString(dataReader["o_itemdescription"]);
                        loadmasterResultset.Size = Convert.ToString(dataReader["o_size"]);
                        loadmasterResultset.Typeid = Convert.ToInt16(dataReader["o_typeid"]);
                        loadmasterResultset.Type = Convert.ToString(dataReader["o_type"]);
                        //loadmasterResultset.Haspackage = Convert.ToString(dataReader["o_haspackage"]);
                        loadmasterResultset.Isaddonitem = Convert.ToString(dataReader["o_isaddonitem"]);
                        loadmasterResultset.Ismodifier = Convert.ToString(dataReader["o_ismodifier"]);
                        loadmasterResultset.Applaymodifer = Convert.ToString(dataReader["o_applaymodifer"]);
                        loadmasterResultset.Imagepath = Convert.ToString(dataReader["o_imagepath"]);
                        loadmasterResultset.Username = Convert.ToString(dataReader["o_username"]);
                        loadmasterResultset.Category = Convert.ToString(dataReader["o_category"]);
                        loadmasterResultset.Audiofile = Convert.ToString(dataReader["o_audiofile"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadmasterResultsets.Add(loadmasterResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadmasterResultsets;
        }
        public List<Defalutresultset> EditItemmaster(EditmasterValues editmasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string sizeids = Newtonsoft.Json.JsonConvert.SerializeObject(editmasterValues.Sizeids);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititemmaster_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editmasterValues.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemname", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Itemname ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Itemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_sizeid", NpgsqlTypes.NpgsqlDbType.Varchar, sizeids);
                npgsqlcmd.Parameters.AddWithValue("@i_typeid", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Typeid);
                //npgsqlcmd.Parameters.AddWithValue("@i_haspackage", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Haspackage);
                npgsqlcmd.Parameters.AddWithValue("@i_isaddonitem", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Isaddonitem);
                npgsqlcmd.Parameters.AddWithValue("@i_ismodifier", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Ismodifier);
                npgsqlcmd.Parameters.AddWithValue("@i_applaymodifer", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Applaymodifer);
                npgsqlcmd.Parameters.AddWithValue("@i_imagepath", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, editmasterValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_audiopath", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Audiofile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_category", NpgsqlTypes.NpgsqlDbType.Varchar, editmasterValues.Category ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItemmaster(DeletemasterValues deletemasterValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitemmaster", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deletemasterValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Integer, deletemasterValues.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deletemasterValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deletemasterValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
        #region Itemprice
        public List<Defalutresultset> AddItemprice(AddpriceValues addpriceValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additemprice", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, addpriceValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Numeric, addpriceValues.itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Numeric, addpriceValues.Itemsizeid);
                npgsqlcmd.Parameters.AddWithValue("@i_unitprice", NpgsqlTypes.NpgsqlDbType.Numeric, addpriceValues.Unitprice);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, addpriceValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoadpriceResultset> LoadItemprice(LoadpriceValues loadpriceValues, ref Int32 totalrow)
        {
            List<LoadpriceResultset> loadpriceResultsets = new List<LoadpriceResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemprice", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loadpriceValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Varchar, loadpriceValues.Itemcode??"");
                npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Numeric, loadpriceValues.Itemsizeid);
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadpriceValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadpriceValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loadpriceValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loadpriceValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadpriceResultset loadpriceResultset = new LoadpriceResultset();
                        loadpriceResultset.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        loadpriceResultset.Idprice = Convert.ToInt32(dataReader["o_idprice"]);
                        loadpriceResultset.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        loadpriceResultset.Itemid = Convert.ToInt32(dataReader["o_itemid"]);
                        loadpriceResultset.Itemcode = Convert.ToString(dataReader["o_itemcode"]);
                        loadpriceResultset.Itemsizeid = Convert.ToInt32(dataReader["o_itemsizeid"]);
                        loadpriceResultset.Itemsizename = Convert.ToString(dataReader["o_itemsizename"]);
                        loadpriceResultset.Unitprice = Convert.ToString(dataReader["o_unitprice"]);
                        loadpriceResultset.Createdby = Convert.ToString(dataReader["o_createdby"]);
                        loadpriceResultset.Createdon = Convert.ToString(dataReader["o_createdon"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadpriceResultsets.Add(loadpriceResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadpriceResultsets;
        }
        public List<Defalutresultset> EditItemprice(EditpriceValues editpriceValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititemprice", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editpriceValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_idprice", NpgsqlTypes.NpgsqlDbType.Numeric, editpriceValues.Idprice);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editpriceValues.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Numeric, editpriceValues.Itemsizeid);
                npgsqlcmd.Parameters.AddWithValue("@i_unitprice", NpgsqlTypes.NpgsqlDbType.Numeric, editpriceValues.Unitprice);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, editpriceValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItemprice(DeletepriceValues deletepriceValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitemprice", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deletepriceValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_idprice", NpgsqlTypes.NpgsqlDbType.Integer, deletepriceValues.Idprice);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deletepriceValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deletepriceValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
        #region Itempackage
        public List<Defalutresultset> AddItempackage(AddpackageitemValues addpackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string jsonval = Newtonsoft.Json.JsonConvert.SerializeObject(addpackageValues.Packagevalues);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additempackage_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, addpackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.customeritemcode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritem", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.Masteritem ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.Masteritemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_imagefile", NpgsqlTypes.NpgsqlDbType.Varchar, addpackageValues.Imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Numeric, addpackageValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_jsonval", NpgsqlTypes.NpgsqlDbType.Text, jsonval);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<LoadpackageResultset> LoadItempackage(LoadpackageValues loadpackageValues, ref Int32 totalrow)
        {
            List<LoadpackageResultset> loadpackageResultsets = new List<LoadpackageResultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditempackage_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, loadpackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemname", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Itemname ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_itemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Fromdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_fromdate", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_todate", NpgsqlTypes.NpgsqlDbType.Varchar, loadpackageValues.Todate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, loadpackageValues.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, loadpackageValues.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadpackageResultset loadpackageResultset = new LoadpackageResultset();
                        loadpackageResultset.Sno = Convert.ToInt32(dataReader["sno"]);
                        loadpackageResultset.Customerid = Convert.ToInt32(dataReader["customerid"]);
                        loadpackageResultset.Customeritemcode = Convert.ToString(dataReader["customeritemcode"]);
                        loadpackageResultset.Masteritemid = Convert.ToInt64(dataReader["packageid"]);
                        loadpackageResultset.Itemname = Convert.ToString(dataReader["itemname"]);
                        loadpackageResultset.Itemdescription = Convert.ToString(dataReader["itemdescription"]);
                        loadpackageResultset.Packageitems = Convert.ToString(dataReader["packageitems"]);
                        loadpackageResultset.Createdby = Convert.ToString(dataReader["createby"]);
                        loadpackageResultset.Createdon = Convert.ToString(dataReader["createdon"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadpackageResultsets.Add(loadpackageResultset);
                    }
                }
                npgsqlcon.Close();
            }
            return loadpackageResultsets;
        }
        public List<Defalutresultset> EditItempackage(EditpackageValues editpackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string jsonval = Newtonsoft.Json.JsonConvert.SerializeObject(editpackageValues.Packagevalues);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.edititempackage_json", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_masteritemid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Masteritemid);
                npgsqlcmd.Parameters.AddWithValue("@i_customeritemcode", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Customeritemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_masteritem", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Masteritem ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_masteritemdescription", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Masteritemdescription ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_imagefile", NpgsqlTypes.NpgsqlDbType.Varchar, editpackageValues.Imagepath ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_jsonval", NpgsqlTypes.NpgsqlDbType.Text, jsonval);
                /* npgsqlcmd.CommandType = CommandType.StoredProcedure;
                 npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Customerid);
                 npgsqlcmd.Parameters.AddWithValue("@i_idpackage", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Idpackage);
                 npgsqlcmd.Parameters.AddWithValue("@i_packageitemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Packageitemcode);
                 npgsqlcmd.Parameters.AddWithValue("@i_serialno", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.Serialno);
                 npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Itemcode);
                 npgsqlcmd.Parameters.AddWithValue("@i_itemsizeid", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Itemsizeid);
                 npgsqlcmd.Parameters.AddWithValue("@i_itemprice", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Itemprice);
                 npgsqlcmd.Parameters.AddWithValue("@i_discount", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Discount);
                 npgsqlcmd.Parameters.AddWithValue("@i_unitprice", NpgsqlTypes.NpgsqlDbType.Numeric, editpackageValues.Unitprice);
                 npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, editpackageValues.userid);*/
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Defalutresultset> DeleteItempackage(DeletepackageValues deletepackageValues)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteitempackage", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deletepackageValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_idpackage", NpgsqlTypes.NpgsqlDbType.Integer, deletepackageValues.Masteritemid);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, deletepackageValues.Reason ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deletepackageValues.Userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        #endregion
    }
}
