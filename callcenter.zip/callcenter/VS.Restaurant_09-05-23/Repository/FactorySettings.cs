﻿using Npgsql;
using Org.BouncyCastle.Ocsp;
using System.Data;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Repository
{
    public class FactorySettings : DbConfig, IFactorySettings
    {
        public DefaultResponse AddBlackList(ReqBlackList reqBlack)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addcustomerblaglistnumbers", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqBlack.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqBlack.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_contactnumber", NpgsqlTypes.NpgsqlDbType.Varchar, reqBlack.Contactnumber ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_consumername", NpgsqlTypes.NpgsqlDbType.Varchar, reqBlack.Consumername ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_isblock", NpgsqlTypes.NpgsqlDbType.Integer, reqBlack.Isblock);
                npgsqlcmd.Parameters.AddWithValue("@i_reason", NpgsqlTypes.NpgsqlDbType.Varchar, reqBlack.Reason ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse RemoveBlackList(ReqRemoveBlackList reqRemoveBlackList)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.removecustomerblaglist", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveBlackList.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveBlackList.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_transid", NpgsqlTypes.NpgsqlDbType.Bigint, reqRemoveBlackList.TransId);
                npgsqlcmd.Parameters.AddWithValue("@i_isblock", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveBlackList.Block);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<ResLoadBlacList> GetBlackList(ReqLoadBlacList reqLoadBlacList, ref int totalrows)
        {
            List<ResLoadBlacList> _default = new List<ResLoadBlacList>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadblocklist", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqLoadBlacList.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, reqLoadBlacList.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, reqLoadBlacList.Pagesize);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResLoadBlacList
                        {
                            Consumername = Convert.ToString(dataReader["o_consumername"]),
                            Contactnumber = Convert.ToString(dataReader["o_contactnumber"]),
                            Createdby = Convert.ToString(dataReader["o_createdby"]),
                            Createdon = Convert.ToString(dataReader["o_createdon"]),
                            idblock = Convert.ToInt64(dataReader["o_idblock"]),
                            Reason = Convert.ToString(dataReader["o_reason"]),
                            Sno = Convert.ToInt32(dataReader["o_sno"])
                        });

                        totalrows = Convert.ToInt32(dataReader["o_totalrow"]);
                    }
                }
            }
            return _default;
        }
        public DefaultResponse AddFactoryPauseTimings(ReqFactoryPause reqFactoryPause)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addfactoryorderpausesettings", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqFactoryPause.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqFactoryPause.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_minutes", NpgsqlTypes.NpgsqlDbType.Integer, reqFactoryPause.Minutes);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse RemoveFactoryPauseTimings(ReqRemoveItem reqRemoveItem)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.removefactoryorderpausesettings", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_transid", NpgsqlTypes.NpgsqlDbType.Bigint, reqRemoveItem.TransId);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<ResDelayList> GetFactoryPauseTimings(ReqDelay reqDelay)
        {
            List<ResDelayList> _default = new List<ResDelayList>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadfactorypausesettings", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqDelay.Customerid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResDelayList
                        {
                            Sno = Convert.ToInt32(dataReader["o_sno"]),
                            Transid = Convert.ToInt64(dataReader["o_transid"]),
                            Starttime = Convert.ToString(dataReader["o_starttime"]),
                            Endtime = Convert.ToString(dataReader["o_endtime"]),
                            Createdby = Convert.ToString(dataReader["o_createdby"]),
                            Createdon = Convert.ToString(dataReader["o_createdon"]),
                            Delayminutes = Convert.ToInt32(dataReader["o_minutes"])
                        });

                    }
                }
            }
            return _default;
        }
        public DefaultResponse AddItemDelay(ReqItemDelays reqItemDelays)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addfactoringitemdelays", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemDelays.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemDelays.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Bigint, reqItemDelays.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_minutes", NpgsqlTypes.NpgsqlDbType.Integer, reqItemDelays.Minutes);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse RemoveItemDelay(ReqRemoveItem reqRemoveItem)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.removefactoringitemdelays", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_transid", NpgsqlTypes.NpgsqlDbType.Bigint, reqRemoveItem.TransId);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<ResItemList> GetItemDelayList(ReqItemList reqItemList, ref int totalrows)
        {
            List<ResItemList> _default = new List<ResItemList>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemdelay", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_date", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemList.Starttime ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResItemList
                        {
                            Sno = Convert.ToInt32(dataReader["o_sno"]),
                            Transid = Convert.ToInt64(dataReader["o_transid"]),
                            Itemcode = Convert.ToInt64(dataReader["o_itemcode"]),
                            Itemname = Convert.ToString(dataReader["o_itemname"]),
                            Starttime = Convert.ToString(dataReader["o_starttime"]),
                            Endtime = Convert.ToString(dataReader["o_endtime"]),
                            Createdby = Convert.ToString(dataReader["o_createdby"]),
                            Createdon = Convert.ToString(dataReader["o_createdon"]),
                            Delayminutes = Convert.ToInt32(dataReader["o_minutes"])
                        });
                        totalrows = Convert.ToInt32(dataReader["o_totalrow"]);
                    }
                }
            }
            return _default;
        }
        public DefaultResponse AddItemOfTheDay(ReqItemOfTheDay reqItemOfTheDay)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additemoftheday", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemOfTheDay.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemOfTheDay.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Bigint, reqItemOfTheDay.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_starttime", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemOfTheDay.Starttime ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse RemoveItemOfTheDay(ReqRemoveItem reqRemoveItem)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.removeitemoftheday", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_transid", NpgsqlTypes.NpgsqlDbType.Bigint, reqRemoveItem.TransId);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse AddItemPromotion(ReqItemPromotion reqItemPromotion)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.additempromotion", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemPromotion.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemPromotion.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Bigint, reqItemPromotion.Itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_starttime", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemPromotion.Starttime ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_endtime", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemPromotion.Endtime ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse RemoveItemPromotion(ReqRemoveItem reqRemoveItem)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.removeitempromotion", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_transid", NpgsqlTypes.NpgsqlDbType.Bigint, reqRemoveItem.TransId);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<ResItemList> GetItemPromotion(ReqItemList reqItemList, ref int totalrows)
        {
            List<ResItemList> _default = new List<ResItemList>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditempromotion", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_date", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemList.Starttime ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResItemList
                        {
                            Sno = Convert.ToInt32(dataReader["o_sno"]),
                            Transid = Convert.ToInt64(dataReader["o_transid"]),
                            Itemcode = Convert.ToInt64(dataReader["o_itemcode"]),
                            Itemname = Convert.ToString(dataReader["o_itemname"]),
                            Starttime = Convert.ToString(dataReader["o_starttime"]),
                            Endtime = Convert.ToString(dataReader["o_endtime"]),
                            Createdby = Convert.ToString(dataReader["o_createdby"]),
                            Createdon = Convert.ToString(dataReader["o_createdon"]),

                        });
                        totalrows = Convert.ToInt32(dataReader["o_totalrow"]);
                    }
                }
            }
            return _default;
        }
        public List<ResItemList> GetItemOfTheDay(ReqItemList reqItemList, ref int totalrows)
        {
            List<ResItemList> _default = new List<ResItemList>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loaditemoftheday", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_date", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemList.Starttime ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResItemList
                        {
                            Sno = Convert.ToInt32(dataReader["o_sno"]),
                            Transid = Convert.ToInt64(dataReader["o_transid"]),
                            Itemcode = Convert.ToInt64(dataReader["o_itemcode"]),
                            Itemname = Convert.ToString(dataReader["o_itemname"]),
                            Starttime = Convert.ToString(dataReader["o_starttime"]),
                            Endtime = Convert.ToString(dataReader["o_endtime"]),
                            Createdby = Convert.ToString(dataReader["o_createdby"]),
                            Createdon = Convert.ToString(dataReader["o_createdon"]),
                            Delayminutes = 0
                        });
                        totalrows = Convert.ToInt32(dataReader["o_totalrow"]);
                    }
                }
            }
            return _default;
        }
        public List<ResDelayList> GetOverAllOrderDelay(ReqDelay reqDelay)
        {
            List<ResDelayList> _default = new List<ResDelayList>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadoverallorderdelays", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqDelay.Customerid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResDelayList
                        {
                            Sno = Convert.ToInt32(dataReader["o_sno"]),
                            Transid = Convert.ToInt64(dataReader["o_transid"]),
                            Starttime = Convert.ToString(dataReader["o_starttime"]),
                            Endtime = Convert.ToString(dataReader["o_endtime"]),
                            Createdby = Convert.ToString(dataReader["o_createdby"]),
                            Createdon = Convert.ToString(dataReader["o_createdon"]),
                            Delayminutes = Convert.ToInt32(dataReader["o_minutes"])
                        });

                    }
                }
            }
            return _default;
        }
        public DefaultResponse AddOverAllOrderDelay(ReqAddOverAllDelay reqAddOverAllDelay)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addoverallorderdelays", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqAddOverAllDelay.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqAddOverAllDelay.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_minutes", NpgsqlTypes.NpgsqlDbType.Varchar, reqAddOverAllDelay.Delayminutes);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse RemoveOverAllOrderDelay(ReqRemoveItem reqRemoveItem)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.Removeoverallorderdelays", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, reqRemoveItem.Userid);
                npgsqlcmd.Parameters.AddWithValue("@i_transid", NpgsqlTypes.NpgsqlDbType.Bigint, reqRemoveItem.TransId);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<ResAddBalcklistmembers> getBlacklistmembers(ReqAddBalcklistmembers reqItemList, ref int totalrows)
        {
            List<ResAddBalcklistmembers> _default = new List<ResAddBalcklistmembers>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getorderreportsummary", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Pageno);
                npgsqlcmd.Parameters.AddWithValue("@i_pagesize", NpgsqlTypes.NpgsqlDbType.Integer, reqItemList.Pagesize);
                npgsqlcmd.Parameters.AddWithValue("@i_date", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemList.date ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_searchtext", NpgsqlTypes.NpgsqlDbType.Varchar, reqItemList.Searchtext ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Add(new ResAddBalcklistmembers
                        {
                            Sno = Convert.ToInt32(dataReader["o_sno"]),
                            Consumerid = Convert.ToInt64(dataReader["o_consumerid"]),
                            Consumername = Convert.ToString(dataReader["o_consumername"]),
                            Contactno = Convert.ToString(dataReader["o_contactno"]),
                            Orderid = Convert.ToInt64(dataReader["o_orderid"]),
                            Orderdate = Convert.ToString(dataReader["o_orderdate"]),
                            Orderstatus = Convert.ToString(dataReader["o_orderstatus"]),
                            Noofitems = Convert.ToInt32(dataReader["o_noofitems"]),
                            Amount = Convert.ToDecimal(dataReader["o_amount"]),
                            Taxamount = Convert.ToDecimal(dataReader["o_taxamount"]),
                            Totalamount = Convert.ToDecimal(dataReader["o_totalamount"]),
                            Deliverytime = Convert.ToInt32(dataReader["o_deliverytime"]),

                        });
                        totalrows = Convert.ToInt32(dataReader["o_totalrow"]);
                    }
                }
            }
            return _default;
        }
    }
}
