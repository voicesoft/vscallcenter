﻿using Npgsql;
using Org.BouncyCastle.Ocsp;
using System.Data;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Repository
{
    public class CRUDAgents : DbConfig, IAgentRepository
    {
        public Defalutresultset CreateAgent(CreateAgents _agent)
        {
            Defalutresultset _defalutresultsets = new Defalutresultset();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string Languageids = Newtonsoft.Json.JsonConvert.SerializeObject(_agent.Languagelist);
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addagent_new", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_agentname", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.AgentName ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_agentcity", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.AgentCity ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_username", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.UserName ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userpassword", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.UserPassword ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_usermobile", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.UserMobile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_extension", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.Extension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_extensionpwd", NpgsqlTypes.NpgsqlDbType.Varchar, _agent.Extensionpwd ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, _agent.CreatedBy ?? 0);
                npgsqlcmd.Parameters.AddWithValue("@i_isadmin", NpgsqlTypes.NpgsqlDbType.Integer, _agent.Isadmin);
                npgsqlcmd.Parameters.AddWithValue("@i_languagelist", NpgsqlTypes.NpgsqlDbType.Text, Languageids);
                npgsqlcmd.Parameters.AddWithValue("@i_rmid", NpgsqlTypes.NpgsqlDbType.Integer, _agent.Rmid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _defalutresultsets.Status = Convert.ToInt32(dataReader["o_status"]);
                        _defalutresultsets.Message = Convert.ToString(dataReader["o_message"]);
                    }
                }
                npgsqlcon.Close();
            }
            return _defalutresultsets;
        }     
        List<Agents> IAgentRepository.GetAllAgents(int userid)
        {
            List<Agents> _lstAgents = new List<Agents>();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadagent", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, userid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Agents objAgent = new Agents();
                        objAgent.AgentName = Convert.ToString(dataReader["o_agentname"]);
                        objAgent.AgentCity = Convert.ToString(dataReader["o_agentcity"]);
                        objAgent.UserMobile = Convert.ToString(dataReader["o_usermobile"]);
                        objAgent.UserName = Convert.ToString(dataReader["o_username"]);
                        objAgent.User = Convert.ToString(dataReader["o_createdby"]);
                        objAgent.Extension = Convert.ToString(dataReader["o_extension"]);
                        objAgent.Extensionpwd = Convert.ToString(dataReader["o_extensionpwd"]);
                        _lstAgents.Add(objAgent);

                    }
                }
                npgsqlcon.Close();
            }

            return _lstAgents;
        }
    }
}
