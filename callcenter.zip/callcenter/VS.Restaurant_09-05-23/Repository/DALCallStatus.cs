﻿using Microsoft.VisualBasic;
using Npgsql;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Ocsp;
using System.Collections.ObjectModel;
using System.Data;
using System.Net.NetworkInformation;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;

namespace VS.Restaurant.Repository
{
    public class DALCallStatus : DbConfig, ICallStatus
    {
        public DefaultResponse UpdateQueueLogs(ReqQueueLog reqQueueLog)
        {
            DefaultResponse _default = new DefaultResponse();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updatequeuelog", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_callid", NpgsqlTypes.NpgsqlDbType.Varchar, reqQueueLog.callid ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_queuename", NpgsqlTypes.NpgsqlDbType.Varchar, reqQueueLog.queuename ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_agent", NpgsqlTypes.NpgsqlDbType.Varchar, reqQueueLog.agent ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_event", NpgsqlTypes.NpgsqlDbType.Varchar, reqQueueLog.events ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_created", NpgsqlTypes.NpgsqlDbType.Varchar, reqQueueLog.created ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<AgentStatusResultset> GetLanguage(int agentid)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<AgentStatusResultset> loadagentsets = new List<AgentStatusResultset>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getlanguage", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_idagent", NpgsqlTypes.NpgsqlDbType.Integer, agentid);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        AgentStatusResultset loadagentdata = new AgentStatusResultset();
                        loadagentdata.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        loadagentdata.Languagelist = Convert.ToString(dataReader["o_languagelist"]);
                        loadagentsets.Add(loadagentdata);
                        //break;
                    }
                }                
            }
            return loadagentsets;
        }
        public DefaultResponse AgentStausUpdate(AgentStatusUpdate _req)
        {
            DefaultResponse _default = new DefaultResponse();
           
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updateagentstatus", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, _req.AgentId);
                npgsqlcmd.Parameters.AddWithValue("@i_extension", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Extension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_status", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Registered ?? "");
                
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;            
        }

        public DefaultResponse AgentCallStatus(LiveAgents _req)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updateagentcallstatus", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_agentid", NpgsqlTypes.NpgsqlDbType.Integer, _req.AgentId);
                npgsqlcmd.Parameters.AddWithValue("@i_extension", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Extension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_status", NpgsqlTypes.NpgsqlDbType.Integer, _req.InCall);
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _req.DID ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }

        public AllocatedExtension GetorSetAgentData(IncomingCall _req)
        {
            AllocatedExtension _default = new AllocatedExtension();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getorsetagentdata", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _req.DID ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callerid", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallerId ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_preextension", NpgsqlTypes.NpgsqlDbType.Varchar, _req.PreExtension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_jsonagents", NpgsqlTypes.NpgsqlDbType.Text, Newtonsoft.Json.JsonConvert.SerializeObject(_req.Agents));
                npgsqlcmd.Parameters.AddWithValue("@i_uniqueid", NpgsqlTypes.NpgsqlDbType.Varchar, _req.UniqueID ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Extension = Convert.ToString(dataReader["o_extension"]);
                        _default.Record = Convert.ToString(dataReader["o_recordcall"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public AllocatedExtension GetorSetAgenQueueData(IncomingCall _req)
        {
            AllocatedExtension _default = new AllocatedExtension();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getorsetagentdataforcall", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _req.DID ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callerid", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallerId ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_preextension", NpgsqlTypes.NpgsqlDbType.Varchar, _req.PreExtension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_jsonagents", NpgsqlTypes.NpgsqlDbType.Text, Newtonsoft.Json.JsonConvert.SerializeObject(_req.Agents));
                npgsqlcmd.Parameters.AddWithValue("@i_uniqueid", NpgsqlTypes.NpgsqlDbType.Varchar, _req.UniqueID ?? "");
                
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Extension = Convert.ToString(dataReader["o_extension"]);
                        _default.Record = Convert.ToString(dataReader["o_recordcall"]);
                        _default.Manager = Convert.ToInt32(dataReader["o_manager"]);
                        _default.Queue = Convert.ToString(dataReader["o_queue"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public DefaultResponse UpdateCallLog(CallLog _req)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string[] arruniqueid = _req.RecordingFile.Split('-');
            string lstruniqueid = "";
            if(arruniqueid.Length>=2)
            {
                lstruniqueid = arruniqueid[1];
            }
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updatecalllog", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _req.DID ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callerid", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallerId ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callstarttime", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallStartTime ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callendtime", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallEndTime ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_voicefilepath", NpgsqlTypes.NpgsqlDbType.Varchar, _req.RecordingFile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_extension", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Extension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callstatus", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallStatus ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_duration", NpgsqlTypes.NpgsqlDbType.Integer, _req.Duration);
                npgsqlcmd.Parameters.AddWithValue("@i_voice", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Voicemessage ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_uniqueid", NpgsqlTypes.NpgsqlDbType.Varchar, lstruniqueid ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }

        public AudioData UpdateTrainingCallLog(TCallLog _req)
        {
            AudioData audioData = new AudioData();
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updatetrainingcalllog", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _req.DID ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callerid", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallerId ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callstarttime", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallStartTime ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callendtime", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallEndTime ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_voicefilepath", NpgsqlTypes.NpgsqlDbType.Varchar, _req.RecordingFile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_extension", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Extension ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_callstatus", NpgsqlTypes.NpgsqlDbType.Varchar, _req.CallStatus ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_duration", NpgsqlTypes.NpgsqlDbType.Integer, _req.Duration);
                npgsqlcmd.Parameters.AddWithValue("@i_voice", NpgsqlTypes.NpgsqlDbType.Varchar, _req.Voicemessage ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_audio", NpgsqlTypes.NpgsqlDbType.Varchar, _req.audio ?? "");
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        audioData.audio = Convert.ToString(dataReader["o_audio"]).Replace(".wav", "");
                        audioData.did =  Convert.ToString(dataReader["o_did"]);
                        audioData.cid = Convert.ToString(dataReader["o_cid"]);
                        audioData.extesion = Convert.ToString(dataReader["o_extension"]);
                        audioData.status = Convert.ToString(dataReader["o_status"]);
                        audioData.wait = Convert.ToString(dataReader["o_wait"]);
                        break;
                    }
                }
            }
            return audioData;
        }
        public DefaultResponse UpdateCurrentAgentStatus(List<AgentList> _req)
        {
            DefaultResponse _default = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updatecurrentagentstatus", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_agentjson", NpgsqlTypes.NpgsqlDbType.Text, Newtonsoft.Json.JsonConvert.SerializeObject(_req) ?? "[]");

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
        public List<Companyddl> Loadcompany()
        {
            List<Companyddl> resultlist = new List<Companyddl>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                string query = "select idcustomer as restaurantid,companyname as restaurantname from mastercustomer WHERE isactive=1 order by companyname asc";
                var npgsqlcmd = new NpgsqlCommand(query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Companyddl result = new Companyddl();
                        result.Restaurantid = Convert.ToInt32(dataReader["restaurantid"]);
                        result.Restaurantname = Convert.ToString(dataReader["restaurantname"]);
                        resultlist.Add(result);
                    }
                }
            }
            return resultlist;
        }
        public AudioData InitiateTraining(RequestStartStop requestStartStop)
        {
            AudioData objAudio = new AudioData();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getaudiosstopstart", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_agent", NpgsqlTypes.NpgsqlDbType.Integer, requestStartStop.AgentId);
                npgsqlcmd.Parameters.AddWithValue("@i_action", NpgsqlTypes.NpgsqlDbType.Varchar, requestStartStop.Action);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        objAudio.audio = Convert.ToString(dataReader["o_audio"]).Replace(".wav", "");
                        objAudio.did = Convert.ToString(dataReader["o_did"]);
                        objAudio.cid = Convert.ToString(dataReader["o_cid"]);
                        objAudio.extesion = Convert.ToString(dataReader["o_extension"]);
                        objAudio.status = Convert.ToString(dataReader["o_status"]);
                        objAudio.wait = Convert.ToString(dataReader["o_wait"]);
                        break;
                    }
                }
            }
            return objAudio;
        }
        public List<Defalutresultset> Uploadaudio(AddReqUploadTrainingAudio requploadaudio)
        {
            List<Defalutresultset> defalutresultsets = new List<Defalutresultset>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.uploadaudiofile", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, requploadaudio.CustomerId);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, requploadaudio.UserId);
                npgsqlcmd.Parameters.AddWithValue("@i_audiofile", NpgsqlTypes.NpgsqlDbType.Varchar, requploadaudio.Audiofile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_audiofilewithextension", NpgsqlTypes.NpgsqlDbType.Varchar, requploadaudio.Audiofilewithextension ?? "");


                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Defalutresultset defalutresultset = new Defalutresultset();
                        defalutresultset.Status = Convert.ToInt32(dataReader["o_status"]);
                        defalutresultset.Message = Convert.ToString(dataReader["o_message"]);
                        defalutresultsets.Add(defalutresultset);
                    }
                }
                npgsqlcon.Close();
            }
            return defalutresultsets;
        }
        public List<Loadallaudioop> Loadallaudio(LoadcompanyInput loadcompanyInput, ref int totalrow)
        {
            List<Loadallaudioop> loadcompanyOutputs = new List<Loadallaudioop>();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string audiopath = getConnection().GetSection("connectionStrings").GetSection("audiodownload").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadorderaudiofiles", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_search", NpgsqlTypes.NpgsqlDbType.Varchar, Convert.ToString(loadcompanyInput.Search ?? ""));
                npgsqlcmd.Parameters.AddWithValue("@i_pageno", NpgsqlTypes.NpgsqlDbType.Integer, Convert.ToInt32(loadcompanyInput.pageno));
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        Loadallaudioop _defaultresult = new Loadallaudioop();
                        _defaultresult.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        _defaultresult.Customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        _defaultresult.Customername = Convert.ToString(dataReader["o_customername"]);
                        _defaultresult.Companyname = Convert.ToString(dataReader["o_companyname"]);
                        _defaultresult.DID = Convert.ToString(dataReader["o_did"]);
                        _defaultresult.Createdby = Convert.ToString(dataReader["o_createdby"]);
                        _defaultresult.Createdon = Convert.ToString(dataReader["o_createdon"]);
                        if (Convert.ToString(dataReader["o_audiopath"]) != "")
                            _defaultresult.Audiopath = audiopath + Convert.ToString(dataReader["o_audiopath"]);
                        else
                            _defaultresult.Audiopath = Convert.ToString(dataReader["o_audiopath"]);
                        totalrow = Convert.ToInt32(dataReader["o_totalrow"]);
                        loadcompanyOutputs.Add(_defaultresult);
                    }
                }
                npgsqlcon.Close();
            }
            return loadcompanyOutputs;
        }
        public Defalutresultset Deleteaudiofile(DeleteaudiofileIP deleteaudiofileValues)
        {
            Defalutresultset _default = new Defalutresultset();

            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.deleteaudiofile", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, deleteaudiofileValues.Customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, deleteaudiofileValues.Userid);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        _default.Status = Convert.ToInt32(dataReader["o_status"]);
                        _default.Message = Convert.ToString(dataReader["o_message"]);
                        break;
                    }
                }
            }
            return _default;
        }
    }
}
