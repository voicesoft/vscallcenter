﻿using MailKit.Search;
using Npgsql;
using NpgsqlTypes;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Ocsp;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Security.Cryptography;
using VS.Restaurant.Modal;
using VS.Restaurant.Repository.Interfaces;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace VS.Restaurant.Repository
{
    public class Order : DbConfig, IOrder
    {
        public DefaultResponse CreateNewOrder(OrderHeader _order)
        {
            DefaultResponse _defalutresultsets = new DefaultResponse();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            Int64 cusumerid = 0;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.consumer", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _order.DID ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, _order.CustomerId);
                npgsqlcmd.Parameters.AddWithValue("@i_consumername", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerName ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_address1", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerAddress1 ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_address2", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerAddress2 ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_city", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerCity ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_state", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerState ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_zipcode", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ZipCode ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_country", NpgsqlTypes.NpgsqlDbType.Varchar, "");
                npgsqlcmd.Parameters.AddWithValue("@i_mobile", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerMobile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_altmobile", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.ConsumerAltMobile ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, _order.UserId);
                npgsqlcmd.Parameters.AddWithValue("@i_queue", NpgsqlTypes.NpgsqlDbType.Varchar, _order.Buyer.queuename ?? ""); 
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        cusumerid = Convert.ToInt64(dataReader["o_cusumerid"]);
                        break;
                    }
                }


                if (cusumerid > 0)
                {

                    npgsqlcmd = new NpgsqlCommand("public.createorder", npgsqlcon);
                    npgsqlcmd.CommandType = CommandType.StoredProcedure;
                    npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, _order.DID ?? "");
                    npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, _order.CustomerId);
                    npgsqlcmd.Parameters.AddWithValue("@i_consumerid", NpgsqlTypes.NpgsqlDbType.Bigint, cusumerid);
                    npgsqlcmd.Parameters.AddWithValue("@i_noofitems", NpgsqlTypes.NpgsqlDbType.Integer, _order.NoOfItems);
                    npgsqlcmd.Parameters.AddWithValue("@i_grossamount", NpgsqlTypes.NpgsqlDbType.Numeric, _order.GrossAmount);
                    npgsqlcmd.Parameters.AddWithValue("@i_taxamount", NpgsqlTypes.NpgsqlDbType.Numeric, _order.TaxAmount);
                    npgsqlcmd.Parameters.AddWithValue("@i_totalamount", NpgsqlTypes.NpgsqlDbType.Numeric, _order.TotalAmount);
                    npgsqlcmd.Parameters.AddWithValue("@i_itemdetails", NpgsqlTypes.NpgsqlDbType.Text, Newtonsoft.Json.JsonConvert.SerializeObject(_order.ItemDetails));
                    npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, _order.UserId);

                    using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                    {
                        while (dataReader.Read())
                        {
                            _defalutresultsets.Status = Convert.ToInt32(dataReader["o_status"]);
                            _defalutresultsets.Message = Convert.ToString(dataReader["o_message"]);
                            _defalutresultsets.OrderId = Convert.ToInt64(dataReader["o_orderid"]);
                            break;
                        }
                    }
                }
                npgsqlcon.Close();
            }
            return _defalutresultsets;
        }
        public List<FinishedItemDetails> GetFinishedItems(int UserId, string DID)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<FinishedItemDetails> lstFinishedItems = new List<FinishedItemDetails>();
            string audiopath = getConnection().GetSection("connectionStrings").GetSection("audiodownloadPath").Value;
            string imagepath = getConnection().GetSection("connectionStrings").GetSection("imagedownloadPath").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.searchitems", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, UserId);
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, DID);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        FinishedItemDetails finishedItemDetails = new FinishedItemDetails();
                        finishedItemDetails.ItemCode = Convert.ToInt64(dataReader["o_itemcode"]);
                        finishedItemDetails.CustomerItemCode = Convert.ToString(dataReader["o_custitemcode"]);
                        finishedItemDetails.ItemName = Convert.ToString(dataReader["o_itemname"]);
                        finishedItemDetails.UnitPrice = Convert.ToDecimal(dataReader["o_unitprice"]);
                        finishedItemDetails.PackageItem = Convert.ToInt32(dataReader["o_ispackage"]);
                        finishedItemDetails.IsAddOn = Convert.ToInt32(dataReader["o_isaddon"]);
                        finishedItemDetails.IsModifier = Convert.ToInt32(dataReader["o_ismodifier"]);
                        finishedItemDetails.PackageDetails = Convert.ToString(dataReader["o_packagedetails"]);
                        finishedItemDetails.AddOnDetails = Convert.ToString(dataReader["o_addondetails"]);
                        finishedItemDetails.ModifierDetails = Convert.ToString(dataReader["o_modifierdetails"]);
                        finishedItemDetails.Idsize = Convert.ToInt32(dataReader["o_itemsizeid"]);
                        finishedItemDetails.SizeName = Convert.ToString(dataReader["o_sizename"]);
                        finishedItemDetails.Description = Convert.ToString(dataReader["o_description"]);
                        finishedItemDetails.Isoutofstock = Convert.ToInt32(dataReader["o_isoutofstock"]);
                        finishedItemDetails.Customermobile = Convert.ToString(dataReader["o_customermobile"]);
                        finishedItemDetails.Itemtype = Convert.ToString(dataReader["o_itemtype"]);
                        finishedItemDetails.Restname = Convert.ToString(dataReader["o_restname"]);
                        finishedItemDetails.Category = Convert.ToString(dataReader["o_category"]);
                        if (Convert.ToString(dataReader["o_audiopath"]) != "")
                            finishedItemDetails.Audiopath = audiopath + Convert.ToString(dataReader["o_audiopath"]);
                        else
                            finishedItemDetails.Audiopath = Convert.ToString(dataReader["o_audiopath"]);
                        finishedItemDetails.Itemoftheday = Convert.ToInt32(dataReader["o_itemoftheday"]);
                        finishedItemDetails.Itempromotion = Convert.ToInt32(dataReader["o_itempromotion"]);
                        finishedItemDetails.Itemdelay = Convert.ToInt32(dataReader["o_itemdelay"]);
                        finishedItemDetails.Itemdelaymins = Convert.ToInt32(dataReader["o_itemdelaymin"]);
                        finishedItemDetails.Isown = Convert.ToInt32(dataReader["o_isown"]);
                        if (Convert.ToString(dataReader["o_imagepath"]) != "")
                            finishedItemDetails.Imagepath = imagepath + Convert.ToString(dataReader["o_imagepath"]);
                        else
                            finishedItemDetails.Imagepath = Convert.ToString(dataReader["o_imagepath"]);
                        lstFinishedItems.Add(finishedItemDetails);
                    }
                }
                npgsqlcon.Close();
            }
            return lstFinishedItems;
        }
        public List<PckItems> GetSearchItems(int UserId, int CustomerId)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<PckItems> lstFinishedItems = new List<PckItems>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getsearchitems", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, CustomerId);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, UserId);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        PckItems finishedItemDetails = new PckItems();
                        finishedItemDetails.ItemCode = Convert.ToInt64(dataReader["o_itemcode"]);
                        finishedItemDetails.ItemName = Convert.ToString(dataReader["o_itemname"]);
                        finishedItemDetails.Description = Convert.ToString(dataReader["o_description"]);
                        finishedItemDetails.ImagePath = Convert.ToString(dataReader["o_imagepath"]);
                        lstFinishedItems.Add(finishedItemDetails);
                    }
                }
                npgsqlcon.Close();
            }
            return lstFinishedItems;
        }
        public List<ItemPriceDetails> GetItemsizebyItemcode(int UserId, int CustomerId, Int64 Itemcode)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<ItemPriceDetails> lstFinishedItems = new List<ItemPriceDetails>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getitemsizebyitemcode", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_companyid", NpgsqlTypes.NpgsqlDbType.Integer, CustomerId);
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, UserId);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Bigint, Itemcode);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        ItemPriceDetails finishedItemDetails = new ItemPriceDetails();
                        finishedItemDetails.ItemCode = Convert.ToInt64(dataReader["o_itemcode"]);
                        finishedItemDetails.ItemPrize = Convert.ToDecimal(dataReader["o_unitprice"]);
                        finishedItemDetails.ItemSize = Convert.ToString(dataReader["o_sizename"]);
                        finishedItemDetails.ItemSizeId = Convert.ToInt32(dataReader["o_idsize"]);
                        lstFinishedItems.Add(finishedItemDetails);
                    }
                }
                npgsqlcon.Close();
            }
            return lstFinishedItems;
        }
        public List<OrderHeaderInfo> GetOrderHeaderInfo(int CustomerId)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<OrderHeaderInfo> lstOrder = new List<OrderHeaderInfo>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getorderheader", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, CustomerId);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        OrderHeaderInfo currentRow = new OrderHeaderInfo();
                        currentRow.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        currentRow.ConsumerId = Convert.ToInt64(dataReader["o_consumerid"]);
                        currentRow.ConsumerName = Convert.ToString(dataReader["o_consumername"]);
                        currentRow.ContactNo = Convert.ToString(dataReader["o_contactno"]);
                        currentRow.Orderid = Convert.ToInt64(dataReader["o_orderid"]);
                        currentRow.OrderDate = Convert.ToString(dataReader["o_orderdate"]);
                        currentRow.OrderStatus = Convert.ToString(dataReader["o_orderstatus"]);
                        currentRow.NoofItems = Convert.ToInt32(dataReader["o_noofitems"]);
                        currentRow.Amount = Convert.ToDecimal(dataReader["o_amount"]);
                        currentRow.TaxAmount = Convert.ToDecimal(dataReader["o_taxamount"]);
                        currentRow.TotalAmount = Convert.ToDecimal(dataReader["o_totalamount"]);
                        currentRow.DeliveryTime = Convert.ToInt32(dataReader["o_deliverytime"]);
                        currentRow.OrderTime = Convert.ToString(dataReader["o_ordertime"]);
                        lstOrder.Add(currentRow);
                    }
                }
                npgsqlcon.Close();
            }
            return lstOrder;
        }
        public List<OrderDetailsInfo> GetOrderDetailsbyOrderno(int CustomerId, Int64 OrderNo)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<OrderDetailsInfo> lstOrder = new List<OrderDetailsInfo>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.getorderdetailsbyorderno", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, CustomerId);
                npgsqlcmd.Parameters.AddWithValue("@i_orderno", NpgsqlTypes.NpgsqlDbType.Bigint, OrderNo);
                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        OrderDetailsInfo currentRow = new OrderDetailsInfo();
                        currentRow.Sno = Convert.ToInt32(dataReader["o_sno"]);
                        currentRow.SerialNo = Convert.ToInt32(dataReader["o_serailno"]);
                        currentRow.ItemCode = Convert.ToInt64(dataReader["o_itemcode"]);
                        currentRow.ItemName = Convert.ToString(dataReader["o_itemname"]);
                        currentRow.IdSize = Convert.ToInt32(dataReader["o_idsize"]);
                        currentRow.SizeName = Convert.ToString(dataReader["o_sizename"]);
                        currentRow.Qty = Convert.ToInt32(dataReader["o_qty"]);
                        currentRow.UnitPrice = Convert.ToDecimal(dataReader["o_unitprice"]);
                        currentRow.Amount = Convert.ToDecimal(dataReader["o_amount"]);
                        currentRow.TaxAmount = Convert.ToDecimal(dataReader["o_taxamount"]);
                        currentRow.TotalAmount = Convert.ToDecimal(dataReader["o_totalamount"]);
                        currentRow.OrderDesription = Convert.ToString(dataReader["o_orderdesription"]);
                        lstOrder.Add(currentRow);
                    }
                }
                npgsqlcon.Close();
            }
            return lstOrder;
        }
        public int UpdateOrderStatus(ReqUpdateStatus req)
        {
            int iResult = 0;
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string Query = "update orderheader set orderstatus ='" + req.Status + "',lastupdatedon=now(),lastupdatedby=" + req.UserId + " where customerid = " + req.CustomerId + " and idheader = " + req.OrderId + ";";
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand(Query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                iResult = npgsqlcmd.ExecuteNonQuery();
                npgsqlcon.Close();
            }
            return iResult;
        }
        public int Updateordertiming(ReqUpdateStatus req)
        {
            int iResult = 0;
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            string Query = "update orderheader set deliverytime ='" + Convert.ToInt32(req.Status) + "',lastupdatedon=now(),lastupdatedby=" + req.UserId + " where customerid = " + req.CustomerId + " and idheader = " + req.OrderId + ";";
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand(Query, npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                iResult = npgsqlcmd.ExecuteNonQuery();
                npgsqlcon.Close();
            }
            return iResult;
        }
        public List<LoadmasteritemDDLOP> LoadmasteritemDDL(LoadmasteritemDDLIP customerid, ref List<ConferenceCallOP> conferenceCallOPs)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<LoadmasteritemDDLOP> lstFinishedItems = new List<LoadmasteritemDDLOP>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadMasteritemsDDL", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, customerid.DID);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        LoadmasteritemDDLOP finishedItemDetails = new LoadmasteritemDDLOP();
                        finishedItemDetails.Itemcode = Convert.ToInt32(dataReader["o_itemcode"]);
                        finishedItemDetails.Itemname = Convert.ToString(dataReader["o_itemname"]);
                        finishedItemDetails.Itemdescription = Convert.ToString(dataReader["o_itemdescription"]);
                        lstFinishedItems.Add(finishedItemDetails);
                    }
                }
                npgsqlcon.Close();
                npgsqlcon.Open();
                npgsqlcmd = new NpgsqlCommand("public.getitemsofrestaurant", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_did", NpgsqlTypes.NpgsqlDbType.Varchar, customerid.DID);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        ConferenceCallOP ConferenceCallOPobj = new ConferenceCallOP();
                        ConferenceCallOPobj.Status = Convert.ToString(dataReader["o_type"]);
                        ConferenceCallOPobj.Message = Convert.ToString(dataReader["o_value"]);
                        conferenceCallOPs.Add(ConferenceCallOPobj);
                    }
                }
                npgsqlcon.Close();
            }
            return lstFinishedItems;
        }
        /*Out of order*/
        public List<loadItemmasterforOOS> LoadItemmasterforOOS(outofstockIP customerid)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<loadItemmasterforOOS> lstFinishedItems = new List<loadItemmasterforOOS>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadItemmasterforOOS", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, customerid.customerid);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        loadItemmasterforOOS finishedItemDetails = new loadItemmasterforOOS();
                        finishedItemDetails.sno = Convert.ToInt32(dataReader["o_sno"]);
                        finishedItemDetails.itemcode = Convert.ToInt64(dataReader["o_itemcode"]);
                        finishedItemDetails.itemsize = Convert.ToInt32(dataReader["o_itemsize"]);
                        finishedItemDetails.customerid = Convert.ToInt32(dataReader["o_customerid"]);
                        finishedItemDetails.itemname = Convert.ToString(dataReader["o_itemname"]);
                        finishedItemDetails.itemdescription = Convert.ToString(dataReader["o_itemdescription"]);
                        finishedItemDetails.sizename = Convert.ToString(dataReader["o_sizename"]);
                        finishedItemDetails.itemtype = Convert.ToString(dataReader["o_itemtype"]);
                        lstFinishedItems.Add(finishedItemDetails);
                    }
                }
                npgsqlcon.Close();
            }
            return lstFinishedItems;
        }
        public int AddOutofstocks(addoutofstock req)
        {
            int iResult = 0;
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<loadItemmasterforOOS> lstFinishedItems = new List<loadItemmasterforOOS>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.addOutofstocks", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, req.customerid);
                npgsqlcmd.Parameters.AddWithValue("@i_itemcode", NpgsqlTypes.NpgsqlDbType.Integer, req.itemcode);
                npgsqlcmd.Parameters.AddWithValue("@i_itemsize", NpgsqlTypes.NpgsqlDbType.Integer, req.itemsize);
                npgsqlcmd.Parameters.AddWithValue("@i_stockdate", NpgsqlTypes.NpgsqlDbType.Varchar, req.stockdate ?? "");
                npgsqlcmd.Parameters.AddWithValue("@i_userid", NpgsqlTypes.NpgsqlDbType.Integer, req.userid ?? 0);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        iResult = Convert.ToInt32(dataReader["o_status"]);
                    }
                }
                npgsqlcon.Close();
            }
            return iResult;
        }
        public List<loadOutofstocksOP> LoadOutofstocks(outofstockIP customerid)
        {
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<loadOutofstocksOP> lstFinishedItems = new List<loadOutofstocksOP>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.loadOutofstocks", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_customerid", NpgsqlTypes.NpgsqlDbType.Integer, customerid.customerid);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        loadOutofstocksOP finishedItemDetails = new loadOutofstocksOP();
                        finishedItemDetails.sno = Convert.ToInt32(dataReader["o_sno"]);
                        finishedItemDetails.id = Convert.ToInt64(dataReader["o_id"]);
                        finishedItemDetails.itemname = Convert.ToString(dataReader["o_itemname"]);
                        finishedItemDetails.sizename = Convert.ToString(dataReader["o_sizename"]);
                        finishedItemDetails.stockdate = Convert.ToString(dataReader["o_stockdate"]);
                        finishedItemDetails.username = Convert.ToString(dataReader["o_username"]);
                        finishedItemDetails.createdon = Convert.ToString(dataReader["o_createdon"]);
                        lstFinishedItems.Add(finishedItemDetails);
                    }
                }
                npgsqlcon.Close();
            }
            return lstFinishedItems;
        }
        public int Updateoutofstock(stockIP stockid)
        {
            int iResult = 0;
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            List<loadItemmasterforOOS> lstFinishedItems = new List<loadItemmasterforOOS>();
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                var npgsqlcmd = new NpgsqlCommand("public.updateoutofstock", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.StoredProcedure;
                npgsqlcmd.Parameters.AddWithValue("@i_id", NpgsqlTypes.NpgsqlDbType.Integer, stockid.stockid);

                using (NpgsqlDataReader dataReader = npgsqlcmd.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        iResult = Convert.ToInt32(dataReader["o_status"]);
                    }
                }
                npgsqlcon.Close();
            }
            return iResult;
        }
        /*End*/
        public string GetConsumername(string consumermobile, string customermobile, ref string consumername)
        {
            DataTable dataTable = new DataTable();
            string conStr = getConnection().GetSection("connectionStrings").GetSection("DefaultConnection").Value;
            using (var npgsqlcon = new NpgsqlConnection(conStr))
            {
                npgsqlcon.Open();
                //var npgsqlcmd = new NpgsqlCommand("select consumername from consumer where mobile=@consumermobile and customerid=(select idcustomer from mastercustomer where contactnumber=@customermobile)", npgsqlcon);
                var npgsqlcmd = new NpgsqlCommand("select coalesce(c.consumername,'') as consumername,coalesce(mc.companyname,'') as companyname from consumer c inner join mastercustomer mc on mc.idcustomer=c.customerid where c.mobile=@consumermobile and mc.did=@customermobile limit 1", npgsqlcon);
                npgsqlcmd.CommandType = CommandType.Text;
                NpgsqlDataAdapter npgsqlDataAdapter = new NpgsqlDataAdapter(npgsqlcmd);
                npgsqlcmd.Parameters.AddWithValue("@consumermobile", Convert.ToString(consumermobile));
                npgsqlcmd.Parameters.AddWithValue("@customermobile", Convert.ToString(customermobile));
                npgsqlDataAdapter.Fill(dataTable);
                npgsqlcon.Close();
            }
            if (dataTable.Rows.Count > 0)
            {
                consumername = Convert.ToString(dataTable.Rows[0]["consumername"]);
            }

            return consumername;
        }
   
    }
}
