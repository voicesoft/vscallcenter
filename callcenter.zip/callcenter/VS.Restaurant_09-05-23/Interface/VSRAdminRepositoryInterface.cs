﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface VSRAdminRepositoryInterface
    {
        public List<Defaultresultset> AddCompany(Customer company,ref dynamic dbConfig);
        public List<Defaultresultset> Customerinfo(Addcustomerinfo addcustomerinfo, ref dynamic dbConfig);
        public List<LoadcompanyOutput> LoadCompany(LoadcompanyInput loadcompanyInput,ref int totalrow);
        public List<Defaultresultset> UpdateagentAvailability(string agentextension);
    }
}
