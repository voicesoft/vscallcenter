﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface VSRRepositoryInterface
    {
        public List<LoginResultset> ValidateLogin(LoginValues loginValues);
        public Agentloignresut ValidateagentLogin(Agentloign agentloign);
        #region Itemtype
        public List<Defalutresultset> AddItemtype(AdditemValues additemValues);
        public List<LoaditemResultset> LoadItemtype(LoaditemValues loaditemValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItemtype(EdititemValues edititemValues);
        public List<Defalutresultset> DeleteItemtype(DeleteitemValues deleteitemValues);
        #endregion
        #region Itemsize
        public List<Defalutresultset> AddItemsize(AddsizeValues addsizeValues);
        public List<LoadsizeResultset> LoadItemsize(LoadsizeValues loadsizeValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItemsize(EditsizeValues editsizeValues);
        public List<Defalutresultset> DeleteItemsize(DeletesizeValues deletesizeValues);
        #endregion
        #region Itemmaster
        public List<Defalutresultset> AddItemmaster(AddmasterValues addmasterValues);
        public List<LoadmasterResultset> LoadItemmaster(LoadmasterValues loadmasterValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItemmaster(EditmasterValues editmasterValues);
        public List<Defalutresultset> DeleteItemmaster(DeletemasterValues deletemasterValues);
        #endregion
        #region Itemmprice
        public List<Defalutresultset> AddItemprice(AddpriceValues addpriceValues);
        public List<LoadpriceResultset> LoadItemprice(LoadpriceValues loadpriceValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItemprice(EditpriceValues editpriceValues);
        public List<Defalutresultset> DeleteItemprice(DeletepriceValues deletepriceValues);
        #endregion
        #region Itempackage
        public List<Defalutresultset> AddItempackage(AddpackageitemValues addpackageValues);
        public List<LoadpackageResultset> LoadItempackage(LoadpackageValues loadpackageValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItempackage(EditpackageValues editpackageValues);
        public List<Defalutresultset> DeleteItempackage(DeletepackageValues deletepackageValues);
        #endregion
    }
}
