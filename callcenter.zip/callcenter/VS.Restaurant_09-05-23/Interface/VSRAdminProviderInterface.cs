﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface VSRAdminProviderInterface
    {
        GenericResponse AddCompany(Customer customer);
        GenericResponse Customerinfo(Addcustomerinfo addcustomerinfo);
        GenericResponse LoadCompany(LoadcompanyInput loadcompanyInput);
        GenericResponse Welcomeaudio(ReqWelcomeAudio reqwelcomeaudio);
        GenericResponse Loadwelcomeaudio(LoadwelcomeAudio loadwelcomeAudio);
        GenericResponse Deletewelcomeaudio(DeletewelcomeAudio deletewelcomeAudio);
        GenericResponse UpdateagentAvailability(string agentextension);
    }

}
