﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface VSRProviderInterface
    {
        public GenericResponse ValidateLogin(LoginValues loginValues);
        public GenericResponse ValidateagentLogin(Agentloign agentloign);
        #region Itemtype
        public GenericResponse AddItemtype(AdditemValues additemValues);
        public GenericResponse LoadItemtype(LoaditemValues loaditemValues);
        public GenericResponse EditItemtype(EdititemValues edititemValues);
        public GenericResponse DeleteItemtype(DeleteitemValues deleteitemValues);
        #endregion
        #region Itemsize
        public GenericResponse AddItemsize(AddsizeValues addsizeValues);
        public GenericResponse LoadItemsize(LoadsizeValues loadsizeValues);
        public GenericResponse EditItemsize(EditsizeValues editsizeValues);
        public GenericResponse DeleteItemsize(DeletesizeValues deletesizeValues);
        #endregion
        #region Itemmaster
        public GenericResponse AddItemmaster(Addmasterfromdata addmasterValues);
        public GenericResponse LoadItemmaster(LoadmasterValues loadmasterValues);
        public GenericResponse EditItemmaster(Addmasterfromdata addmasterValues);
        public GenericResponse DeleteItemmaster(DeletemasterValues deletemasterValues);
        #endregion
        #region Itemprice
        public GenericResponse AddItemprice(AddpriceValues addpriceValues);
        public GenericResponse LoadItemprice(LoadpriceValues loadpriceValues);
        public GenericResponse EditItemprice(EditpriceValues editpriceValues);
        public GenericResponse DeleteItemprice(DeletepriceValues deletepriceValues);
        #endregion
        #region Itempackage
        public GenericResponse AddItempackage(Addmasterfromdata addmasterfromdata);
        public GenericResponse LoadItempackage(LoadpackageValues loadpackageValues);
        public GenericResponse EditItempackage(Addmasterfromdata addmasterfromdata);//EditpackageValues editpackageValues
        public GenericResponse DeleteItempackage(DeletepackageValues deletepackageValues);
        #endregion
    }
}
