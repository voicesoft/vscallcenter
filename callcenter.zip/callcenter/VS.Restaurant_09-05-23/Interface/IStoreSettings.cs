﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface IStoreSettings
    {
        public GenericResponse AddItemPromotion(ReqItemPromotion reqItemPromotion);
        public GenericResponse RemoveItemPromotion(ReqRemoveItem reqRemoveItem);
        public GenericResponse GetItemPromotion(ReqItemList reqItemList);
        public GenericResponse AddItemDelay(ReqItemDelays reqItemDelays);
        public GenericResponse RemoveItemDelay(ReqRemoveItem reqRemoveItem);
        public GenericResponse GetItemDelayList(ReqItemList reqItemList);
        public GenericResponse AddFactoryPauseTimings(ReqFactoryPause reqFactoryPause);
        public GenericResponse RemoveFactoryPauseTimings(ReqRemoveItem reqRemoveItem);
        public GenericResponse GetFactoryPauseTimings(ReqDelay reqDelay);
        public GenericResponse AddItemOfTheDay(ReqItemOfTheDay reqItemOfTheDay);
        public GenericResponse RemoveItemOfTheDay(ReqRemoveItem reqRemoveItem);
        public GenericResponse GetItemOfTheDay(ReqItemList reqItemList);
        public GenericResponse AddBlackList(ReqBlackList reqBlack);
        public GenericResponse RemoveBlackList(ReqRemoveBlackList reqRemoveBlackList);
        public GenericResponse GetBlackList(ReqLoadBlacList reqLoadBlacList);
        public GenericResponse GetOverAllOrderDelay(ReqDelay reqDelay);
        public GenericResponse AddOverAllOrderDelay(ReqAddOverAllDelay reqAddOverAllDelay);
        public GenericResponse RemoveOverAllOrderDelay(ReqRemoveItem reqRemoveItem);
        public GenericResponse getBlacklistmembers(ReqAddBalcklistmembers reqRemoveItem);
    }
}
