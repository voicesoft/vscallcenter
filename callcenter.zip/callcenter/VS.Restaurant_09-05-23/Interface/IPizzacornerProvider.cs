﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface IPizzacornerProvider
    {
        #region Itembase
        GenericResponse Loadpizzabase(int restraurantid);
        GenericResponse Addpizzabase(OperatemasterbaseReq operatemasterbaseReq);
        GenericResponse Updatepizzabase(OperatemasterbaseReq operatemasterbaseReq);
        GenericResponse Deletepizzabase(DeletemasterbaseReq operatemasterbaseReq); 
        #endregion
        #region Itemtoppings
        GenericResponse LoadpizzaToppings(int restraurantid, int userid);
        GenericResponse AddpizzaToppings(AddmasttertopingsReq addmasttertopingsReq);
        GenericResponse UpdatepizzaToppings(UpdatemasttertopingsReq addmasttertopingsReq);
        GenericResponse DeletepizzaToppings(int restraurantid, int userid, Int64 topingid); 
        #endregion
        #region Itemmaster
        public GenericResponse AddItemmaster(Addmasterpizzafromdata addmasterValues);
        public GenericResponse LoadItemmaster(LoadmasterpizzaValues loadmasterValues);
        public GenericResponse EditItemmaster(Addmasterpizzafromdata addmasterValues);
        public GenericResponse DeleteItemmaster(DeletemasterpizzaValues deletemasterValues);
        #endregion
        #region Itempackage
        public GenericResponse AddItempackagepizza(Addmasterpizzafromdata addmasterfromdata);
        public GenericResponse LoadItempackagepizza(LoadpackagepizzaValues loadpackageValues);
        public GenericResponse EditItempackagepizza(Addmasterpizzafromdata addmasterfromdata);
        public GenericResponse DeleteItempackagepizza(DeletepackagepizzaValues deletepackageValues);
        #endregion
        #region Iteminfo
        public GenericResponse Loaditeminfo(Int64 itemcode);
        #endregion
        #region Itemtypeddl
        public GenericResponse Loaditemtypeddl(Int64 restaurantid);
        public GenericResponse Loaditemnameddl(Int64 restaurantid, Int64 itemtype);

        #endregion
    }
}
