﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface IAgentmonitorProvider
    {
        GenericResponse Validatelogin(LoginReq loginReq);
        GenericResponse Loadagentcallstatus(LoadagentstatusReq loadagentstatusReq);
        GenericResponse Loadagentddl();
        GenericResponse Loadagentlanguage();
        GenericResponse Loadagentcallhistory(LoadagenthistoryReq loadagenthistoryReq);
        GenericResponse Loadagentcallsummary(LoadagenthistoryReq loadagenthistoryReq);
        GenericResponse Loadagentbyrmddl(int rmid);
        GenericResponse Loadagentcallsummarystatus(LoadagenthistoryReq loadagentstatusReq);
        GenericResponse Loadagentcalldetailstatus(LoadagenthistoryReq loadagentstatusReq);
        GenericResponse DowloadItemMaster(int CustomerId);
        GenericResponse downloadpackageitems(int CustomerId);

        GenericResponse downloadagentcallstatus(downloadagentcallReq downloadagentcallReq);
    }
}
