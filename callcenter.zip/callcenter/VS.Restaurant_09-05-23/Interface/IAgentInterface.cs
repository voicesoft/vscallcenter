﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface IAgentInterface
    {
        GenericResponse AddAgent(CreateAgents _agent);
        GenericResponse GetAllAgents(int userid);

    }
}
