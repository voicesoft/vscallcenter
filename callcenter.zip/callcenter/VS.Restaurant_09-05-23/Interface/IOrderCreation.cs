﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface IOrderCreation
    {
        GenericResponse CreateOrder(OrderHeader _agent);
        GenericResponse GetFinishedItems(int UserId, string DID);
        GenericResponse GetSearchItems(int UserId, int CustomerId);
        GenericResponse GetItemsizebyItemcode(int UserId, int CustomerId, int Itemcode);
        GenericResponse GetOrderHeaderInfo(int CustomerId);
        GenericResponse GetOrderDetailsbyOrderno(int CustomerId, Int64 OrderNo);
        public GenericResponse UpdateOrderStatus(ReqUpdateStatus req);
        public GenericResponse Updateordertiming(ReqUpdateStatus req);
        /*Out of order*/
        public GenericResponse LoadItemmasterforOOS(outofstockIP customerid);
        public GenericResponse AddOutofstocks(addoutofstock req);
        public GenericResponse LoadOutofstocks(outofstockIP customerid);
        public GenericResponse Updateoutofstock(stockIP stockid);
        public GenericResponse LoadmasteritemDDL(LoadmasteritemDDLIP stockid);
        
        /*End*/
        /*Conference call*/
        public GenericResponse Makeconferencecall(ConferenceCallIP conferenceCallIP);
        public GenericResponse Playaudiofile(Playaudioip playaudioip);
        public GenericResponse Stopaudiofile(Stopaudioip stopaudioip );
        /*End*/
        public GenericResponse GetConsumername(string consumermobile, string customermobile);
    }
}
