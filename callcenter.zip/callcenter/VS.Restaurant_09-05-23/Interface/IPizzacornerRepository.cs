﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface IPizzacornerRepository
    {
        #region Itembase
        public List<LoadmasterbaseRes> Loadpizzabase(int restraurantid);
        public OPRes Addpizzabase(OperatemasterbaseReq operatemasterbaseReq);
        public OPRes Updatepizzabase(OperatemasterbaseReq operatemasterbaseReq);
        public OPRes Deletepizzabase(DeletemasterbaseReq operatemasterbaseReq); 
        #endregion
        #region Itemtopping
        public List<LoadmastertopingsRes> LoadpizzaToppings(int restraurantid, int userid);
        public OPRes AddpizzaToppings(AddmasttertopingsReq addmasttertopingsReq);
        public OPRes UpdatepizzaToppings(UpdatemasttertopingsReq addmasttertopingsReq);
        public OPRes DeletepizzaToppings(int restraurantid, int userid, Int64 topingid);
        #endregion
        #region Itemmaster
        public List<Defalutresultset> AddItemmaster(AddmasterpizzaValues addmasterValues);
        public List<LoadmasterpizzaResultset> LoadItemmaster(LoadmasterpizzaValues loadmasterValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItemmaster(EditmasterpizzaValues editmasterValues);
        public List<Defalutresultset> DeleteItemmaster(DeletemasterpizzaValues deletemasterValues);
        #endregion
        #region Itempackage
        public List<Defalutresultset> AddItempackagepizza(AddpackageitempizzaValues addpackageValues);
        public List<LoadpackagepizzaResultset> LoadItempackagepizza(LoadpackagepizzaValues loadpackageValues, ref Int32 totalrow);
        public List<Defalutresultset> EditItempackagepizza(EditpackagepizzaValues editpackageValues);
        public List<Defalutresultset> DeleteItempackagepizza(DeletepackagepizzaValues deletepackageValues);
        #endregion
        #region Itemdata
        public List<itemdatares> Loaditeminfo(Int64 itemcode);
        #endregion
        #region Itemtypeddl
        public List<Loaditemtyperes> Loaditemtypeddl(Int64 resturuantid);
        public List<Loaditemnameres> Loaditemnameddl(Int64 resturuantid, Int64 itemtype);
        #endregion

    }
}
