﻿using VS.Restaurant.Modal;

namespace VS.Restaurant.Interface
{
    public interface ICallStatusUpdateBase
    {
        GenericResponse AgentStausUpdate(AgentStatusUpdate _req);
        GenericResponse AgentCallStatus(LiveAgents _req);
        GenericResponse GetorSetAgentData(IncomingCall _req);
        GenericResponse UpdateCallLog(CallLog req);
        GenericResponse UpdateCurrentAgentStatus(List<AgentList> _req);
        GenericResponse GetorSetAgenQueueData(IncomingCall _req);
        GenericResponse UpdateQueueLogs(ReqQueueLog reqQueueLog);
        GenericResponse InitiateTraining(RequestStartStop requestStartStop);
        GenericResponse Loadcompany();
        AudioData UpdateTrainingCallLog(TCallLog req);
        GenericResponse Uploadaudio(ReqUploadTrainingAudio requploadaudio);
        GenericResponse Loadallaudio(LoadcompanyInput loadcompanyInput);
        GenericResponse Deleteaudiofile(DeleteaudiofileIP deleteaudiofileValues);
    }
}