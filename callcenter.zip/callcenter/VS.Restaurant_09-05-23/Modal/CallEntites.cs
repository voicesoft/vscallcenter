﻿using MimeKit.Encodings;
using System.Text.Json.Serialization;

namespace VS.Restaurant.Modal
{
    public class LiveAgents
    {
        [JsonPropertyName("did")]
        public string? DID { get; set; }
        [JsonPropertyName("agentid")]
        public int AgentId { get; set; }
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("incall")]
        public int InCall { get; set; }
    }

    public class WebRTCAgents
    {
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("incall")]
        public int InCall { get; set; }
    }
    public class IncomingCall
    {
        [JsonPropertyName("did")]
        public string? DID { get; set; }
        [JsonPropertyName("callerid")]
        public string? CallerId { get; set; }
        [JsonPropertyName("preextension")]
        public string? PreExtension { get; set; }
        [JsonPropertyName("agents")]
        public List<WebRTCAgents>? Agents { get; set; }
        [JsonPropertyName("uniqueid")]
        public string? UniqueID { get; set; }
        public string? option { get; set; }

    }
    public class ReqQueueLog
    {
        public string callid { get; set; }
        public string queuename { get; set; }
        public string agent { get; set; }
        public string events { get; set; }
        public string created { get; set; }
    }
    public class reqqueue
    {
        public string member { get; set; }
        public string queuename { get; set; }
        public string value { get; set; }
    }
    public class AgentStatusUpdate
    {
        [JsonPropertyName("agentid")]
        public int AgentId { get; set; }
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("registered")]
        public string? Registered { get; set; }
    }

    public class AllocatedExtension
    {
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("record")]
        public string? Record { get; set; }
        [JsonPropertyName("manager")]
        public int Manager { get; set; }
        [JsonPropertyName("queue")]
        public string? Queue { get; set; }
    }

    public class CallLog
    {
        [JsonPropertyName("did")]
        public string? DID { get; set; }

        [JsonPropertyName("callerid")]
        public string? CallerId { get; set; }
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("callstarttime")]
        public string? CallStartTime { get; set; }
        [JsonPropertyName("callendtime")]
        public string? CallEndTime { get; set; }
        [JsonPropertyName("recordingfile")]
        public string? RecordingFile { get; set; }
        [JsonPropertyName("callstatus")]
        public string? CallStatus { get; set; }
        [JsonPropertyName("duration")]
        public int Duration { get; set; }
        [JsonPropertyName("Voicemessage")]
        public string? Voicemessage { get; set; }

        [JsonPropertyName("uniqueid")]
        public string? uniqueid { get; set; }
    }
    public class TCallLog
    {
        [JsonPropertyName("did")]
        public string? DID { get; set; }

        [JsonPropertyName("callerid")]
        public string? CallerId { get; set; }
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("callstarttime")]
        public string? CallStartTime { get; set; }
        [JsonPropertyName("callendtime")]
        public string? CallEndTime { get; set; }
        [JsonPropertyName("recordingfile")]
        public string? RecordingFile { get; set; }
        [JsonPropertyName("callstatus")]
        public string? CallStatus { get; set; }
        [JsonPropertyName("duration")]
        public int Duration { get; set; }
        [JsonPropertyName("Voicemessage")]
        public string? Voicemessage { get; set; }
        [JsonPropertyName("audio")]
        public string? audio { get; set; }
    }

    public class AgentList
    {
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("incall")]
        public int InCall { get; set; }
    }
    public class RequestStartStop
    {
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("agentid")]
        public int AgentId { get; set; }
        [JsonPropertyName("action")]
        public string? Action { get; set; }
    }
    public class ReqUploadTrainingAudio
    {
        [JsonPropertyName("itemdata")]
        public string? Itemdata { get; set; }
        [JsonPropertyName("audiofile")]
        public IFormFile? Audiofile { get; set; }

    }

    public class AddReqUploadTrainingAudio
    {
        [JsonPropertyName("customerid")]
        public int CustomerId { get; set; }
        [JsonPropertyName("userid")]
        public int UserId { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
        [JsonPropertyName("audiofilewithextension")]
        public string? Audiofilewithextension { get; set; }
    }
    public class LoadwelcomeAudio
    {
        [JsonPropertyName("customerid")]
        public int CustomerId { get; set; }
        [JsonPropertyName("userid")]
        public int UserId { get; set; }
    }
    public class DeletewelcomeAudio
    {
        [JsonPropertyName("customerid")]
        public int CustomerId { get; set; }
        [JsonPropertyName("audio")]
        public string? Audio { get; set; }
    }

    public class ListWelcomefile
    {
        [JsonPropertyName("audio")]
        public string? Audio { get; set; }
        [JsonPropertyName("audiourl")]
        public string? AudioURL { get; set; }
    }
    public class AudioData
    {
        public string? extesion { get; set; }
        public string? did { get; set; }
        public string? cid { get; set; }
        public string? audio { get; set; }
        public string wait { get; set; }
        public string status { get; set; }
    }
    public class AudioUpload
    {
        public string link { get; set; }
        public string filename { get; set; }
    }
    public class AudioConvert
    {
        public string current { get; set; }
        public string format { get; set; }
        public string convert { get; set; }
        public string cformat { get; set; }
    }
}
