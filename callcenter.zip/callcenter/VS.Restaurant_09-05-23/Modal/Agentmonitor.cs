﻿using System.Text.Json.Serialization;

namespace VS.Restaurant.Modal
{
    public class Agentmonitor
    {
    }
    public class LoginReq
    {
        [JsonPropertyName("username")]
        public string? Username { get; set; }
        [JsonPropertyName("userpassword")]
        public string? Userpassword { get; set; }
    }
    public class LoginRes
    {
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("agentname")]
        public string? Agentname { get; set; }
        [JsonPropertyName("username")]
        public string? Username { get; set; }
        [JsonPropertyName("usermobile")]
        public string? Usermobile { get; set; }
        [JsonPropertyName("userpassword")]
        public string? Userpassword { get; set; }
        [JsonPropertyName("userrole")]
        public string? Userrole { get; set; }
        [JsonPropertyName("reportmanager")]
        public int Reportmanager { get; set; }
    }
    public class LoadagentstatusReq
    {
        [JsonPropertyName("reportingmanagerid")]
        public int Reportingmanagerid { get; set; }
        [JsonPropertyName("agentid")]
        public int Agentid { get; set; }
    }
    public class LoadagenthistoryReq
    {
        [JsonPropertyName("reportingmanagerid")]
        public int Reportingmanagerid { get; set; }
        [JsonPropertyName("agentid")]
        public int Agentid { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
    }
    public class LoadagentstatusRes
    {
        [JsonPropertyName("rno")]
        public int Rno { get; set; }
        [JsonPropertyName("agentid")]
        public int Agentid { get; set; }
        [JsonPropertyName("agentname")]
        public string? Agentname { get; set; }
        [JsonPropertyName("agentextension")]
        public string? Agentextension { get; set; }
        [JsonPropertyName("logdate")]
        public string? Logdate { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
        [JsonPropertyName("endtime")]
        public string? Endtime { get; set; }
        [JsonPropertyName("duration")]
        public string? Duration { get; set; }
        [JsonPropertyName("callstatus")]
        public string? Callstatus { get; set; }
    }
    public class Agentddl
    {
        [JsonPropertyName("agentid")]
        public int Agentid { get; set; }
        [JsonPropertyName("agentname")]
        public string? Agentname { get; set; }
    }
    public class Languageddl
    {
        [JsonPropertyName("languageid")]
        public int Languageid { get; set; }
        [JsonPropertyName("languagename")]
        public string? Languagename { get; set; }
    }
    public class DetailreportOP
    {
        [JsonPropertyName("rno")]
        public int Rno { get; set; }
        [JsonPropertyName("agentname")]
        public string? Agentname { get; set; }
        [JsonPropertyName("agentextension")]
        public string? Agentextension { get; set; }
        [JsonPropertyName("logdate")]
        public string? Logdate { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
        [JsonPropertyName("endtime")]
        public string? Endtime { get; set; }
        [JsonPropertyName("duration")]
        public string? Duration { get; set; }
        [JsonPropertyName("callstatus")]
        public string? Callstatus { get; set; }

    }
    public class SummaryreportOP
    {
        [JsonPropertyName("agentname")]
        public string? Agentname { get; set; }
        [JsonPropertyName("agentextension")]
        public string? Agentextension { get; set; }
        [JsonPropertyName("logdate")]
        public string? Logdate { get; set; }
        [JsonPropertyName("duration")]
        public string? Duration { get; set; }
        [JsonPropertyName("connected")]
        public string? Connected { get; set; }
        [JsonPropertyName("missed")]
        public string? Missed { get; set; }
        [JsonPropertyName("avgcalltime")]
        public string? Avgcalltime { get; set; }
    }
    public class downloadagentcallReq
    {
        [JsonPropertyName("agentid")]
        public int Agentid { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
    }
}
