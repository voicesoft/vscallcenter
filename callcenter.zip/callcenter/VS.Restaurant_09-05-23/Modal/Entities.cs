﻿using System.Text.Json;
using System.Text.Json.Serialization;
using Newtonsoft.Json;
using JsonIgnoreAttribute = System.Text.Json.Serialization.JsonIgnoreAttribute;

namespace VS.Restaurant.Modal
{
    public class Agentloign
    {
        [JsonPropertyName("username")]
        public string? UserName { get; set; }
        [JsonPropertyName("userpassword")]
        public string? UserPassword { get; set; }
    }
    public class Agentloignresut
    {
        [JsonPropertyName("agentid")]
        public Int32 AgentID { get; set; }
        [JsonPropertyName("agentname")]
        public string? AgentName { get; set; }
        [JsonPropertyName("username")]
        public string? UserName { get; set; }
        [JsonPropertyName("usermobile")]
        public string? UserMobile { get; set; }
        [JsonPropertyName("configdata")]
        public string? Configdata { get; set; }
    }
    public class Customer
    {
        [JsonPropertyName("type")]
        public Int32 Type { get; set; }
        [JsonPropertyName("companyname")]
        public string? CompanyName { get; set; }
        [JsonPropertyName("companyid")]
        public Int32 CompanyId { get; set; }
        [JsonPropertyName("customername")]
        public string? CustomerName { get; set; }
        [JsonPropertyName("email")]
        public string? Email { get; set; }
        [JsonPropertyName("username")]
        public string? Username { get; set; }
        [JsonPropertyName("firstname")]
        public string? FirstName { get; set; }
        [JsonPropertyName("lastname")]
        public string? LastName { get; set; }
        [JsonPropertyName("regnumber")]
        public string? RegNumber { get; set; }

        [JsonPropertyName("address1")]
        public string? Address1 { get; set; }

        [JsonPropertyName("address2")]
        public string? Address2 { get; set; }

        [JsonPropertyName("address3")]
        public string? Address3 { get; set; }

        [JsonPropertyName("country")]
        public string? Country { get; set; }

        [JsonPropertyName("zipcode")]
        public string? Zipcode { get; set; }

        [JsonPropertyName("contactnumber")]
        public string? ContactNumber { get; set; }

        [JsonPropertyName("contactperson")]
        public string? ContactPerson { get; set; }

        [JsonPropertyName("contactpersonnumber")]
        public string? ContactPersonNumber { get; set; }

        [JsonPropertyName("did")]
        public string? DID { get; set; }

        [JsonPropertyName("onlineurl")]
        public string? OnlineURL { get; set; }

        [JsonPropertyName("deliverytype")]
        public int DeliveryType { get; set; }

        [JsonPropertyName("ordercomission")]
        public decimal? OrderComission { get; set; }
        [JsonPropertyName("createdby")]
        public Int32 Createdby { get; set; }
        [JsonPropertyName("restauranttype")]
        public Int32 Restauranttype { get; set; }
        [JsonPropertyName("hours")]
        public string? Hours { get; set; }
        [JsonPropertyName("minutes")]
        public string? Minutes { get; set; }

    }
    public class Addcustomerinfo
    {
        [JsonPropertyName("companyid")]
        public Int32 Companyid { get; set; }
        [JsonPropertyName("merchantid")]
        public string? Merchantid { get; set; }
        [JsonPropertyName("clientid")]
        public string? Clientid { get; set; }
        [JsonPropertyName("secretkey")]
        public string? Secretkey { get; set; }
        [JsonPropertyName("secretcode")]
        public string? Secretcode { get; set; }
        [JsonPropertyName("authtoken")]
        public string? Authtoken { get; set; }
        [JsonPropertyName("pos")]
        public string? Pos { get; set; }

    }
    public class Defaultresultset
    {
        [JsonPropertyName("status")]
        public Int32 Status { get; set; }
        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }
    public class LoadcompanyInput
    {
        [JsonPropertyName("search")]
        public string? Search { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 pageno { get; set; }
    }
    public class LoadcompanyOutput
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("customername")]
        public string? Customername { get; set; }
        [JsonPropertyName("companyname")]
        public string? Companyname { get; set; }
        [JsonPropertyName("regnumber")]
        public string? Regnumber { get; set; }
        [JsonPropertyName("address1")]
        public string? Address1 { get; set; }
        [JsonPropertyName("address2")]
        public string? Address2 { get; set; }
        [JsonPropertyName("address3")]
        public string? Address3 { get; set; }
        [JsonPropertyName("country")]
        public string? Country { get; set; }
        [JsonPropertyName("zipcode")]
        public string? Zipcode { get; set; }
        [JsonPropertyName("contactnumber")]
        public string? Contactnumber { get; set; }
        [JsonPropertyName("contactperson")]
        public string? Contactperson { get; set; }
        [JsonPropertyName("contactpernum")]
        public string? Contactpernum { get; set; }
        [JsonPropertyName("did")]
        public string? Did { get; set; }
        [JsonPropertyName("onlineurl")]
        public string? Onlineurl { get; set; }
        [JsonPropertyName("delivertype")]
        public Int32 Delivertype { get; set; }
        [JsonPropertyName("ordercomission")]
        public decimal Ordercomission { get; set; }
        [JsonPropertyName("hours")]
        public string? Hours { get; set; }
        [JsonPropertyName("minutes")]
        public string? Minutes { get; set; }
    }


    public class Agents
    {
        // [JsonPropertyName("agentname")]
        [JsonPropertyName("agentname")]
        public string? AgentName { get; set; }
        [JsonPropertyName("agentcity")]
        public string? AgentCity { get; set; }
        [JsonPropertyName("username")]
        public string? UserName { get; set; }

        [JsonPropertyName("userpassword")]
        [JsonIgnore]
        public string? UserPassword { get; set; }
        [JsonPropertyName("usermobile")]
        public string? UserMobile { get; set; }
        [JsonIgnore]
        [JsonPropertyName("createdby")]
        public int? CreatedBy { get; set; }
        [JsonPropertyName("user")]
        public string? User { get; set; }
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }
        [JsonPropertyName("extensionpwd")]
        public string? Extensionpwd { get; set; }
    }
    public class LoadagentsIP
    {
        [JsonPropertyName("userid")]
        public Int32 userid { get; set; }

    }
    public class CreateAgents
    {
        // [JsonPropertyName("agentname")]
        [JsonPropertyName("agentname")]
        public string? AgentName { get; set; }
        [JsonPropertyName("agentcity")]
        public string? AgentCity { get; set; }
        [JsonPropertyName("username")]
        public string? UserName { get; set; }

        [JsonPropertyName("userpassword")]
        public string? UserPassword { get; set; }
        [JsonPropertyName("usermobile")]
        public string? UserMobile { get; set; }
        [JsonPropertyName("extension")]
        public string? Extension { get; set; }

        [JsonPropertyName("extensionpwd")]
        public string? Extensionpwd { get; set; }

        [JsonPropertyName("createdby")]
        public int? CreatedBy { get; set; }
        [JsonPropertyName("isadmin")]
        public int? Isadmin { get; set; }
        [JsonPropertyName("languagelist")]
        public List<languagelist>? Languagelist { get; set; }

        [JsonPropertyName("rmid")]
        public int? Rmid { get; set; }

    }
    public class languagelist
    {
        [JsonPropertyName("languageid")]
        public Int32 languageid { get; set; }
    }

    public class Consumer
    {
        [JsonPropertyName("isnew")]
        public int IsNewConsumer { get; set; }
        [JsonPropertyName("name")]
        public string? ConsumerName { get; set; }
        [JsonPropertyName("mobile")]
        public string? ConsumerMobile { get; set; }
        [JsonPropertyName("altmobile")]
        public string? ConsumerAltMobile { get; set; }
        [JsonPropertyName("address1")]
        public string? ConsumerAddress1 { get; set; }
        [JsonPropertyName("address2")]
        public string? ConsumerAddress2 { get; set; }
        [JsonPropertyName("city")]
        public string? ConsumerCity { get; set; }
        [JsonPropertyName("state")]
        public string? ConsumerState { get; set; }
        [JsonPropertyName("zipcode")]
        public string? ZipCode { get; set; }
        [JsonPropertyName("queuename")]
        public string? queuename { get; set; }
    }

    public class OrderHeader
    {
        [JsonPropertyName("did")]
        public string? DID { get; set; }
        [JsonPropertyName("customerid")]
        public int CustomerId { get; set; }
        [JsonPropertyName("userid")]
        public int UserId { get; set; }
        [JsonPropertyName("consumer")]
        public Consumer? Buyer { get; set; }
        [JsonPropertyName("consumerid")]
        public Int64 ConsumerId { get; set; }
        [JsonPropertyName("noofitems")]
        public int NoOfItems { get; set; }
        [JsonPropertyName("grossamount")]
        public decimal GrossAmount { get; set; }
        [JsonPropertyName("taxamount")]
        public decimal TaxAmount { get; set; }
        [JsonPropertyName("totalamount")]
        public decimal TotalAmount { get; set; }
        [JsonPropertyName("itemdetails")]
        public List<OrderDetails>? ItemDetails { get; set; }
    }

    public class OrderDetails
    {
        [JsonPropertyName("itemcode")]
        public int ItemCode { get; set; }
        [JsonPropertyName("customeritemCode")]
        public string? CustomerItemCode { get; set; }
        [JsonPropertyName("parentitemCode")]
        public int ParentItemCode { get; set; }
        [JsonPropertyName("customerparentitemCode")]
        public string? CustomerParentItemCode { get; set; }
        [JsonPropertyName("itemname")]
        public string? ItemName { get; set; }
        [JsonPropertyName("quantity")]
        public decimal Quantity { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal UnitPrice { get; set; }
        [JsonPropertyName("grossamount")]
        public decimal GrossAmount { get; set; }
        [JsonPropertyName("taxamount")]
        public decimal TaxAmount { get; set; }
        [JsonPropertyName("totalamount")]
        public decimal TotalAmount { get; set; }
        [JsonPropertyName("isaddon")]
        public int IsAddOn { get; set; }
        [JsonPropertyName("ismodifier")]
        public int IsModifier { get; set; }
        [JsonPropertyName("itemserial")]
        public int ItemSerial { get; set; }
        [JsonPropertyName("serial")]
        public int Serial { get; set; }
        [JsonPropertyName("packageitem")]
        public int PackageItem { get; set; }
        [JsonPropertyName("remarks")]
        public string? Remarks { get; set; }
        [JsonPropertyName("itemsize")]
        public int ItemSize { get; set; }
        [JsonPropertyName("sizename")]
        public string? ItemSizeName { get; set; }
        [JsonPropertyName("spicy")]
        public Int16 spicy { get; set; }
    }

    public class ItemDetails
    {
        [JsonPropertyName("serial")]
        public int Serial { get; set; }
        [JsonPropertyName("itemcode")]
        public int ItemCode { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? CustomerItemCode { get; set; }
        [JsonPropertyName("itemname")]
        public string? ItemName { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal? UnitPrice { get; set; }
    }

    public class FinishedItemDetails
    {
        [JsonPropertyName("itemcode")]
        public Int64 ItemCode { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? CustomerItemCode { get; set; }
        [JsonPropertyName("itemname")]
        public string? ItemName { get; set; }
        public decimal? UnitPrice { get; set; }
        [JsonPropertyName("packageitem")]
        public int PackageItem { get; set; }
        [JsonPropertyName("isaddon")]
        public int IsAddOn { get; set; }
        [JsonPropertyName("ismodifier")]
        public int IsModifier { get; set; }
        [JsonPropertyName("packageitemdetails")]
        public string? PackageDetails { get; set; }

        [JsonPropertyName("addondetails")]
        public string? AddOnDetails { get; set; }

        [JsonPropertyName("modifierdetails")]
        public string? ModifierDetails { get; set; }
        [JsonPropertyName("idsize")]
        public int Idsize { get; set; }
        [JsonPropertyName("sizename")]
        public string? SizeName { get; set; }
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        [JsonPropertyName("isoutofstock")]
        public int Isoutofstock { get; set; }
        [JsonPropertyName("customermobile")]
        public string? Customermobile { get; set; }
        [JsonPropertyName("itemtype")]
        public string? Itemtype { get; set; }
        [JsonPropertyName("restname")]
        public string? Restname { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiopath")]
        public string? Audiopath { get; set; }
        [JsonPropertyName("itemoftheday")]
        public int Itemoftheday { get; set; }
        [JsonPropertyName("itempromotion")]
        public int Itempromotion { get; set; }
        [JsonPropertyName("itemdelay")]
        public int Itemdelay { get; set; }
        [JsonPropertyName("itemdelaymins")]
        public int Itemdelaymins { get; set; }
        [JsonPropertyName("isown")]
        public int Isown { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
    }

    public class ReqSearchItems
    {
        [JsonPropertyName("userid")]
        public int UserId { get; set; }
        [JsonPropertyName("did")]
        public string? DID { get; set; }
    }

    public class PckItems
    {
        [JsonPropertyName("itemcode")]
        public Int64 ItemCode { get; set; }
        [JsonPropertyName("itemname")]
        public string? ItemName { get; set; }
        [JsonPropertyName("description")]
        public string? Description { get; set; }
        [JsonPropertyName("imagepath")]
        public string? ImagePath { get; set; }
    }

    public class ItemPriceDetails
    {
        [JsonPropertyName("itemcode")]
        public Int64 ItemCode { get; set; }

        [JsonPropertyName("itemsizeid")]
        public int ItemSizeId { get; set; }
        [JsonPropertyName("itemsize")]
        public string? ItemSize { get; set; }

        [JsonPropertyName("itemprize")]
        public decimal ItemPrize { get; set; }
    }

    public class ReqLoadItems
    {
        [JsonPropertyName("userid")]
        public int UserId { get; set; }
        [JsonPropertyName("customerid")]
        public int CustomerId { get; set; }
        [JsonPropertyName("itemcode")]
        public int Itemcode { get; set; }
    }

    public class OrderHeaderInfo
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("consumerid")]
        public Int64 ConsumerId { get; set; }
        [JsonPropertyName("consumername")]
        public string? ConsumerName { get; set; }
        [JsonPropertyName("contactno")]
        public string? ContactNo { get; set; }
        [JsonPropertyName("orderid")]
        public Int64 Orderid { get; set; }
        [JsonPropertyName("orderdate")]
        public string? OrderDate { get; set; }
        [JsonPropertyName("orderstatus")]
        public string? OrderStatus { get; set; }
        [JsonPropertyName("noofitems")]
        public int NoofItems { get; set; }
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }
        [JsonPropertyName("taxamount")]
        public decimal TaxAmount { get; set; }
        [JsonPropertyName("totalamount")]
        public decimal TotalAmount { get; set; }
        [JsonPropertyName("deliverytime")]
        public int DeliveryTime { get; set; }
        [JsonPropertyName("ordertime")]
        public string? OrderTime { get; set; }
    }

    public class OrderDetailsInfo
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("serialno")]
        public int SerialNo { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 ItemCode { get; set; }
        [JsonPropertyName("itemname")]
        public string? ItemName { get; set; }
        [JsonPropertyName("idsize")]
        public int IdSize { get; set; }
        [JsonPropertyName("sizename")]
        public string? SizeName { get; set; }
        [JsonPropertyName("qty")]
        public int Qty { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal UnitPrice { get; set; }
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }
        [JsonPropertyName("taxamount")]
        public decimal TaxAmount { get; set; }
        [JsonPropertyName("totalamount")]
        public decimal TotalAmount { get; set; }
        [JsonPropertyName("remarks")]
        public string? OrderDesription { get; set; }

    }

    public class ReqUpdateStatus
    {
        [JsonPropertyName("customerid")]
        public int CustomerId { get; set; }
        [JsonPropertyName("orderid")]
        public Int64 OrderId { get; set; }
        [JsonPropertyName("userid")]
        public int UserId { get; set; }
        [JsonPropertyName("status")]
        public string? Status { get; set; }
    }
    public class LoadmasteritemDDLIP
    {
        [JsonPropertyName("did")]
        public string? DID { get; set; }
    }
    public class LoadmasteritemDDLOP
    {
        [JsonPropertyName("itemcode")]
        public int Itemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
    }
    /*Out of order*/
    public class loadItemmasterforOOS
    {
        [JsonPropertyName("sno")]
        public int sno { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 itemcode { get; set; }
        [JsonPropertyName("itemsize")]
        public Int64 itemsize { get; set; }
        [JsonPropertyName("customerid")]
        public int? customerid { get; set; }
        [JsonPropertyName("itemname")]
        public string? itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? itemdescription { get; set; }
        [JsonPropertyName("sizename")]
        public string? sizename { get; set; }
        [JsonPropertyName("itemtype")]
        public string? itemtype { get; set; }

    }
    public class addoutofstock
    {
        [JsonPropertyName("customerid")]
        public int customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 itemcode { get; set; }
        [JsonPropertyName("itemsize")]
        public Int64 itemsize { get; set; }
        [JsonPropertyName("stockdate")]
        public string? stockdate { get; set; }
        [JsonPropertyName("userid")]
        public int? userid { get; set; }
    }
    public class loadOutofstocksOP
    {
        [JsonPropertyName("sno")]
        public int sno { get; set; }
        [JsonPropertyName("id")]
        public Int64 id { get; set; }
        [JsonPropertyName("itemname")]
        public string? itemname { get; set; }
        [JsonPropertyName("sizename")]
        public string? sizename { get; set; }
        [JsonPropertyName("stockdate")]
        public string? stockdate { get; set; }
        [JsonPropertyName("username")]
        public string? username { get; set; }
        [JsonPropertyName("createdon")]
        public string? createdon { get; set; }
    }
    public class outofstockIP
    {
        [JsonPropertyName("customerid")]
        public int customerid { get; set; }
    }
    public class stockIP
    {
        [JsonPropertyName("stockid")]
        public int stockid { get; set; }
    }
    /*End*/
    /*Conference call*/
    public class ConferenceCallIP
    {
        [JsonPropertyName("user")]
        public string? user { get; set; }
        [JsonPropertyName("customer")]
        public string? customer { get; set; }

    }
    public class ConferenceCallOP
    {
        [JsonPropertyName("status")]
        public string? Status { get; set; }
        [JsonPropertyName("message")]
        public string? Message { get; set; }

    }
    public class Playaudioip {
        [JsonPropertyName("conferenceid")]
        public string? conferenceid { get; set; }
        [JsonPropertyName("filename")]
        public string? filename { get; set; }
    }
    public class Stopaudioip
    {
        [JsonPropertyName("channel")]
        public string? channel { get; set; }
        [JsonPropertyName("conferenceid")]
        public string? conferenceid { get; set; }
    }

    public class Loadallaudioop
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("customername")]
        public string? Customername { get; set; }
        [JsonPropertyName("companyname")]
        public string? Companyname { get; set; }
        [JsonPropertyName("did")]
        public string? DID { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
        [JsonPropertyName("audiopath")]
        public string? Audiopath { get; set; }
    }
    public class ReqWelcomeAudio
    {
        [JsonPropertyName("itemdata")]
        public string? Itemdata { get; set; }
        [JsonPropertyName("audiofile")]
        public IFormFile? Audiofile { get; set; }

    }

    /*End*/

}

