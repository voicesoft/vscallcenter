﻿using Newtonsoft.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace VS.Restaurant.Modal
{
    public class LoginValues
    {
        [JsonPropertyName("username")]
        public string? UserName { get; set; }
        [JsonPropertyName("password")]
        public string? Password { get; set; }
    }
    public class LoginResultset
    {
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("password")]
        public int Password { get; set; }
        [JsonPropertyName("name")]
        public string? Name { get; set; }
        [JsonPropertyName("mobile")]
        public string? Mobile { get; set; }
        [JsonPropertyName("emalid")]
        public string? Emalid { get; set; }
        [JsonPropertyName("company")]
        public string? Company { get; set; }
        [JsonPropertyName("companyid")]
        public int Companyid { get; set; }
        [JsonPropertyName("roleid")]
        public int Roleid { get; set; }
        [JsonPropertyName("rolename")]
        public string? Rolename { get; set; }
        [JsonPropertyName("lastlogin")]
        public string? Lastlogin { get; set; }
        [JsonPropertyName("status")]
        public int Status { get; set; }
        [JsonPropertyName("message")]
        public string? Message { get; set; }
        [JsonPropertyName("approvetype")]
        public int Approvetype { get; set; }
        [JsonPropertyName("issuperadmin")]
        public int Issuperadmin { get; set; }
        [JsonPropertyName("isadmin")]
        public int Isadmin { get; set; }
        [JsonPropertyName("hasapprove")]
        public int Hasapprove { get; set; }
    }

    #region Itemtype
    public class AdditemValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemtype")]
        public string? Itemtype { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class LoaditemValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemtype")]
        public string? Itemtype { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }

    }
    public class LoaditemResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("idtype")]
        public Int32 Idtype { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemtype")]
        public string? Itemtype { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
        //[JsonPropertyName("totalrow")]
        //public Int32 Totalrow { get; set; }
    }
    public class EdititemValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemtypeid")]
        public Int32 Itemtypeid { get; set; }
        [JsonPropertyName("itemtype")]
        public string? Itemtype { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class DeleteitemValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemtypeid")]
        public Int32 Itemtypeid { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class Defalutresultset
    {
        [JsonPropertyName("status")]
        public Int32 Status { get; set; }
        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }

    public class DefaultResponse
    {
        [JsonPropertyName("orderid")]
        public Int64 OrderId { get; set; }

        [JsonPropertyName("status")]
        public Int32 Status { get; set; }
        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }

    #endregion
    #region Itemsize
    public class AddsizeValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemsize")]
        public string? Itemsize { get; set; }
        [JsonPropertyName("hideagent")]
        public Int32 Hideagent { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class LoadsizeValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemsize")]
        public string? Itemsize { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }

    }
    public class LoadsizeResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("idsize")]
        public Int32 Idsize { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemsize")]
        public string? Itemsize { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
        [JsonPropertyName("hideagent")]
        public Int32 Hideagent { get; set; }
        //[JsonPropertyName("totalrow")]
        //public Int32 Totalrow { get; set; }
    }
    public class EditsizeValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int32 Itemsizeid { get; set; }
        [JsonPropertyName("sizename")]
        public string? Sizename { get; set; }
        [JsonPropertyName("hideagent")]
        public Int32 Hideagent { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class DeletesizeValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int32 Itemsizeid { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("hideagent")]
        public Int32 Hideagent { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    #endregion
    #region Itemmaster
    public class Addmasterfromdata
    {
        [JsonPropertyName("itemdata")]
        public string? Itemdata { get; set; }
        [JsonPropertyName("filename")]
        public IFormFile? Filename { get; set; }
        [JsonPropertyName("audiofile")]
        public IFormFile? Audiofile { get; set; }

    }
    public class AddmasterValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("sizeids")]
        public List<sizelist>? Sizeids { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        //[JsonPropertyName("haspackage")]
        //public Int32 Haspackage { get; set; }
        [JsonPropertyName("isaddonitem")]
        public Int32 Isaddonitem { get; set; }
        [JsonPropertyName("ismodifier")]
        public Int32 Ismodifier { get; set; }
        [JsonPropertyName("applaymodifer")]
        public Int32 Applaymodifer { get; set; }
        [JsonPropertyName("imagepath")]
        public string? imagepath { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
    }
    public class sizelist
    {
        [JsonPropertyName("sizeid")]
        public Int32 sizeid { get; set; }
    }
    public class LoadmasterValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        //[JsonPropertyName("sizeid")]
        //public Int32 Sizeid { get; set; }
        //[JsonPropertyName("haspackage")]
        //public Int32 Haspackage { get; set; }
        [JsonPropertyName("isaddon")]
        public Int32 Isaddon { get; set; }
        [JsonPropertyName("ismodifier")]
        public Int32 Ismodifier { get; set; }
        [JsonPropertyName("applymodifier")]
        public Int32 Applymodifier { get; set; }
        [JsonPropertyName("search")]
        public string? Search { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }

    }
    public class LoadmasterResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("size")]
        public string? Size { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("type")]
        public string? Type { get; set; }
        //[JsonPropertyName("haspackage")]
        //public string? Haspackage { get; set; }
        [JsonPropertyName("isaddonitem")]
        public string? Isaddonitem { get; set; }
        [JsonPropertyName("ismodifier")]
        public string? Ismodifier { get; set; }
        [JsonPropertyName("applaymodifer")]
        public string? Applaymodifer { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("username")]
        public string? Username { get; set; }
        //[JsonPropertyName("totalrow")]
        //public Int32 Totalrow { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
    }
    public class sizeinfo
    {
        [JsonPropertyName("sizeid")]
        public Int32 sizeid { get; set; }
        [JsonPropertyName("sizename")]
        public string? sizename { get; set; }
    }
    public class EditmasterValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("sizeids")]
        public List<sizelist>? Sizeids { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("haspackage")]
        public Int32 Haspackage { get; set; }
        [JsonPropertyName("isaddonitem")]
        public Int32 Isaddonitem { get; set; }
        [JsonPropertyName("ismodifier")]
        public Int32 Ismodifier { get; set; }
        [JsonPropertyName("applaymodifer")]
        public Int32 Applaymodifer { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
    }
    public class DeletemasterValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    #endregion
    #region Itemprice
    public class AddpriceValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 itemcode { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int64 Itemsizeid { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal Unitprice { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class LoadpriceValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public string? Itemcode { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int64 Itemsizeid { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }

    }
    public class LoadpriceResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("idprice")]
        public Int64 Idprice { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemid")]
        public Int32 Itemid { get; set; }
        [JsonPropertyName("itemcode")]
        public string? Itemcode { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int32 Itemsizeid { get; set; }
        [JsonPropertyName("itemsizename")]
        public string? Itemsizename { get; set; }
        [JsonPropertyName("unitprice")]
        public string? Unitprice { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
        //[JsonPropertyName("totalrow")]
        //public Int32 Totalrow { get; set; }
    }
    public class EditpriceValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("idprice")]
        public Int64 Idprice { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int64 Itemsizeid { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal Unitprice { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    public class DeletepriceValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("idprice")]
        public Int64 Idprice { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    #endregion
    #region Itempackage
    public class AddpackageitemValues
    {
        [JsonPropertyName("customeritemcode")]
        public string? customeritemcode { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("masteritem")]
        public string? Masteritem { get; set; }
        [JsonPropertyName("masteritemdescription")]
        public string? Masteritemdescription { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("packagevalues")]
        public List<AddpackageValues>? Packagevalues { get; set; }
    }
    public class AddpackageValues
    {
        [JsonPropertyName("serialno")]
        public Int32 serialno { get; set; }
        [JsonPropertyName("itemtype")]
        public Int32 Itemtype { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 itemcode { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int64 itemsizeid { get; set; }
        [JsonPropertyName("itemprice")]
        public decimal itemprice { get; set; }
        [JsonPropertyName("discount")]
        public decimal discount { get; set; }
        [JsonPropertyName("discounttype")]
        public Int32 discounttype { get; set; }
        [JsonPropertyName("discountamount")]
        public decimal discountamount { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal unitprice { get; set; }

    }
    public class LoadpackageValues
    {
        /*
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("packageitemcode")]
        public Int64 Packageitemcode { get; set; }
        [JsonPropertyName("serialno")]
        public Int32 Serialno { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int64 Itemsizeid { get; set; }
        [JsonPropertyName("itemprice")]
        public decimal Itemprice { get; set; }
        [JsonPropertyName("discount")]
        public decimal Discount { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal Unitprice { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }
        */
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }
    }
    public class LoadpackageResultset
    {
        /* [JsonPropertyName("sno")]
         public Int32 Sno { get; set; }
         [JsonPropertyName("idpackage")]
         public Int64 Idpackage { get; set; }
         [JsonPropertyName("customerid")]
         public Int32 Customerid { get; set; }
         [JsonPropertyName("packageitemcode")]
         public Int64 Packageitemcode { get; set; }
         [JsonPropertyName("serialno")]
         public Int32 serialno { get; set; }
         [JsonPropertyName("itemcode")]
         public Int64 Itemcode { get; set; }
         [JsonPropertyName("itemsizeid ")]
         public Int64 Itemsizeid { get; set; }
         [JsonPropertyName("itemprice")]
         public decimal Itemprice { get; set; }
         [JsonPropertyName("discount")]
         public decimal Discount { get; set; }
         [JsonPropertyName("unitprice")]
         public decimal Unitprice { get; set; }
         [JsonPropertyName("createdby")]
         public string? Createdby { get; set; }
         [JsonPropertyName("createdon")]
         public string? Createdon { get; set; }*/
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("customerid")]
        public Int64 Customerid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("masteritemid")]
        public Int64 Masteritemid { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("packageitems")]
        public string? Packageitems { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
    }
    public class EditpackageValues
    {
        /*  [JsonPropertyName("customerid")]
          public Int32 Customerid { get; set; }
          [JsonPropertyName("idpackage")]
          public Int64 Idpackage { get; set; }
          [JsonPropertyName("packageitemcode")]
          public Int64 Packageitemcode { get; set; }
          [JsonPropertyName("serialno")]
          public Int64 Serialno { get; set; }
          [JsonPropertyName("itemcode")]
          public Int64 Itemcode { get; set; }
          [JsonPropertyName("itemsizeid")]
          public Int64 Itemsizeid { get; set; }
          [JsonPropertyName("itemprice")]
          public decimal Itemprice { get; set; }
          [JsonPropertyName("discount")]
          public decimal Discount { get; set; }
          [JsonPropertyName("unitprice")]
          public decimal Unitprice { get; set; }
          [JsonPropertyName("userid")]
          public Int32 userid { get; set; }*/
        [JsonPropertyName("customeritemcode")]
        public Int64 Customeritemcode { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("masteritemid")]
        public Int64 Masteritemid { get; set; }
        [JsonPropertyName("masteritem")]
        public string? Masteritem { get; set; }
        [JsonPropertyName("masteritemdescription")]
        public string? Masteritemdescription { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("packagevalues")]
        public List<AddpackageValues>? Packagevalues { get; set; }
    }
    public class DeletepackageValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("masteritemid")]
        public Int64 Masteritemid { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    #endregion
}
