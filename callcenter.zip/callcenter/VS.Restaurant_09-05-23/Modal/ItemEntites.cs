﻿using System.Text.Json.Serialization;

namespace VS.Restaurant.Modal
{
    public class ReqBlackList
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("contactnumber")]
        public string? Contactnumber { get; set; }
        [JsonPropertyName("consumername")]
        public string? Consumername { get; set; }
        [JsonPropertyName("isblock")]
        public int Isblock { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }

    }
    public class ReqItemDelays
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("minutes")]
        public Int64 Minutes { get; set; }
    }
    public class ReqFactoryPause
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }

        [JsonPropertyName("minutes")]
        public Int64 Minutes { get; set; }
    }

    public class ReqItemOfTheDay
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
    }

    public class ReqItemPromotion
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
        [JsonPropertyName("endtime")]
        public string? Endtime { get; set; }
    }

    public class ReqLoadBlacList
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("pageno")]
        public int Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public int Pagesize { get; set; }
    }
    public class ResLoadBlacList
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("idblock")]
        public Int64 idblock { get; set; }
        [JsonPropertyName("contactnumber")]
        public string? Contactnumber { get; set; }
        [JsonPropertyName("consumername")]
        public string? Consumername { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
    }

    public class ReqRemoveItem
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("transId")]
        public Int64 TransId { get; set; }

    }
    public class ReqRemoveBlackList
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("transId")]
        public Int64 TransId { get; set; }
        [JsonPropertyName("block")]
        public int Block { get; set; }
    }

    public class ReqItemList
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
    }
    public class ResItemList
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("transid")]
        public Int64 Transid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
        [JsonPropertyName("endtime")]
        public string? Endtime { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
        [JsonPropertyName("delayminutes")]
        public int Delayminutes { get; set; }

    }

    public class ReqDelay
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
    }
    public class ResDelayList
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("transid")]
        public Int64 Transid { get; set; }
        [JsonPropertyName("starttime")]
        public string? Starttime { get; set; }
        [JsonPropertyName("endtime")]
        public string? Endtime { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
        [JsonPropertyName("delayminutes")]
        public int Delayminutes { get; set; }

    }
    public class ReqAddOverAllDelay
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("userid")]
        public int Userid { get; set; }
        [JsonPropertyName("delayminutes")]
        public int Delayminutes { get; set; }
    }
    public class ReqAddBalcklistmembers
    {
        [JsonPropertyName("customerid")]
        public int Customerid { get; set; }
        [JsonPropertyName("pageno")]
        public int Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public int Pagesize { get; set; }
        [JsonPropertyName("date")]
        public string? date { get; set; }
        [JsonPropertyName("searchtext")]
        public string? Searchtext { get; set; }
    }
    public class ResAddBalcklistmembers
    {
        [JsonPropertyName("sno")]
        public int Sno { get; set; }
        [JsonPropertyName("consumerid")]
        public Int64 Consumerid { get; set; }
        [JsonPropertyName("consumername")]
        public string? Consumername { get; set; }
        [JsonPropertyName("contactno")]
        public string? Contactno { get; set; }
        [JsonPropertyName("orderid")]
        public Int64 Orderid { get; set; }
        [JsonPropertyName("orderdate")]
        public string? Orderdate { get; set; }
        [JsonPropertyName("orderstatus")]
        public string? Orderstatus { get; set; }
        [JsonPropertyName("noofitems")]
        public int Noofitems { get; set; }
        [JsonPropertyName("amount")]
        public decimal Amount { get; set; }
        [JsonPropertyName("taxamount")]
        public decimal Taxamount { get; set; }
        [JsonPropertyName("totalamount")]
        public decimal Totalamount { get; set; }
        [JsonPropertyName("deliverytime")]
        public int Deliverytime { get; set; }
        [JsonPropertyName("totalrow")]
        public int Totalrow { get; set; }
    }
}
