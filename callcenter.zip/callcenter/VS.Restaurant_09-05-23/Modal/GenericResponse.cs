﻿using System.Text.Json.Serialization;

namespace VS.Restaurant.Modal
{
    public class GenericResponse
    {
             public dynamic? Data { get; set; }
    }
}
