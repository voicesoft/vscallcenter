﻿using System.Text.Json.Serialization;

namespace VS.Restaurant.Modal
{
    public class Pizzacorner
    {
    }
    #region Loadpizzabase
    public class LoadmasterbaseReq
    {
        [JsonPropertyName("resturantid")]
        public Int32 Resturantid { get; set; }
    }
    public class LoadmasterbaseRes
    {
        [JsonPropertyName("sno")]
        public Int32 SNo { get; set; }
        [JsonPropertyName("baseid")]
        public Int32 Baseid { get; set; }
        [JsonPropertyName("basename")]
        public string? Basename { get; set; }
        [JsonPropertyName("basecode")]
        public string? Basecode { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
    }
    #endregion
    #region Addpizzabase
    public class OperatemasterbaseReq
    {
        [JsonPropertyName("restaurantid")]
        public Int32 Restaurantid { get; set; }
        [JsonPropertyName("baseid")]
        public Int64 Baseid { get; set; }
        [JsonPropertyName("basename")]
        public string? Basename { get; set; }
        [JsonPropertyName("basecode")]
        public string? Basecode { get; set; }
        [JsonPropertyName("createdby")]
        public Int32 Createdby { get; set; }
        //[JsonPropertyName("operationtype")]
        //public int Operationtype { get; set; }
    }
    public class DeletemasterbaseReq
    {
        [JsonPropertyName("restaurantid")]
        public Int32 Restaurantid { get; set; }
        [JsonPropertyName("baseid")]
        public Int64 Baseid { get; set; }
        [JsonPropertyName("createdby")]
        public Int32 Createdby { get; set; }
        //[JsonPropertyName("operationtype")]
        //public int Operationtype { get; set; }
    }
    #endregion
    #region Loadpizzatopings
    public class LoadmastertopingsRes
    {
        [JsonPropertyName("sno")]
        public int SNo { get; set; }
        [JsonPropertyName("topingid")]
        public Int64 Topingid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Custoemritemcode { get; set; }
        [JsonPropertyName("topingname")]
        public string? Topingname { get; set; }
        [JsonPropertyName("fullprice")]
        public string? Fullprice { get; set; }
        [JsonPropertyName("halfprice")]
        public string? Halfprice { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
    }
    public class AddmasttertopingsReq
    {
        [JsonPropertyName("resturantid")]
        public int Resturantid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("topingname")]
        public string? Topingname { get; set; }
        [JsonPropertyName("fullprice")]
        public decimal Fullprice { get; set; }
        [JsonPropertyName("halfprice")]
        public decimal Halfprice { get; set; }
        [JsonPropertyName("createdby")]
        public int Createdby { get; set; }
    }
    public class UpdatemasttertopingsReq
    {
        [JsonPropertyName("resturantid")]
        public int Resturantid { get; set; }
        [JsonPropertyName("topingid")]
        public Int64 Topingid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("topingname")]
        public string? Topingname { get; set; }
        [JsonPropertyName("fullprice")]
        public decimal Fullprice { get; set; }
        [JsonPropertyName("halfprice")]
        public decimal Halfprice { get; set; }
        [JsonPropertyName("createdby")]
        public int Createdby { get; set; }
    }
    #endregion
    #region CommonRes
    public class OPRes
    {
        [JsonPropertyName("status")]
        public int Status { get; set; }
        [JsonPropertyName("message")]
        public string? Message { get; set; }
    }
    #endregion
    #region Itempackage
    //public class Addmasterpizzafromdata
    //{
    //    [JsonPropertyName("itemdata")]
    //    public string? Itemdata { get; set; }
    //    [JsonPropertyName("filename")]
    //    public IFormFile? Filename { get; set; }
    //}
    public class AddpackageitempizzaValues
    {
        [JsonPropertyName("customeritemcode")]
        public string? customeritemcode { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }

        [JsonPropertyName("masteritem")]
        public string? Masteritem { get; set; }
        [JsonPropertyName("masteritemdescription")]
        public string? Masteritemdescription { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("packagevalues")]
        public List<AddpackagepizzaValues>? Packagevalues { get; set; }
    }
    public class AddpackagepizzaValues
    {
        [JsonPropertyName("serialno")]
        public Int32 serialno { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 itemcode { get; set; }
        [JsonPropertyName("itemtype")]
        public Int32 itemtype { get; set; }
        [JsonPropertyName("itemsizeid")]
        public Int64 itemsizeid { get; set; }
        [JsonPropertyName("itemprice")]
        public decimal itemprice { get; set; }
        [JsonPropertyName("discount")]
        public decimal discount { get; set; }
        [JsonPropertyName("discounttype")]
        public string? description { get; set; }
        [JsonPropertyName("description")]
        public Int32 discounttype { get; set; }
        [JsonPropertyName("discountamount")]
        public decimal discountamount { get; set; }
        [JsonPropertyName("unitprice")]
        public decimal unitprice { get; set; }
        [JsonPropertyName("itemvalues")]
        public List<itemtypeval>? itemtypeval { get; set; }

    }
    public class itemtypeval
    {
        [JsonPropertyName("itemid")]
        public Int64 itemid { get; set; }
        [JsonPropertyName("itemname")]
        public string? itemname { get; set; }
    }
    public class LoadpackagepizzaValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }
    }
    public class LoadpackagepizzaResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("customerid")]
        public Int64 Customerid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("masteritemid")]
        public Int64 Masteritemid { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("packageitems")]
        public string? Packageitems { get; set; }
        [JsonPropertyName("createdby")]
        public string? Createdby { get; set; }
        [JsonPropertyName("createdon")]
        public string? Createdon { get; set; }
    }
    public class EditpackagepizzaValues
    {
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("masteritemid")]
        public Int64 Masteritemid { get; set; }
        [JsonPropertyName("masteritem")]
        public string? Masteritem { get; set; }
        [JsonPropertyName("masteritemdescription")]
        public string? Masteritemdescription { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("packagevalues")]
        public List<AddpackagepizzaValues>? Packagevalues { get; set; }
    }
    public class DeletepackagepizzaValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("masteritemid")]
        public Int64 Masteritemid { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
    #endregion
    #region Itemmaster
    public class Addmasterpizzafromdata
    {
        [JsonPropertyName("itemdata")]
        public string? Itemdata { get; set; }
        [JsonPropertyName("filename")]
        public IFormFile? Filename { get; set; }
        [JsonPropertyName("audiofile")]
        public IFormFile? Audiofile { get; set; }

    }
    public class AddmasterpizzaValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("sizeids")]
        public List<sizelist>? Sizeids { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("isaddonitem")]
        public Int32 Isaddonitem { get; set; }
        [JsonPropertyName("ismodifier")]
        public Int32 Ismodifier { get; set; }
        [JsonPropertyName("applaymodifer")]
        public Int32 Applaymodifer { get; set; }
        [JsonPropertyName("imagepath")]
        public string? imagepath { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
        [JsonPropertyName("extraaddonlimit")]
        public Int32 Extraaddonlimit { get; set; }
        [JsonPropertyName("defaultremovecount")]
        public Int32 Defaultremovecount { get; set; }
        [JsonPropertyName("defaulttoppings")]
        public List<defaluttoppingslist>? Defaulttoppings { get; set; }
        [JsonPropertyName("isown")]
        public Int32 Isown { get; set; }
        [JsonPropertyName("addonlimit")]
        public Int32 Addonlimit { get; set; }
        [JsonPropertyName("itembase")]
        public List<Baseinfo>? Itembase { get; set; }
    }
    public class Baseinfo
    {
        [JsonPropertyName("baseid")]
        public Int32 baseid { get; set; }
        [JsonPropertyName("basename")]
        public string? Basename { get; set; }
    }
    public class defaluttoppingslist
    {
        [JsonPropertyName("toppingid")]
        public Int32 toppingid { get; set; }
    }
    public class LoadmasterpizzaValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("isaddon")]
        public Int32 Isaddon { get; set; }
        [JsonPropertyName("ismodifier")]
        public Int32 Ismodifier { get; set; }
        [JsonPropertyName("applymodifier")]
        public Int32 Applymodifier { get; set; }
        [JsonPropertyName("search")]
        public string? Search { get; set; }
        [JsonPropertyName("fromdate")]
        public string? Fromdate { get; set; }
        [JsonPropertyName("todate")]
        public string? Todate { get; set; }
        [JsonPropertyName("pageno")]
        public Int32 Pageno { get; set; }
        [JsonPropertyName("pagesize")]
        public Int32 Pagesize { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }

    }
    public class LoadmasterpizzaResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("size")]
        public string? Size { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("type")]
        public string? Type { get; set; }
        [JsonPropertyName("isaddonitem")]
        public string? Isaddonitem { get; set; }
        [JsonPropertyName("ismodifier")]
        public string? Ismodifier { get; set; }
        [JsonPropertyName("applaymodifer")]
        public string? Applaymodifer { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("username")]
        public string? Username { get; set; }

        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
        [JsonPropertyName("extraaddonlimit")]
        public string? Extraaddonlimit { get; set; }
        [JsonPropertyName("addonremovelimit")]
        public string? Addonremovelimit { get; set; }
        [JsonPropertyName("isown")]
        public string? Isown { get; set; }
        [JsonPropertyName("addonlimit")]
        public string? Addonlimit { get; set; }
        [JsonPropertyName("defaulttoppings")]
        public string? Defaulttoppings { get; set; }
        [JsonPropertyName("defaultbase")]
        public string? Defaultbase { get; set; }
        
    }

    public class AgentStatusResultset
    {
        [JsonPropertyName("sno")]
        public Int32 Sno { get; set; }
        [JsonPropertyName("languagelist")]
        public string? Languagelist { get; set; }
       
    }
    public class EditmasterpizzaValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("customeritemcode")]
        public string? Customeritemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("sizeids")]
        public List<sizelist>? Sizeids { get; set; }
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("haspackage")]
        public Int32 Haspackage { get; set; }
        [JsonPropertyName("isaddonitem")]
        public Int32 Isaddonitem { get; set; }
        [JsonPropertyName("ismodifier")]
        public Int32 Ismodifier { get; set; }
        [JsonPropertyName("applaymodifer")]
        public Int32 Applaymodifer { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
        [JsonPropertyName("category")]
        public string? Category { get; set; }
        [JsonPropertyName("audiofile")]
        public string? Audiofile { get; set; }
        [JsonPropertyName("extraaddonlimit")]
        public Int32 Extraaddonlimit { get; set; }
        [JsonPropertyName("defaultremovecount")]
        public Int32 Defaultremovecount { get; set; }
        [JsonPropertyName("defaulttoppings")]
        public List<defaluttoppingslist>? Defaulttoppings { get; set; }
        [JsonPropertyName("isown")]
        public Int32 Isown { get; set; }
        [JsonPropertyName("addonlimit")]
        public Int32 Addonlimit { get; set; }
        [JsonPropertyName("itembase")]
        public List<Baseinfo>? Itembase { get; set; }
    }
    public class DeletemasterpizzaValues
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("reason")]
        public string? Reason { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }

    public class Companyddl
    {
        [JsonPropertyName("restaurantid")]
        public int Restaurantid { get; set; }
        [JsonPropertyName("restaurantname")]
        public string? Restaurantname { get; set; }
    }
    #endregion
    #region Itemdata
    public class itemdatares
    {
        [JsonPropertyName("itemcode")]
        public Int64 Itemcode { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
        [JsonPropertyName("itemdescription")]
        public string? Itemdescription { get; set; }
        [JsonPropertyName("imagepath")]
        public string? Imagepath { get; set; }
        [JsonPropertyName("extraaddonlimit")]
        public Int32 Extraaddonlimit { get; set; }
        [JsonPropertyName("addonremovelimit")]
        public Int32 Addonremovelimit { get; set; }
        [JsonPropertyName("isown")]
        public Int32 Isown { get; set; }
        [JsonPropertyName("addonlimit")]
        public Int32 Addonlimit { get; set; }
        [JsonPropertyName("sizeinfo")]
        public string? Sizeinfo { get; set; }
        [JsonPropertyName("baseinfo")]
        public string? Baseinfo { get; set; }
        [JsonPropertyName("defaulttoppinginfo")]
        public string? Defaulttoppinginfo { get; set; }
        [JsonPropertyName("toppinginfo")]
        public string? Toppinginfo { get; set; }
        [JsonPropertyName("restaurantid")]
        public Int64 Restaurantid { get; set; }
    }
    #endregion
    #region Loaditemtypeddlop
    public class Loaditemtyperes
    {
        [JsonPropertyName("typeid")]
        public Int32 Typeid { get; set; }
        [JsonPropertyName("typename")]
        public string? Typename { get; set; }
    }
    public class Loaditemnameres
    {
        [JsonPropertyName("itemid")]
        public Int32 Itemid { get; set; }
        [JsonPropertyName("itemname")]
        public string? Itemname { get; set; }
    }
    #endregion
    public class DeleteaudiofileIP
    {
        [JsonPropertyName("customerid")]
        public Int32 Customerid { get; set; }
        [JsonPropertyName("userid")]
        public Int32 Userid { get; set; }
    }
}
