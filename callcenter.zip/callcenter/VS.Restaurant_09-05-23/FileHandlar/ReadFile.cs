﻿ 
namespace VS.Restaurant.FileHandlar
{
    public class ReadFile
    {
        public IConfigurationRoot GetConnection()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
            return builder;
        }
    }
}
