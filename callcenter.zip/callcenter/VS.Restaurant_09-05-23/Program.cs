using System.Text.Json;
using VS.Restaurant.Interface;
using VS.Restaurant.Providers;
using VS.Restaurant.Repository;
using VS.Restaurant.Repository.Interfaces;
using Newtonsoft.Json;
using VS.Restaurant.Middleware;

var builder = WebApplication.CreateBuilder(args);
builder.WebHost.ConfigureKestrel((context, options) =>
{
    options.Listen(System.Net.IPAddress.Any, 5006);
});
// Add services to the container.
builder.Services.AddControllers();
 
//builder.Services.AddControllers().AddJsonOptions(options =>
//        options.JsonSerializerOptions.PropertyNameCaseInsensitive = false);
//builder.Services.AddControllers().AddJsonOptions(options =>
//           { options.JsonSerializerOptions.PropertyNamingPolicy = null; });

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<VSRAdminProviderInterface, VSRAdminProvider>();
builder.Services.AddScoped<VSRAdminRepositoryInterface, VSRAdminRepository>();
builder.Services.AddScoped<VSRProviderInterface, VSRProvder>();
builder.Services.AddScoped<VSRRepositoryInterface, VSRRepository>();

builder.Services.AddScoped<IAgentRepository, CRUDAgents>();
builder.Services.AddScoped<IAgentInterface, BALAgents>();
builder.Services.AddScoped<IOrder, Order>();
builder.Services.AddScoped<IOrderCreation, BALOrder>();

builder.Services.AddScoped<ICallStatusUpdateBase, BALCallStatus>();
builder.Services.AddScoped<ICallStatus, DALCallStatus>();

builder.Services.AddScoped<IAgentmonitorProvider, AgentmonitorProvider>();
builder.Services.AddScoped<IAgentmonitorRepository, AgentmonitorRepository>();

builder.Services.AddScoped<IPizzacornerProvider, PizzacornerProvider>();
builder.Services.AddScoped<IPizzacornerRepository, PizzacornerRepository>();

builder.Services.AddScoped<IStoreSettings, StoreSettings>();
builder.Services.AddScoped<IFactorySettings, FactorySettings>();

var app = builder.Build();

app.UseMiddleware<ErrorHandlerMiddleware>();
app.UseCors(x => { x.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod(); });
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment()||app.Environment.IsProduction())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();



app.MapControllers();



app.Run();
