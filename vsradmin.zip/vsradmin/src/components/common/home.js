import React from "react";
import "./common.css";
import { useEffect, forwardRef, useState, useRef } from "react";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";
import TableContainer from "@mui/material/TableContainer";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import Paper from "@mui/material/Paper";
import { stringAvatar } from "./avatar";
import { Overlay, Popover } from "react-bootstrap";
import istudiologo from "../../images/vslogo.png";
import PlayCircleOutlineIcon from "@mui/icons-material/PlayCircleOutline";
import DriveFolderUploadIcon from "@mui/icons-material/DriveFolderUpload";
import {
  Box,
  FormControl,
  Button,
  TextField,
  MenuItem,
  Slide,
  Stack,
  Dialog,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import AddCircleOutlineOutlinedIcon from "@mui/icons-material/AddCircleOutlineOutlined";
import Addcompany from "./addcompany";
import Addagent from "./addagent";
import ReactPaginate from "react-paginate";
import { ToastContainer, toast } from "react-toastify";
import {
  LoadCompany,
  AddCompany,
  LoadAgent,
  AddCustomerinfo,
  Loadcompanyddl,
  LoadUploadedaudio,
  Uploadaudio,
  Deleteaudio,
  Welcomeaudio,
  ListWelcomeaudio,
} from "../../store/action/index";
import { connect } from "react-redux";
import AppRegistrationOutlinedIcon from "@mui/icons-material/AppRegistrationOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ViewAgendaOutlinedIcon from "@mui/icons-material/ViewAgendaOutlined";
/* Dialog*/
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import TextareaAutosize from "@mui/base/TextareaAutosize";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import { useNavigate } from "react-router-dom";
import { Search } from "../common/search/search";
import { SearchIconWrapper } from "../common/search/searchiconwrapper";
import { StyledInputBase } from "../common/search/styledinputbase";
import { debounce } from "throttle-debounce";
import Loader from "../common/loader";

const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="left" ref={ref} {...props} />;
});
const Home = ({
  loadCompany,
  addCompany,
  loadAgent,
  addCustomerinfo,
  loadcompanyddl,
  loadUploadedaudio,
  uploadaudio,
  deleteaudio,
  welcomeaudio,
  listwelcomeaudio,
  state,
}) => {
  /* Declarations */
  let navigate = useNavigate();
  const menuId = "primary-search-account-menu";
  // const [values, setValues] = useState([
  //   new DateObject().subtract(7, "days"),
  //   new DateObject().add(0, "days"),
  // ]);
  const input = useRef(null);
  const [addcompany, setaddcompany] = useState(false);
  const [addagent, setaddagent] = useState(false);
  const [companyinfo, setCompanyinfo] = useState([]);
  const [agentinfo, setAgentinfo] = useState([]);
  const [totalrow, setTotalrow] = useState(0);
  const [totalagent, setTotalagent] = useState(0);
  const [totalcount, setTotalcount] = useState(0);
  const [searchData, setSearchData] = useState("");
  const [pagenumber, setPageNumber] = useState(1);
  const [companydetail, setCompanydetail] = useState([]);
  const [rejectconfirm, setRejectconfirm] = useState(false);
  const [rejectaudio, setRejectaudio] = useState(false);
  const [audiodetail, setAudiodetail] = useState([]);
  const [deletereason, setDeleteReason] = useState("");
  const [show, setShow] = useState(false);
  const [target, setTarget] = useState(null);
  const [openloading, setOpenloading] = useState(false);
  const [openapipopup, setOpenApipopup] = useState(false);
  const [merchantid, setMerchantid] = useState("");
  const [clientid, setClientid] = useState("");
  const [secretkey, setSecretkey] = useState("");
  const [secretcode, setSecretcode] = useState("");
  const [authtoken, setAuthtoken] = useState("");
  const [pos, setPOS] = useState("");
  const [customerid, setCustomerid] = useState(0);
  const [validmerchantid, setValidMerchantid] = useState(true);
  const [validclientid, setValidClientid] = useState(true);
  const [validsecretkey, setValidSecretkey] = useState(true);
  const [validsecretcode, setValidSecretcode] = useState(true);
  const [validauthtoken, setValidAuthtoken] = useState(true);
  const [validpos, setValidPOS] = useState(true);
  const [searchItem, setSearchItem] = useState("");
  const [pageno, setPageno] = useState(1);
  const debounceFunc = debounce(
    1000,
    (value) => {
      setSearchData(value);
    },
    { atBegin: false }
  );
  //Upload audio
  const [audioinfo, setAudioinfo] = useState([]);
  const [companydll, setCompanydll] = useState([]);
  const [restaurantid, setRestaurantID] = useState("");
  const [totalaudio, setTotalaudio] = useState(0);
  const [audiocount, setAudiocount] = useState(0);
  const [openAudio, setopenAudio] = useState(false);
  const [selectedAudio, setSelectedAudio] = useState(null);
  const [welcomefile, setWelcomefile] = useState(false);
  const [listWelcomefile, setListWelcomefile] = useState([]);

  useEffect(() => {
    handlelistcompany();
    handlelistagent();
    listUploadedaudio();
    loadcompanyddl()
      .then((response) => {
        setCompanydll(response.data.resultset);
      })
      .catch((error) => {
        console.log(error);
      });
  }, [searchData, pagenumber, pageno]);

  // ADD AND EDIT COMPANY
  const addnewclick = (params) => {
    setaddcompany(true);
    setCompanydetail(params);
  };
  const handleCloseaddcompany = () => {
    setaddcompany(false);
  };
  // OPEN DELETE DIALOG
  const handleopenreject = (params) => {
    setRejectconfirm(true);
    setCompanydetail(params);
  };
  // OPEN API POPUP
  const handleapimodal = (params) => {
    setCustomerid(params.customerid);
    setOpenApipopup(true);
  };
  const handleClear = () => {
    setMerchantid("");
    setClientid("");
    setSecretkey("");
    setSecretcode("");
    setAuthtoken("");
    setPOS("");
  };
  const handleClose = () => {
    handleClear();
    setOpenApipopup(false);
  };
  // ADD AGENT
  const addnewagent = () => {
    setaddagent(true);
  };
  const handleCloseaddagent = () => {
    setaddagent(false);
  };
  // LIST COMPANY
  const handlelistcompany = () => {
    setOpenloading(true);
    let params = {
      search: searchData,
      pageno: pagenumber,
    };
    loadCompany(params)
      .then((response) => {
        setCompanyinfo(response.data.resultset);
        setTotalrow(response.data.resultset.length);
        setTotalcount(Math.ceil(response.data.totalrow / 10));
        setTimeout(() => {
          setOpenloading(false);
        }, 500);
      })
      .catch((error) => {
        console.log("error: ", error);
        setTimeout(() => {
          setOpenloading(false);
        }, 500);
      });
  };
  // DELETE COMPANY
  const handledeletecompany = () => {
    if (deletereason !== "") {
      let params = {
        type: 3,
        companyName: deletereason,
        companyId: companydetail.customerid,
        customerName: "",
        email: "",
        username: "",
        firstName: "",
        lastName: "",
        regNumber: "",
        address1: "",
        address2: "",
        address3: "",
        country: "",
        zipcode: "",
        contactNumber: "",
        contactPerson: "",
        contactPersonNumber: "",
        did: "",
        onlineURL: "",
        deliveryType: 0,
        orderComission: 0,
        hours: "",
        minutes: "",
        createdby: state.loginreducer.logininfo.data.data[0].userid,
      };
      addCompany(params)
        .then((response) => {
          if (response.data.resultSet[0].status === 1) {
            toast.success(response.data.resultSet[0].message, {
              autoClose: 1000,
            });
            setRejectconfirm(false);
            handlepageno();
            handlelistcompany();
            setDeleteReason("");
          } else if (response.data.resultSet[0].status === 2) {
            toast.warning(response.data.resultSet[0].message, {
              autoClose: 1000,
            });
          } else {
            toast.error(response.data.resultSet[0].message, {
              autoClose: 1000,
            });
          }
        })
        .catch((error) => {
          console.log("error: ", error);
        });
    } else {
      input.current.focus();
      // toast.warning("Enter delete reason", { autoClose: 2000 });
    }
    // handlelistcompany();
  };
  // LIST AGENT
  const handlelistagent = () => {
    setOpenloading(true);
    let param = {
      userid: state.loginreducer.logininfo.data.data[0].userid,
    };
    loadAgent(param)
      .then((response) => {
        setAgentinfo(response.data.resultset);
        setTotalagent(response.data.resultset.length);
        setTimeout(() => {
          setOpenloading(false);
        }, 500);
      })
      .catch((error) => {
        console.log("error: ", error);
        setTimeout(() => {
          setOpenloading(false);
        }, 500);
      });
  };
  const handlesaveinfo = () => {
    if (
      merchantid !== "" &&
      clientid !== "" &&
      secretkey !== "" &&
      secretcode !== "" &&
      authtoken !== "" &&
      pos !== ""
    ) {
      let params = {
        companyid: customerid,
        merchantid: merchantid,
        clientid: clientid,
        secretkey: secretkey,
        secretcode: secretcode,
        authtoken: authtoken,
        pos: pos,
      };
      addCustomerinfo(params)
        .then((response) => {
          if (response.data.resultset[0].status === 1) {
            toast.success(response.data.resultset[0].message, {
              autoClose: 2000,
            });
            setTimeout(() => {
              setOpenApipopup(false);
            }, 1000);
            handleClear();
            handlelistcompany();
          } else if (response.data.resultset[0].status === 2) {
            toast.warning(response.data.resultset[0].message, {
              autoClose: 2000,
            });
          } else {
            toast.error(response.data.resultset[0].message, {
              autoClose: 2000,
            });
          }
        })
        .catch((error) => {
          console.log("error: ", error);
        });
    } else {
      formvalidate();
    }
  };
  // LIST UPLOADED AUDIO
  const listUploadedaudio = () => {
    let params = {
      search: searchItem,
      pageno: pageno,
    };
    loadUploadedaudio(params)
      .then((response) => {
        setAudioinfo(response.data.resultset);
        setTotalaudio(response.data.resultset.length);
        setAudiocount(Math.ceil(response.data.totalrow / 10));
      })
      .catch((error) => {
        console.log(error);
      });
  };
  const handleAudio = (event) => {
    setSelectedAudio(event.target.files[0]);
  };

  // UPLOAD AUDIOFILE
  const saveUploadaudio = (event) => {
    event.preventDefault();
    if (restaurantid != "" && restaurantid != "0") {
      let param = {
        customerid: parseInt(restaurantid),
        userid: state.loginreducer.logininfo.data.data[0].userid,
      };
      const formData = new FormData();
      formData.append("itemdata", JSON.stringify(param));
      selectedAudio &&
        formData.append("audiofile", selectedAudio, selectedAudio.name);
      uploadaudio(formData)
        .then((response) => {
          if (response.data.data[0].status === 1) {
            toast.success(response.data.data[0].message, {
              autoClose: 1000,
            });
            setopenAudio(false);
            handlepageno();
            listUploadedaudio();
            setRestaurantID("");
          } else if (response.data.data[0].status === 0) {
            toast.warning(response.data.data[0].message, {
              autoClose: 1000,
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      toast.warning("Please select restaurant", {
        autoClose: 1000,
      });
    }
  };

  // UPLOAD WELCOME FILE
  const saveWelcomeaudio = (event) => {
    setOpenloading(true);
    event.preventDefault();
    let param = {
      customerid: parseInt(restaurantid),
      userid: state.loginreducer.logininfo.data.data[0].userid,
    };
    const formData = new FormData();
    formData.append("itemdata", JSON.stringify(param));
    selectedAudio &&
      formData.append("audiofile", selectedAudio, selectedAudio.name);
    if (selectedAudio != null) {
      welcomeaudio(formData)
        .then((response) => {
          if (response.data.status === 1) {
            toast.success(response.data.message, {
              autoClose: 1000,
            });
            setOpenloading(false);
            setWelcomefile(false);
            handlepageno();
            handlelistcompany();
            setRestaurantID("");
          } else if (response.data.status === -1) {
            toast.warning(response.data.message, {
              autoClose: 1000,
            });
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } else {
      toast.warning("Please choose audio", {
        autoClose: 1000,
      });
    }
  };
  
  // Load WELCOME FILE
  const loadWelcomeaudio = (row, restaurantid) => {
    setWelcomefile(true);
    setRestaurantID(row ? row.customerid : restaurantid);
    let param = {
      customerid: parseInt(row ? row.customerid : restaurantid),
      userid: state.loginreducer.logininfo.data.data[0].userid,
    };
    listwelcomeaudio(param)
      .then((response) => {
        if (response.data.status === 1) {
          setListWelcomefile(response.data.resultset);
        } else if (response.data.status === 0) {
          toast.warning(response.data.message, {
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // OPEN DELETE DIALOG
  const onOpenDeleteModal = (row) => {
    setRejectaudio(true);
    setAudiodetail(row.audio);
  };

  // DELETE UPLOADED AUDIO
  const handleDeleteaudio = (event) => {
    setOpenloading(true);
    event.preventDefault();
    let param = {
      customerid: restaurantid,
      audio: audiodetail,
    };
    deleteaudio(param)
      .then((response) => {
        if (response.data.status === 1) {
          setOpenloading(false);
          toast.success(response.data.message, {
            autoClose: 1000,
          });
          setRejectaudio(false);
          loadWelcomeaudio("", restaurantid);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  // SERVERSIDE PAGINATION FOR COMPANY
  function handlePageClick(event) {
    setPageNumber(event.selected + 1);
  }
  // SERVERSIDE PAGINATION FOR AUDIO
  function handleAudioClick(event) {
    setPageno(event.selected + 1);
  }
  const handlepageno = () => {
    setPageNumber(1);
    setTotalcount();
    setPageno(1);
    setTotalaudio();
  };
  // CLIENT SIDE PAGINATION FOR AGENT
  const [pageItems, setPageItems] = useState(0);
  const usersPerPage = 10;
  const pagesVisited = pageItems * usersPerPage;
  const pageCount = Math.ceil(agentinfo.length / usersPerPage);
  const changePageHandler = ({ selected }) => {
    setPageItems(selected);
  };
  // PROFILE MENU
  const handleProfileMenuOpen = (event) => {
    setShow(!show);
    setTarget(event.target);
  };
  const signouthandler = () => {
    navigate("/");
  };
  // Tostify
  const formvalidate = () => {
    {
      if (merchantid === "") {
        setValidMerchantid(false);
      }
      if (clientid === "") {
        setValidClientid(false);
      }
      if (secretkey === "") {
        setValidSecretkey(false);
      }
      if (secretcode === "") {
        setValidSecretcode(false);
      }
      if (authtoken === "") {
        setValidAuthtoken(false);
      }
      if (pos === "") {
        setValidPOS(false);
      }
    }
    toast.warning("All fields are required!", { autoClose: 2000 });
  };
  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <img
          alt="logo"
          src={istudiologo}
          style={{ marginLeft: "20px", height: "50px" }}
        />
        <div className="col-6">
          <IconButton
            sx={{ float: "right", p: 2 }}
            size="large"
            aria-label="account of current user"
            aria-controls={menuId}
            aria-haspopup="true"
            color="inherit"
            onClick={handleProfileMenuOpen}
          >
            <Avatar
              {...stringAvatar(state.loginreducer.logininfo.data.data[0].name)}
            ></Avatar>
          </IconButton>
        </div>
      </div>
      <div className="dashboard-container">
        <Tabs defaultActiveKey="restaurant" id="tabs-list" className="mb-0">
          <Tab eventKey="restaurant" title="Restaurants">
            <div className="dashboard-items">
              <Search>
                <SearchIconWrapper>
                  <SearchIcon sx={{ color: "#6e7488" }} />
                </SearchIconWrapper>
                <StyledInputBase
                  placeholder="Search..."
                  inputProps={{ "aria-label": "search" }}
                  sx={{
                    border: "1px solid #ced4da",
                    borderRadius: "0.25rem",
                    letterSpacing: "1px",
                    fontSize: "1rem",
                  }}
                  onChange={(event) => {
                    debounceFunc(event.target.value);
                  }}
                  defaultValue={searchData}
                />
              </Search>
              <Button
                sx={{ mt: 1, mb: 1, mr: 2 }}
                className="add-bttn"
                variant="outlined"
                startIcon={<AddCircleOutlineOutlinedIcon />}
                onClick={addnewclick}
              >
                Add
              </Button>
            </div>
            <Box
              sx={{
                height: "calc(100vh - 230px)",
              }}
            >
              <TableContainer
                component={Paper}
                sx={{
                  maxHeight: "calc(100vh - 230px)",
                }}
              >
                <Table
                  stickyHeader
                  aria-label="sticky table"
                  // sx={{ minWidth: "200%" }}
                >
                  <TableHead>
                    <TableRow>
                      <TableCell align="right" className="headerstyle">
                        SNo.
                      </TableCell>
                      <TableCell align="right" className="headerstyle">
                        WelcomeFile
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        CustomerId
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        CustomerName
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        RestaurantName
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Email
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Username
                      </TableCell>
                      {/* <TableCell align="left" className="headerstyle">
                        Firstname
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Lastname
                      </TableCell> */}
                      <TableCell align="left" className="headerstyle">
                        RegisterNo.
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Address1
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Address2
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Address3
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Country
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Zipcode
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Contactnumber
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Contactperson
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        ContactpersonNo.
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        DidNo.
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        OnlineUrl
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Deliverytype
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Ordercommission
                      </TableCell>
                      {/* <TableCell align="center" className="headerstyle">
                        AudioFile
                      </TableCell> */}
                      <TableCell align="left" className="headerstyle">
                        Action
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Apiresponse
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {companyinfo.map((row, i) => (
                      <TableRow key={i}>
                        <TableCell
                          className="headerstyle"
                          component="th"
                          scope="row"
                          align="right"
                        >
                          {row.sno}
                        </TableCell>
                        <TableCell align="center" className="headerstyle">
                          <Tooltip title="Upload audio" arrow>
                            <DriveFolderUploadIcon
                              sx={{ cursor: "pointer" }}
                              fontSize="medium"
                              color="warning"
                              onClick={() => {
                                loadWelcomeaudio(row);
                              }}
                            ></DriveFolderUploadIcon>
                          </Tooltip>
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.customerid}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.customername.split("¶")[0]}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.companyname}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.customername.split("¶")[1]}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.customername.split("¶")[2]}
                        </TableCell>
                        {/* <TableCell align="left" className="headerstyle">
                          {row.customername.split("¶")[3]}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.customername.split("¶")[4]}
                        </TableCell> */}
                        <TableCell align="left" className="headerstyle">
                          {row.regnumber}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.address1}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.address2}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.address3}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.country}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.zipcode}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.contactnumber}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.contactperson}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.contactpernum}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.did}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.onlineurl}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.delivertype === 1
                            ? "All"
                            : row.delivertype === 2
                            ? "Delivery"
                            : row.delivertype === 3
                            ? "Take away"
                            : ""}
                        </TableCell>
                        <TableCell align="left" className="headerstyle">
                          {row.ordercomission}
                        </TableCell>
                        <TableCell align="center" className="headerstyle">
                          <div style={{ display: "flex" }}>
                            <Tooltip title="Edit" arrow>
                              <AppRegistrationOutlinedIcon
                                sx={{ cursor: "pointer" }}
                                color="warning"
                                onClick={() => {
                                  addnewclick(row);
                                }}
                              />
                            </Tooltip>
                            <Tooltip title="Delete" arrow>
                              <DeleteOutlineOutlinedIcon
                                sx={{ cursor: "pointer" }}
                                color="error"
                                onClick={() => {
                                  handleopenreject(row);
                                }}
                              />
                            </Tooltip>
                          </div>
                        </TableCell>
                        <TableCell align="center" className="headerstyle">
                          <ViewAgendaOutlinedIcon
                            sx={{ cursor: "pointer" }}
                            color="success"
                            onClick={() => {
                              handleapimodal(row);
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                    {totalrow === 0
                      ? [
                          <TableRow>
                            <TableCell
                              className="headerstyle"
                              align="center"
                              colSpan={12}
                            >
                              No Records Found
                            </TableCell>
                          </TableRow>,
                        ]
                      : [""]}
                  </TableBody>
                </Table>
              </TableContainer>
              {totalcount > 1
                ? [
                    <Box
                      sx={{
                        paddingRight: 2,
                        paddingTop: 2,
                        paddingBottom: 0.5,
                        bottom: 0,
                        right: 0,
                        position: "fixed",
                      }}
                    >
                      <ReactPaginate
                        previousLabel={"<"}
                        nextLabel={">"}
                        breakLabel={"..."}
                        breakClassName={"break-me"}
                        pageCount={totalcount}
                        marginPagesDisplayed={2}
                        pageRangeDisplayed={5}
                        onPageChange={handlePageClick}
                        containerClassName={"pagination"}
                        subContainerClassName={"pages pagination"}
                        activeClassName={"active"}
                        id="pagination"
                        activeLinkClassName={"active-button"}
                      />
                    </Box>,
                  ]
                : []}
            </Box>
          </Tab>
          <Tab eventKey="agents" title="Agents">
            <div className="dashboard-items">
              <Button
                sx={{ mt: 1, mb: 1, mr: 2 }}
                className="add-bttn"
                variant="outlined"
                startIcon={<AddCircleOutlineOutlinedIcon />}
                onClick={addnewagent}
              >
                Add
              </Button>
            </div>
            <Box
              sx={{
                height: "calc(100vh - 230px)",
              }}
            >
              <TableContainer
                component={Paper}
                sx={{
                  maxHeight: "calc(100vh - 230px)",
                }}
              >
                <Table
                  stickyHeader
                  aria-label="sticky table"
                  sx={{ minWidth: "100%" }}
                >
                  <TableHead>
                    <TableRow>
                      <TableCell
                        align="right"
                        className="headerstyle"
                        sx={{ width: "5%" }}
                      >
                        SNo.
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Agentname
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Agentcity
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Username
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Usermobile
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        User
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Extension
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Extension password
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {agentinfo
                      .slice(pagesVisited, pagesVisited + usersPerPage)
                      .map((data, i) => (
                        <TableRow key={i}>
                          <TableCell
                            className="headerstyle"
                            component="th"
                            scope="row"
                            align="right"
                          >
                            {pageItems * usersPerPage + (i + 1)}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.agentname}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.agentcity}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.username}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.usermobile}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.user}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.extension}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {data.extensionpwd}
                          </TableCell>
                        </TableRow>
                      ))}
                    {totalagent === 0
                      ? [
                          <TableRow>
                            <TableCell
                              className="headerstyle"
                              align="center"
                              colSpan={10}
                            >
                              No Records Found
                            </TableCell>
                          </TableRow>,
                        ]
                      : [""]}
                  </TableBody>
                </Table>
              </TableContainer>
              {pageCount > 1
                ? [
                    <Box
                      sx={{
                        paddingRight: 2,
                        paddingTop: 2,
                        paddingBottom: 0.5,
                        bottom: 0,
                        right: 0,
                        position: "fixed",
                      }}
                    >
                      <ReactPaginate
                        previousLabel={"<"}
                        nextLabel={">"}
                        breakLabel={"..."}
                        breakClassName={"break-me"}
                        pageCount={pageCount}
                        pageRangeDisplayed={5}
                        onPageChange={changePageHandler}
                        containerClassName={"pagination"}
                        subContainerClassName={"pages pagination"}
                        activeClassName={"active"}
                        id="pagination"
                        activeLinkClassName={"active-button"}
                      />
                    </Box>,
                  ]
                : []}
            </Box>
          </Tab>
        </Tabs>

        <Dialog
          fullScreen
          open={addcompany}
          onClose={handleCloseaddcompany}
          TransitionComponent={Transition}
        >
          <Addcompany
            handleClose={handleCloseaddcompany}
            companydetail={companydetail}
            refreshcompany={handlelistcompany}
            pageno={handlepageno}
          />
        </Dialog>

        <Dialog
          open={rejectconfirm}
          onClose={() => {
            setRejectconfirm(false);
            setDeleteReason("");
          }}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogContentText sx={{ mt: 1, textAlign: "center" }}>
            <ErrorOutlineOutlinedIcon color="error" sx={{ fontSize: 40 }} />
          </DialogContentText>
          <DialogTitle id="alert-dialog-title">Confirmation</DialogTitle>
          <DialogContent>
            <TextareaAutosize
              aria-label="minimum height"
              minRows={2}
              maxRows={2}
              placeholder="Enter reason to delete"
              style={{
                width: 350,
                outline: "none",
                padding: "5px",
              }}
              onChange={(event) => {
                setDeleteReason(event.target.value);
              }}
              value={deletereason}
              ref={input}
            />
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                setRejectconfirm(false);
                setDeleteReason("");
              }}
              color="error"
              sx={{ textTransform: "none" }}
            >
              Cancel
            </Button>
            <Button
              sx={{ textTransform: "none" }}
              autoFocus
              color="success"
              onClick={handledeletecompany}
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          fullScreen
          sx={{ width: "45%", ml: "55%" }}
          open={addagent}
          onClose={handleCloseaddagent}
        >
          <Addagent
            handleClose={handleCloseaddagent}
            refreshagent={handlelistagent}
            pageno={handlepageno}
          />
        </Dialog>

        <Overlay
          show={show}
          target={target}
          placement="bottom"
          containerPadding={10}
          rootClose
          onHide={() => setShow(false)}
        >
          <Popover className="profile-menu" id="popover-contained">
            <Popover.Body>
              {/* <Avatar
                className="profile-logo"
                {...stringAvatar(
                  state.loginreducer.logininfo.data.data[0].name
                )}
              /> */}
              <h5>{state.loginreducer.logininfo.data.data[0].name}</h5>
              <p className="email_name">
                {state.loginreducer.logininfo.data.data[0].emalid}
              </p>
              {/* <Button
                variant="outlined"
                style={{
                  fontSize: "15px",
                  textTransform: "none",
                }}
                // onClick={changepwdclick}
              >
                Change password
              </Button> */}
              {/* &nbsp; */}
              <Button
                variant="outlined"
                color="error"
                style={{
                  fontSize: "15px",
                  textTransform: "none",
                }}
                onClick={signouthandler}
              >
                Sign out
              </Button>
            </Popover.Body>
          </Popover>
        </Overlay>

        <Dialog fullScreen sx={{ width: "32%", ml: "68%" }} open={openapipopup}>
          <DialogTitle id="alert-dialog-title">Add details</DialogTitle>
          <DialogContent>
            <Stack sx={{ mt: 2, ml: 6 }}>
              <TextField
                sx={{
                  maxWidth: 300,
                }}
                size="small"
                label="Merchant Id"
                helperText="Please enter merchant id"
                autoComplete="off"
                error={!validmerchantid}
                onChange={(event) => {
                  setMerchantid(event.target.value);
                  if (event.target.value !== "") {
                    setValidMerchantid(true);
                  }
                }}
                value={merchantid}
              ></TextField>
              <TextField
                sx={{ maxWidth: 300, mt: 2 }}
                size="small"
                label="Client Id"
                variant="outlined"
                helperText="Please enter client id"
                autoComplete="off"
                error={!validclientid}
                onChange={(event) => {
                  setClientid(event.target.value);
                  if (event.target.value !== "") {
                    setValidClientid(true);
                  }
                }}
                value={clientid}
              />
              <TextField
                sx={{
                  maxWidth: 300,
                  mt: 2,
                }}
                size="small"
                label="Secretkey"
                helperText="Please enter secretkey"
                autoComplete="off"
                error={!validsecretkey}
                onChange={(event) => {
                  setSecretkey(event.target.value);
                  if (event.target.value !== "") {
                    setValidSecretkey(true);
                  }
                }}
                value={secretkey}
              ></TextField>
              <TextField
                sx={{ maxWidth: 300, mt: 2 }}
                size="small"
                label="Secretcode"
                variant="outlined"
                helperText="Please enter secretcode"
                autoComplete="off"
                error={!validsecretcode}
                onChange={(event) => {
                  setSecretcode(event.target.value);
                  if (event.target.value !== "") {
                    setValidSecretcode(true);
                  }
                }}
                value={secretcode}
              />
              <TextField
                sx={{
                  maxWidth: 300,
                  mt: 2,
                }}
                size="small"
                label="Authtoken"
                helperText="Please enter authtoken"
                autoComplete="off"
                error={!validauthtoken}
                onChange={(event) => {
                  setAuthtoken(event.target.value);
                  if (event.target.value !== "") {
                    setValidAuthtoken(true);
                  }
                }}
                value={authtoken}
              ></TextField>
              <TextField
                sx={{
                  maxWidth: 300,
                  mt: 2,
                }}
                select
                size="small"
                label="POS"
                helperText="Please enter pos"
                autoComplete="off"
                error={!validpos}
                onChange={(event) => {
                  setPOS(event.target.value);
                  if (event.target.value !== "") {
                    setValidPOS(true);
                  }
                }}
                value={pos}
              >
                <MenuItem value="Clover">Clover</MenuItem>
                <MenuItem value="Square up">Square up</MenuItem>
              </TextField>
            </Stack>
          </DialogContent>
          <DialogActions>
            <Button
              variant="outlined"
              onClick={handleClose}
              color="error"
              sx={{ textTransform: "none" }}
            >
              Cancel
            </Button>
            <Button
              variant="outlined"
              sx={{ textTransform: "none" }}
              autoFocus
              color="success"
              onClick={handlesaveinfo}
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={openAudio}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle
            id="alert-dialog-title"
            sx={{ borderBottom: "1px solid #ced4da" }}
          >
            Upload file
          </DialogTitle>
          <DialogContent>
            <div
              className="d-flex flex-column justify-content-evenly"
              style={{ width: "500px", height: "200px" }}
            >
              <TextField
                sx={{ maxWidth: 300 }}
                size="small"
                label="Restaurant"
                select
                variant="outlined"
                autoComplete="off"
                onChange={(event) => {
                  setRestaurantID(event.target.value);
                }}
                value={restaurantid}
              >
                <MenuItem value="0">--select--</MenuItem>
                {companydll.map((list, i) => (
                  <MenuItem value={list.restaurantid} key={i}>
                    {list.restaurantname}
                  </MenuItem>
                ))}
              </TextField>
              <div className="form-group">
                <label className="form-label">Upload audio file</label>
                <input
                  type="file"
                  className="form-control"
                  name="audiofile"
                  onChange={handleAudio}
                ></input>
              </div>
            </div>
          </DialogContent>
          <DialogActions>
            <Button
              onClick={() => {
                setopenAudio(false);
                setRestaurantID("");
              }}
              color="error"
              sx={{ textTransform: "none" }}
            >
              Cancel
            </Button>
            <Button
              sx={{ textTransform: "none" }}
              autoFocus
              color="success"
              onClick={(event) => {
                saveUploadaudio(event);
              }}
            >
              Save
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={welcomefile}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle
            id="alert-dialog-title"
            sx={{ borderBottom: "1px solid #ced4da" }}
          >
            Upload welcome file
          </DialogTitle>
          <DialogContent>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                marginTop: "1rem",
                width: "500px",
                minHeight: "200px",
                maxHeight: "70%",
              }}
            >
              <TextField
                sx={{ maxWidth: 300 }}
                size="small"
                label="Restaurant"
                select
                variant="outlined"
                disabled
                autoComplete="off"
                onChange={(event) => {
                  setRestaurantID(event.target.value);
                }}
                defaultValue={restaurantid}
                value={restaurantid}
              >
                <MenuItem value="0">--select--</MenuItem>
                {companydll.map((list, i) => (
                  <MenuItem value={list.restaurantid} key={i}>
                    {list.restaurantname}
                  </MenuItem>
                ))}
              </TextField>
              <div className="form-group mt-4 mb-4">
                <label className="form-label">Upload audio</label>
                <input
                  type="file"
                  className="form-control"
                  name="audiofile"
                  onChange={handleAudio}
                ></input>
              </div>
              {listWelcomefile.length > 0 && (
                <div>
                  {listWelcomefile.map((row, i) => (
                    <div key={i}>
                      <label>
                        {i + 1}.&nbsp;
                        {row.audio.includes(".wav")
                          ? row.audio.replace(".wav", "")
                          : row.audio.replace(".mp3", "")}
                      </label>
                      <div className="d-flex justify-content-around align-items-center">
                        <audio controls style={{ width: "80%" }}>
                          <source src={row.audiourl} />
                        </audio>
                        <Tooltip title="Delete" arrow>
                          <DeleteOutlineOutlinedIcon
                            sx={{ cursor: "pointer" }}
                            color="error"
                            onClick={() => {
                              onOpenDeleteModal(row);
                            }}
                          />
                        </Tooltip>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </DialogContent>
          <DialogActions className={listWelcomefile.length > 0 ? "mt-4" : ""}>
            <Button
              sx={{ textTransform: "none" }}
              color="error"
              size="small"
              variant="contained"
              onClick={() => {
                setWelcomefile(false);
                setRestaurantID("");
              }}
            >
              Cancel
            </Button>
            <Button
              sx={{ textTransform: "none" }}
              autoFocus
              size="small"
              color="success"
              variant="contained"
              onClick={(event) => {
                saveWelcomeaudio(event);
              }}
            >
              Save
            </Button>
          </DialogActions>
        </Dialog>

        <Dialog
          open={rejectaudio}
          onClose={() => {
            setRejectaudio(false);
          }}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogContentText sx={{ mt: 1, textAlign: "center" }}>
            <ErrorOutlineOutlinedIcon color="error" sx={{ fontSize: 40 }} />
          </DialogContentText>
          <DialogTitle id="alert-dialog-title">Confirmation</DialogTitle>
          <DialogActions>
            <Button
              onClick={() => {
                setRejectaudio(false);
              }}
              color="error"
              sx={{ textTransform: "none" }}
            >
              Cancel
            </Button>
            <Button
              sx={{ textTransform: "none" }}
              autoFocus
              color="success"
              onClick={(event) => {
                handleDeleteaudio(event);
              }}
            >
              Submit
            </Button>
          </DialogActions>
        </Dialog>
      </div>
      <ToastContainer theme="colored" />
      <Loader loading={openloading} />
    </div>
  );
};
const mapStateToProps = (state) => ({
  state: state,
});
const mapDispatchToProps = (dispatch) => ({
  addCompany: (data) => dispatch(AddCompany(data)),
  loadCompany: (data) => dispatch(LoadCompany(data)),
  loadAgent: (data) => dispatch(LoadAgent(data)),
  addCustomerinfo: (data) => dispatch(AddCustomerinfo(data)),
  loadUploadedaudio: (data) => dispatch(LoadUploadedaudio(data)),
  loadcompanyddl: (data) => dispatch(Loadcompanyddl(data)),
  uploadaudio: (data) => dispatch(Uploadaudio(data)),
  deleteaudio: (data) => dispatch(Deleteaudio(data)),
  welcomeaudio: (data) => dispatch(Welcomeaudio(data)),
  listwelcomeaudio: (data) => dispatch(ListWelcomeaudio(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Home);
