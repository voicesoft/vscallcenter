import React from "react";

const changepassword = () => {
  return <div>changepassword</div>;
};

export default changepassword;
