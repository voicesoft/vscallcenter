export const LOG_IN = "LOG_IN";
export const LOAD_COMPANY = "LOAD_COMPANY";
