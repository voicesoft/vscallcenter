import { LOG_IN, LOAD_COMPANY } from "../types";
import axios from "axios";

let jsonconfig = {
  headers: {
    "Content-Type": "application/json",
  },
};
let jsonformdata = {
  headers: {
    "Content-Type": "multipart/form-data",
  },
};
// const loginUrl = "https://callorder.voicesnap.com/callcenter/api/VSR/";
// const adminUrl = "https://callorder.voicesnap.com/callcenter/api/VSRAdmin/";
// const agentUrl =
//   "https://callorder.voicesnap.com/callcenter/api/AgentmonitorWebAPI/";
// const callStatusUrl = "https://callorder.voicesnap.com/callcenter/api/callstatus/";

// const loginUrl = "https://phoneorder.co/callcenter/api/VSR/";
// const adminUrl = "https://phoneorder.co/callcenter/api/VSRAdmin/";
// const agentUrl = "https://phoneorder.co/callcenter/api/AgentmonitorWebAPI/";
// const callStatusUrl = "https://phoneorder.co/callcenter/api/callstatus/";

const loginUrl = "https://ap.voicehuddle.com/callcenter/api/VSR/";
const adminUrl = "https://ap.voicehuddle.com/callcenter/api/VSRAdmin/";
const agentUrl =
  "https://ap.voicehuddle.com/callcenter/api/AgentmonitorWebAPI/";
const callStatusUrl = "https://ap.voicehuddle.com/callcenter/api/callstatus/";

export const Validatelogin = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "ValidateLogin",
      JSON.stringify(ipval),
      jsonconfig
    );
    dispatch({
      type: LOG_IN,
      payload: response.data,
    });
    return response.data;
  } catch (ex) {}
};
export const AddCompany = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "AddCompany",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const LoadCompany = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "LoadCompany",
      JSON.stringify(ipval),
      jsonconfig
    );
    dispatch({
      type: LOAD_COMPANY,
      payload: response.data,
    });
    return response.data;
  } catch (ex) {}
};
export const AddAgent = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "AddAgent",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const loadagentDDL = (ipval) => async (dispatch) => {
  try {
    const response = await axios.get(
      agentUrl + "Loadagentddl",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};

export const loadlanguageDDL = (ipval) => async (dispatch) => {
  try {
    const response = await axios.get(
      agentUrl + "Loadagentlanguage",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};

export const LoadAgent = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "LoadAgents",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const AddCustomerinfo = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "AddCustomerinfo",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const Loadcompanyddl = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      callStatusUrl + "loadcompanyddl",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const LoadUploadedaudio = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      callStatusUrl + "Loadallaudio",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};

export const Uploadaudio = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      callStatusUrl + "uploadaudio",
      ipval,
      jsonformdata
    );
    return response.data;
  } catch (ex) {}
};

export const Welcomeaudio = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "Welcomeaudio",
      ipval,
      jsonformdata
    );
    return response.data;
  } catch (ex) {}
};

export const ListWelcomeaudio = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "Loadwelcomeaudio",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};

export const Deleteaudio = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "Deletewelcomeaudio",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
