export const LOG_IN = "LOG_IN";
export const ACTIVE_TAB = "ACTIVE_TAB";
export const BANK_INFO = "BANK_INFO";
export const CHEQUE_INFO = "CHEQUE_INFO";
export const PVD = "PVD";
export const FUND_CONF = "FUND_CONF";
export const SUPPLIER_INFO = "SUPPLIER_INFO";
