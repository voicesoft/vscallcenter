const softphone = () => {
  return <div>Soft phone</div>;
};
export default softphone;
