import { useState, forwardRef, useEffect } from "react";
import "../../common/common.css";
import {
  Box,
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Button,
  Stack,
  FormControl,
  Paper,
  TextField,
} from "@mui/material";
import Tooltip from "@mui/material/Tooltip";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";
import HistoryOutlinedIcon from "@mui/icons-material/HistoryOutlined";
import CallIcon from "@mui/icons-material/Call";
import CallEndIcon from "@mui/icons-material/CallEnd";
import CloseIcon from "@mui/icons-material/Close";
import FormControlLabel from "@mui/material/FormControlLabel";
import Checkbox from "@mui/material/Checkbox";
import { ToastContainer, toast } from "react-toastify";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import LockOpenOutlinedIcon from "@mui/icons-material/LockOpenOutlined";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography component={"span"}>{children}</Typography>
        </Box>
      )}
    </div>
  );
}
TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};
function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}
const spanstyle = {
  textDecoration: "underline",
  fontWeight: "bolder",
};
const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  bgcolor: "background.paper",
  border: "2px solid #fff",
  boxShadow: 24,
  pt: 4,
  height: 500,
  width: "100%",
};
const headerstyle = {
  border: "0.05rem solid",
};
const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="down" ref={ref} {...props} />;
});

const Expertsettings = ({ handleClose }) => {
  // var sTransferNumber;
  // var oRingTone, oRingbackTone;
  // var oSipStack1,
  //   oSipSessionRegister1,
  //   oSipSessionCall1 = null,
  //   oSipSessionTransferCall1;
  // var oConfigCall1;
  // const [oSipStack, setoSipStack] = useState(null);
  // const [oSipSessionRegister, setoSipSessionRegister] = useState(null);
  // const [oSipSessionCall, setoSipSessionCall] = useState(null);
  // const [oSipSessionTransferCall, setoSipSessionTransferCall] = useState(null);
  // const [oConfigCall, setoConfigCall] = useState(null);
  // var videoRemote, videoLocal, audioRemote;
  // var bFullScreen = false;
  // var oNotifICall;
  // var bDisableVideo = false;
  // var viewVideoLocal, viewVideoRemote, viewLocalScreencast; // <video> (webrtc) or <div> (webrtc4all)

  // var oReadyStateTimer;

  // var C = {
  //   divKeyPadWidth: 220,
  // };
  useEffect(() => {
    window.console &&
      window.console.info &&
      window.console.info("location=" + window.location);

    videoLocal = document.getElementById("video_local");
    videoRemote = document.getElementById("video_remote");
    audioRemote = document.getElementById("audio_remote");

    document.onkeyup = onkeyup;
    document.body.onkeyup = onkeyup;
    // divCallCtrl.onmousemove = onDivCallCtrlMouseMove;

    // set debug level
    SIPml.setDebugLevel(
      window.localStorage &&
        window.localStorage.getItem("org.doubango.expert.disable_debug") ==
          "true"
        ? "error"
        : "info"
    );

    loadCredentials();
    loadCallOptions();

    // Initialize call button
    uiBtnCallSetText("Call");

    var getPVal = function (PName) {
      var query = window.location.search.substring(1);
      var vars = query.split("&");
      for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (decodeURIComponent(pair[0]) === PName) {
          return decodeURIComponent(pair[1]);
        }
      }
      return null;
    };

    var preInit = function () {
      // set default webrtc type (before initialization)
      var s_webrtc_type = getPVal("wt");
      var s_fps = getPVal("fps");
      var s_mvs = getPVal("mvs"); // maxVideoSize
      var s_mbwu = getPVal("mbwu"); // maxBandwidthUp (kbps)
      var s_mbwd = getPVal("mbwd"); // maxBandwidthUp (kbps)
      var s_za = getPVal("za"); // ZeroArtifacts
      var s_ndb = getPVal("ndb"); // NativeDebug

      if (s_webrtc_type) SIPml.setWebRtcType(s_webrtc_type);

      // initialize SIPML5
      SIPml.init(postInit);

      // set other options after initialization
      if (s_fps) SIPml.setFps(parseFloat(s_fps));
      if (s_mvs) SIPml.setMaxVideoSize(s_mvs);
      if (s_mbwu) SIPml.setMaxBandwidthUp(parseFloat(s_mbwu));
      if (s_mbwd) SIPml.setMaxBandwidthDown(parseFloat(s_mbwd));
      if (s_za) SIPml.setZeroArtifacts(s_za === "true");
      if (s_ndb == "true") SIPml.startNativeDebug();

      //var rinningApps = SIPml.getRunningApps();
      //var _rinningApps = Base64.decode(rinningApps);
      //tsk_utils_log_info(_rinningApps);
    };

    oReadyStateTimer = setInterval(function () {
      if (document.readyState === "complete") {
        clearInterval(oReadyStateTimer);
        // initialize SIPML5
        preInit();
      }
    }, 500);

    /*if (document.readyState === "complete") {
      preInit();
  }
  else {
      document.onreadystatechange = function () {
           if (document.readyState === "complete") {
              preInit();
          }
      }
 }*/
  }, []);
  const temphandleClose = () => {
    handleClose();
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const settingsSave = () => {
    window.localStorage.setItem(
      "org.doubango.expert.disable_video",
      disablevideo ? "true" : "false"
    );
    window.localStorage.setItem(
      "org.doubango.expert.enable_rtcweb_breaker",
      enablertcweb ? "true" : "false"
    );
    // if (!txtWebsocketServerUrl.disabled) {
    window.localStorage.setItem(
      "org.doubango.expert.websocket_server_url",
      serverurl
    );
    // }
    window.localStorage.setItem(
      "org.doubango.expert.sip_outboundproxy_url",
      proxyurl
    );
    window.localStorage.setItem("org.doubango.expert.ice_servers", iceservers);
    window.localStorage.setItem("org.doubango.expert.bandwidth", bandwidth);
    window.localStorage.setItem("org.doubango.expert.video_size", videosize);
    window.localStorage.setItem(
      "org.doubango.expert.disable_early_ims",
      earlyims ? "true" : "false"
    );
    window.localStorage.setItem(
      "org.doubango.expert.disable_debug",
      debugmessages ? "true" : "false"
    );
    window.localStorage.setItem(
      "org.doubango.expert.enable_media_caching",
      mediastream ? "true" : "false"
    );
    window.localStorage.setItem(
      "org.doubango.expert.disable_callbtn_options",
      disablebuttonoption ? "true" : "false"
    );

    // txtInfo.innerHTML = "<i>Saved</i>";
  };
  const settingsRevert = (bNotUserAction) => {
    
    setDisablevideo(
      window.localStorage.getItem("org.doubango.expert.disable_video") === true
    );
    setEnablertcweb(
      window.localStorage.getItem(
        "org.doubango.expert.enable_rtcweb_breaker"
      ) === true
    );
    setServerurl(
      window.localStorage.getItem("org.doubango.expert.websocket_server_url") ||
        ""
    );
    setProxyurl(
      window.localStorage.getItem(
        "org.doubango.expert.sip_outboundproxy_url"
      ) || ""
    );
    setIceservers(
      window.localStorage.getItem("org.doubango.expert.ice_servers") || ""
    );
    setBandwidth(
      window.localStorage.getItem("org.doubango.expert.bandwidth") || ""
    );
    setVideosize(
      window.localStorage.getItem("org.doubango.expert.video_size") || ""
    );
    setEarlyims(
      window.localStorage.getItem("org.doubango.expert.disable_early_ims") ==
        true
    );
    setDebugmessages(
      window.localStorage.getItem("org.doubango.expert.disable_debug") == true
    );
    setMediastream(
      window.localStorage.getItem("org.doubango.expert.enable_media_caching") ==
        true
    );
    setDisablebuttonoption(
      window.localStorage.getItem(
        "org.doubango.expert.disable_callbtn_options"
      ) == true
    );
    if (!bNotUserAction) {
      toast.error("Reverted", {
        autoClose: 2000,
      });
      // txtInfo.innerHTML = "<i>Reverted</i>";
    }
  };
  function saveCredentials() {
    if (window.localStorage) {
      window.localStorage.setItem(
        "org.doubango.identity.display_name",
        displayname
      );
      window.localStorage.setItem(
        "org.doubango.identity.impi",
        privateidentity
      );
      window.localStorage.setItem("org.doubango.identity.impu", publicidentity);
      window.localStorage.setItem("org.doubango.identity.password", password);
      window.localStorage.setItem("org.doubango.identity.realm", realm);
    }
  }
  const [btnvalue, setBtnvalue] = useState("Login");
  const [value, setValue] = useState(0);
  const [disablevideo, setDisablevideo] = useState(false);
  const [enablertcweb, setEnablertcweb] = useState(false);
  const [serverurl, setServerurl] = useState("");
  const [proxyurl, setProxyurl] = useState("");
  const [iceservers, setIceservers] = useState("");
  const [bandwidth, setBandwidth] = useState("");
  const [videosize, setVideosize] = useState("");
  const [earlyims, setEarlyims] = useState(false);
  const [debugmessages, setDebugmessages] = useState(false);
  const [mediastream, setMediastream] = useState(false);
  const [disablebuttonoption, setDisablebuttonoption] = useState(false);
  const [displayname, setDisplayname] = useState("");
  const [privateidentity, setPrivateidentity] = useState("");
  const [publicidentity, setPublicidentity] = useState("");
  const [password, setPassword] = useState("");
  const [realm, setRealm] = useState("");
  const [callbtndisabled, setCallbtndisabled] = useState(false);
  const [disconbtndisabled, setDisconbtndisabled] = useState(false);
  const [btnmakecallvalue, setBtnmakecallvalue] = useState("Call");
  const [btnmakecalldisabled, setBtnmakecalldisabled] = useState(false);
  const [btnhangupvalue, setHangupvalue] = useState("Hangup");
  const [btnhangupdisabled, setHangupdisabled] = useState(false);
  const [mobilenumber, setMobilenumber] = useState("");

  function postInit() {
    // check for WebRTC support
    if (!SIPml.isWebRtcSupported()) {
      // is it chrome?
      if (SIPml.getNavigatorFriendlyName() == "chrome") {
        if (
          confirm(
            "You're using an old Chrome version or WebRTC is not enabled.\nDo you want to see how to enable WebRTC?"
          )
        ) {
          window.location = "http://www.webrtc.org/running-the-demos";
        } else {
          window.location = "index.html";
        }
        return;
      } else {
        if (
          confirm(
            "webrtc-everywhere extension is not installed. Do you want to install it?\nIMPORTANT: You must restart your browser after the installation."
          )
        ) {
          window.location = "https://github.com/sarandogou/webrtc-everywhere";
        } else {
          // Must do nothing: give the user the chance to accept the extension
          // window.location = "index.html";
        }
      }
    }

    // checks for WebSocket support
    if (!SIPml.isWebSocketSupported()) {
      if (
        confirm(
          "Your browser don't support WebSockets.\nDo you want to download a WebSocket-capable browser?"
        )
      ) {
        window.location = "https://www.google.com/intl/en/chrome/browser/";
      } else {
        window.location = "index.html";
      }
      return;
    }

    // FIXME: displays must be per session
    viewVideoLocal = videoLocal;
    viewVideoRemote = videoRemote;

    if (!SIPml.isWebRtcSupported()) {
      if (
        confirm(
          "Your browser don't support WebRTC.\naudio/video calls will be disabled.\nDo you want to download a WebRTC-capable browser?"
        )
      ) {
        window.location = "https://www.google.com/intl/en/chrome/browser/";
      }
    }

    // btnRegister.disabled = false;
    setCallbtndisabled(false);
    document.body.style.cursor = "default";
    oConfigCall1 = {
      audio_remote: audioRemote,
      video_local: viewVideoLocal,
      video_remote: viewVideoRemote,
      screencast_window_id: 0x00000000, // entire desktop
      bandwidth: { audio: undefined, video: undefined },
      video_size: {
        minWidth: undefined,
        minHeight: undefined,
        maxWidth: undefined,
        maxHeight: undefined,
      },
      events_listener: { events: "*", listener: onSipEventSession },
      sip_caps: [
        { name: "+g.oma.sip-im" },
        { name: "language", value: '"en,fr"' },
      ],
    };
    setoConfigCall(oConfigCall1);
  }

  function loadCallOptions() {
    if (window.localStorage) {
      var s_value;
      if (
        (s_value = window.localStorage.getItem(
          "org.doubango.call.phone_number"
        ))
      )
        setMobilenumber(s_value);
      bDisableVideo =
        window.localStorage.getItem("org.doubango.expert.disable_video") ==
        "true";
      toast.error("Video " + (bDisableVideo ? "disabled" : "enabled"), {
        autoClose: 2000,
      });
      // txtCallStatus.innerHTML =
      //   "<i>Video " + (bDisableVideo ? "disabled" : "enabled") + "</i>";
    }
  }

  function saveCallOptions() {
    if (window.localStorage) {
      window.localStorage.setItem(
        "org.doubango.call.phone_number",
        mobilenumber
      );
      window.localStorage.setItem(
        "org.doubango.expert.disable_video",
        bDisableVideo ? "true" : "false"
      );
    }
  }

  function loadCredentials() {
    if (window.localStorage) {
      // IE retuns 'null' if not defined
      var s_value;
      if (
        (s_value = window.localStorage.getItem(
          "org.doubango.identity.display_name"
        ))
      )
        setDisplayname(s_value);
      if ((s_value = window.localStorage.getItem("org.doubango.identity.impi")))
        setPrivateidentity(s_value);
      if ((s_value = window.localStorage.getItem("org.doubango.identity.impu")))
        setPublicidentity(s_value);
      if (
        (s_value = window.localStorage.getItem(
          "org.doubango.identity.password"
        ))
      )
        setPassword(s_value);
      if (
        (s_value = window.localStorage.getItem("org.doubango.identity.realm"))
      )
        setRealm(s_value);
    } else {
      //txtDisplayName.value = "005";
      //txtPrivateIdentity.value = "005";
      //txtPublicIdentity.value = "sip:005@sip2sip.info";
      //txtPassword.value = "005";
      //txtRealm.value = "sip2sip.info";
      //txtPhoneNumber.value = "701020";
    }
  }

  // sends SIP REGISTER request to login
  function sipRegister() {
    // catch exception for IE (DOM not ready)
    try {
      // btnRegister.disabled = true;
      setCallbtndisabled(true);
      if (!realm || !privateidentity || !publicidentity) {
        // txtRegStatus.innerHTML = "<b>Please fill madatory fields (*)</b>";
        toast.error("Please fill madatory fields (*)", {
          autoClose: 2000,
        });
        // btnRegister.disabled = false;
        setCallbtndisabled(false);
        return;
      }
      var o_impu = tsip_uri.prototype.Parse(publicidentity);
      if (!o_impu || !o_impu.s_user_name || !o_impu.s_host) {
        // txtRegStatus.innerHTML =
        //   "<b>[" +
        //   txtPublicIdentity.value +
        //   "] is not a valid Public identity</b>";
        toast.error("" + publicidentity + " is not a valid Public identity", {
          autoClose: 2000,
        });
        // btnRegister.disabled = false;
        setCallbtndisabled(false);
        return;
      }

      // enable notifications if not already done
      if (
        window.webkitNotifications &&
        window.webkitNotifications.checkPermission() != 0
      ) {
        window.webkitNotifications.requestPermission();
      }

      // save credentials
      saveCredentials();

      // update debug level to be sure new values will be used if the user haven't updated the page
      SIPml.setDebugLevel(
        window.localStorage &&
          window.localStorage.getItem("org.doubango.expert.disable_debug") ==
            "true"
          ? "error"
          : "info"
      );

      // create SIP stack
      //15-09-2022
      oSipStack1 = new SIPml.Stack({
        realm: realm,
        impi: privateidentity,
        impu: publicidentity,
        password: password,
        display_name: displayname,
        websocket_proxy_url: window.localStorage
          ? window.localStorage.getItem(
              "org.doubango.expert.websocket_server_url"
            )
          : null,
        outbound_proxy_url: window.localStorage
          ? window.localStorage.getItem(
              "org.doubango.expert.sip_outboundproxy_url"
            )
          : null,
        ice_servers: window.localStorage
          ? window.localStorage.getItem("org.doubango.expert.ice_servers")
          : null,
        enable_rtcweb_breaker: window.localStorage
          ? window.localStorage.getItem(
              "org.doubango.expert.enable_rtcweb_breaker"
            ) == "true"
          : false,
        events_listener: { events: "*", listener: onSipEventStack },
        enable_early_ims: window.localStorage
          ? window.localStorage.getItem(
              "org.doubango.expert.disable_early_ims"
            ) != "true"
          : true, // Must be true unless you're using a real IMS network
        enable_media_stream_cache: window.localStorage
          ? window.localStorage.getItem(
              "org.doubango.expert.enable_media_caching"
            ) == "true"
          : false,
        bandwidth: window.localStorage
          ? tsk_string_to_object(
              window.localStorage.getItem("org.doubango.expert.bandwidth")
            )
          : null, // could be redefined a session-level
        video_size: window.localStorage
          ? tsk_string_to_object(
              window.localStorage.getItem("org.doubango.expert.video_size")
            )
          : null, // could be redefined a session-level
        sip_headers: [
          {
            name: "User-Agent",
            value: "IM-client/OMA1.0 sipML5-v1.2016.03.04",
          },
          { name: "Organization", value: "Doubango Telecom" },
        ],
      });
      setoSipStack(oSipStack1);
      if (oSipStack1.start() != 0) {
        // txtRegStatus.innerHTML = "<b>Failed to start the SIP stack</b>";
        toast.error("Failed to start the SIP stack", {
          autoClose: 2000,
        });
      } else return;
    } catch (e) {
      // txtRegStatus.innerHTML = "<b>2:" + e + "</b>";
      toast.error("2:" + e + "", {
        autoClose: 2000,
      });
    }
    // btnRegister.disabled = false;
    setCallbtndisabled(false);
  }

  // sends SIP REGISTER (expires=0) to logout
  function sipUnRegister() {
    if (oSipStack) {
      oSipStack.stop(); // shutdown all sessions
    }
  }

  // makes a call (SIP INVITE)
  function sipCall(s_type) {
    if (
      oSipStack &&
      !oSipSessionCall &&
      !tsk_string_is_null_or_empty(mobilenumber)
    ) {
      if (s_type == "call-screenshare") {
        if (!SIPml.isScreenShareSupported()) {
          alert("Screen sharing not supported. Are you using chrome 26+?");
          return;
        }
        if (!location.protocol.match("https")) {
          if (
            confirm(
              "Screen sharing requires https://. Do you want to be redirected?"
            )
          ) {
            sipUnRegister();
            window.location = "https://ns313841.ovh.net/call.htm";
          }
          return;
        }
      }
      setBtnmakecalldisabled(true);
      setHangupdisabled(false);
      // btnCall.disabled = true;
      // btnHangUp.disabled = false;

      if (window.localStorage) {
        oConfigCall.bandwidth = tsk_string_to_object(
          window.localStorage.getItem("org.doubango.expert.bandwidth")
        ); // already defined at stack-level but redifined to use latest values
        oConfigCall.video_size = tsk_string_to_object(
          window.localStorage.getItem("org.doubango.expert.video_size")
        ); // already defined at stack-level but redifined to use latest values
      }

      // create call session
      oSipSessionCall1 = oSipStack.newSession(s_type, oConfigCall);
      setoSipSessionCall(oSipSessionCall1);
      // make call
      if (oSipSessionCall1.call(mobilenumber) != 0) {
        oSipSessionCall1 = null;
        //  txtCallStatus.value = "Failed to make call";
        toast.error("Failed to make call", {
          autoClose: 2000,
        });
        setBtnmakecalldisabled(false);
        setHangupdisabled(true);
        // btnCall.disabled = false;
        // btnHangUp.disabled = true;
        return;
      }
      saveCallOptions();
    } else if (oSipSessionCall) {
      // txtCallStatus.innerHTML = "<i>Connecting...</i>";
      toast.success("Connecting...", {
        autoClose: 2000,
      });
      oSipSessionCall.accept(oConfigCall);
    }
  }

  // Share entire desktop aor application using BFCP or WebRTC native implementation
  function sipShareScreen() {
    if (SIPml.getWebRtcType() === "w4a") {
      // Sharing using BFCP -> requires an active session
      if (!oSipSessionCall) {
        // txtCallStatus.innerHTML = "<i>No active session</i>";
        toast.error("No active session", {
          autoClose: 2000,
        });
        return;
      }
      if (oSipSessionCall.bfcpSharing) {
        if (oSipSessionCall.stopBfcpShare(oConfigCall) != 0) {
          // txtCallStatus.value = "Failed to stop BFCP share";
          toast.error("Failed to stop BFCP share", {
            autoClose: 2000,
          });
        } else {
          oSipSessionCall.bfcpSharing = false;
        }
      } else {
        oConfigCall.screencast_window_id = 0x00000000;
        if (oSipSessionCall.startBfcpShare(oConfigCall) != 0) {
          // txtCallStatus.value = "Failed to start BFCP share";
          toast.error("Failed to start BFCP share", {
            autoClose: 2000,
          });
        } else {
          oSipSessionCall.bfcpSharing = true;
        }
      }
    } else {
      sipCall("call-screenshare");
    }
  }

  // transfers the call
  function sipTransfer() {
    if (oSipSessionCall) {
      var s_destination = prompt("Enter destination number", "");
      if (!tsk_string_is_null_or_empty(s_destination)) {
        btnTransfer.disabled = true;
        if (oSipSessionCall.transfer(s_destination) != 0) {
          // txtCallStatus.innerHTML = "<i>Call transfer failed</i>";
          toast.error("Call transfer failed", {
            autoClose: 2000,
          });
          btnTransfer.disabled = false;
          return;
        }
        // txtCallStatus.innerHTML = "<i>Transfering the call...</i>";
        toast.success("Transfering the call...", {
          autoClose: 2000,
        });
      }
    }
  }

  // holds or resumes the call
  function sipToggleHoldResume() {
    if (oSipSessionCall) {
      var i_ret;
      btnHoldResume.disabled = true;
      // txtCallStatus.innerHTML = oSipSessionCall.bHeld
      //   ? "<i>Resuming the call...</i>"
      //   : "<i>Holding the call...</i>";
      toast.success(
        oSipSessionCall.bHeld ? "Resuming the call..." : "Holding the call...",
        {
          autoClose: 2000,
        }
      );
      i_ret = oSipSessionCall.bHeld
        ? oSipSessionCall.resume()
        : oSipSessionCall.hold();
      if (i_ret != 0) {
        // txtCallStatus.innerHTML = "<i>Hold / Resume failed</i>";
        toast.error("Hold / Resume failed", {
          autoClose: 2000,
        });
        btnHoldResume.disabled = false;
        return;
      }
    }
  }

  // Mute or Unmute the call
  function sipToggleMute() {
    if (oSipSessionCall) {
      var i_ret;
      var bMute = !oSipSessionCall.bMute;
      // txtCallStatus.innerHTML = bMute
      //   ? "<i>Mute the call...</i>"
      //   : "<i>Unmute the call...</i>";
      toast.success(bMute ? "Mute the call..." : "Unmute the call...", {
        autoClose: 2000,
      });
      i_ret = oSipSessionCall.mute("audio" /*could be 'video'*/, bMute);
      if (i_ret != 0) {
        // txtCallStatus.innerHTML = "<i>Mute / Unmute failed</i>";
        toast.error("Mute / Unmute failed", {
          autoClose: 2000,
        });
        return;
      }
      oSipSessionCall.bMute = bMute;
      btnMute.value = bMute ? "Unmute" : "Mute";
    }
  }

  // terminates the call (SIP BYE or CANCEL)
  function sipHangUp() {
    if (oSipSessionCall) {
      // txtCallStatus.innerHTML = "<i>Terminating the call...</i>";
      toast.error("Terminating the call...", {
        autoClose: 2000,
      });
      oSipSessionCall.hangup({
        events_listener: { events: "*", listener: onSipEventSession },
      });
      window.localStorage.setItem("incommingDID", 0);
    }
  }

  function sipSendDTMF(c) {
    if (oSipSessionCall && c) {
      if (oSipSessionCall.dtmf(c) == 0) {
        try {
          dtmfTone.play();
        } catch (e) {}
      }
    }
  }

  function startRingTone() {
    try {
      ringtone.play();
    } catch (e) {}
  }

  function stopRingTone() {
    try {
      ringtone.pause();
    } catch (e) {}
  }

  function startRingbackTone() {
    try {
      ringbacktone.play();
    } catch (e) {}
  }

  function stopRingbackTone() {
    try {
      ringbacktone.pause();
    } catch (e) {}
  }

  function toggleFullScreen() {
    if (videoRemote.webkitSupportsFullscreen) {
      fullScreen(!videoRemote.webkitDisplayingFullscreen);
    } else {
      fullScreen(!bFullScreen);
    }
  }

  function openKeyPad() {
    divKeyPad.style.visibility = "visible";
    divKeyPad.style.left =
      ((document.body.clientWidth - C.divKeyPadWidth) >> 1) + "px";
    divKeyPad.style.top = "70px";
    divGlassPanel.style.visibility = "visible";
  }

  function closeKeyPad() {
    divKeyPad.style.left = "0px";
    divKeyPad.style.top = "0px";
    divKeyPad.style.visibility = "hidden";
    divGlassPanel.style.visibility = "hidden";
  }

  function fullScreen(b_fs) {
    bFullScreen = b_fs;
    if (
      tsk_utils_have_webrtc4native() &&
      bFullScreen &&
      videoRemote.webkitSupportsFullscreen
    ) {
      if (bFullScreen) {
        videoRemote.webkitEnterFullScreen();
      } else {
        videoRemote.webkitExitFullscreen();
      }
    } else {
      if (tsk_utils_have_webrtc4npapi()) {
        try {
          if (window.__o_display_remote)
            window.__o_display_remote.setFullScreen(b_fs);
        } catch (e) {
          divVideo.setAttribute(
            "class",
            b_fs ? "full-screen" : "normal-screen"
          );
        }
      } else {
        divVideo.setAttribute("class", b_fs ? "full-screen" : "normal-screen");
      }
    }
  }

  function showNotifICall(s_number) {
    // permission already asked when we registered
    if (
      window.webkitNotifications &&
      window.webkitNotifications.checkPermission() == 0
    ) {
      if (oNotifICall) {
        oNotifICall.cancel();
      }
      oNotifICall = window.webkitNotifications.createNotification(
        "images/sipml-34x39.png",
        "Incaming call",
        "Incoming call from " + s_number
      );
      oNotifICall.onclose = function () {
        oNotifICall = null;
      };
      oNotifICall.show();
    }
  }

  function onKeyUp(evt) {
    evt = evt || window.event;
    if (evt.keyCode == 27) {
      fullScreen(false);
    } else if (evt.ctrlKey && evt.shiftKey) {
      // CTRL + SHIFT
      if (evt.keyCode == 65 || evt.keyCode == 86) {
        // A (65) or V (86)
        bDisableVideo = evt.keyCode == 65;
        // txtCallStatus.innerHTML =
        //   "<i>Video " + (bDisableVideo ? "disabled" : "enabled") + "</i>";
        toast.success("Video " + (bDisableVideo ? "disabled" : "enabled"), {
          autoClose: 2000,
        });
        window.localStorage.setItem(
          "org.doubango.expert.disable_video",
          bDisableVideo
        );
      }
    }
  }

  function onDivCallCtrlMouseMove(evt) {
    try {
      // IE: DOM not ready
      if (tsk_utils_have_stream()) {
        // btnCall.disabled = (!tsk_utils_have_stream() || !oSipSessionRegister || !oSipSessionRegister.is_connected());
        setBtnmakecalldisabled(
          !tsk_utils_have_stream() ||
            !oSipSessionRegister ||
            !oSipSessionRegister.is_connected()
        );

        document.getElementById("divCallCtrl").onmousemove = null; // unsubscribe
      }
    } catch (e) {}
  }

  function uiOnConnectionEvent(b_connected, b_connecting) {
    setCallbtndisabled(b_connected || b_connecting);
    setDisconbtndisabled(!b_connected && !b_connecting);
    setBtnmakecalldisabled(
      !(b_connected && tsk_utils_have_webrtc() && tsk_utils_have_stream())
    );
    setHangupdisabled(!oSipSessionCall);
    // btnRegister.disabled = b_connected || b_connecting;
    // btnUnRegister.disabled = !b_connected && !b_connecting;
    // btnCall.disabled = !(
    //   b_connected &&
    //   tsk_utils_have_webrtc() &&
    //   tsk_utils_have_stream()
    // );
    // btnHangUp.disabled = !oSipSessionCall;
  }

  function uiVideoDisplayEvent(b_local, b_added) {
    var o_elt_video = b_local ? videoLocal : videoRemote;

    if (b_added) {
      o_elt_video.style.opacity = 1;
      uiVideoDisplayShowHide(true);
    } else {
      o_elt_video.style.opacity = 0;
      fullScreen(false);
    }
  }

  function uiVideoDisplayShowHide(b_show) {
    if (b_show) {
      tdVideo.style.height = "340px";
      divVideo.style.height =
        navigator.appName == "Microsoft Internet Explorer" ? "100%" : "340px";
    } else {
      tdVideo.style.height = "0px";
      divVideo.style.height = "0px";
    }
    btnFullScreen.disabled = !b_show;
  }

  function uiDisableCallOptions() {
    if (window.localStorage) {
      window.localStorage.setItem(
        "org.doubango.expert.disable_callbtn_options",
        "true"
      );
      uiBtnCallSetText("Call");
      alert(
        "Use expert view to enable the options again (/!\\requires re-loading the page)"
      );
    }
  }

  function uiBtnCallSetText(s_text) {
    switch (s_text) {
      case "Call": {
        var bDisableCallBtnOptions =
          window.localStorage &&
          window.localStorage.getItem(
            "org.doubango.expert.disable_callbtn_options"
          ) == "true";
        setBtnmakecallvalue(bDisableCallBtnOptions ? "Call" : "Call 1");
        // btnCall.value = btnCall.innerHTML = bDisableCallBtnOptions
        //   ? "Call"
        //   : 'Call <span id="spanCaret" class="caret">';

        // btnCall.setAttribute(
        //   "class",
        //   bDisableCallBtnOptions
        //     ? "btn btn-primary"
        //     : "btn btn-primary dropdown-toggle"
        // );
        // btnCall.onclick = bDisableCallBtnOptions
        //   ? function () {
        //       sipCall(bDisableVideo ? "call-audio" : "call-audiovideo");
        //     }
        //   : null;
        /*   ulCallOptions.style.visibility = bDisableCallBtnOptions
          ? "hidden"
          : "visible";
        if (
          !bDisableCallBtnOptions &&
          ulCallOptions.parentNode != divBtnCallGroup
        ) {
          divBtnCallGroup.appendChild(ulCallOptions);
        } else if (
          bDisableCallBtnOptions &&
          ulCallOptions.parentNode == divBtnCallGroup
        ) {
          document.body.appendChild(ulCallOptions);
        }
*/
        break;
      }
      default: {
        setBtnmakecallvalue(s_text);
        //btnCall.value = btnCall.innerHTML = s_text;
        //btnCall.setAttribute("class", "btn btn-primary");
        //btnCall.onclick = function () {
        //  sipCall(bDisableVideo ? "call-audio" : "call-audiovideo");
        //};
        /*ulCallOptions.style.visibility = "hidden";
        if (ulCallOptions.parentNode == divBtnCallGroup) {
          document.body.appendChild(ulCallOptions);
        }*/
        break;
      }
    }
  }

  function uiCallTerminated(s_description) {
    uiBtnCallSetText("Call");
    setHangupvalue("HangUp");
    setBtnmakecalldisabled(false);
    setHangupdisabled(true);
    // btnHangUp.value = "HangUp";
    // btnHoldResume.value = "hold";
    // btnMute.value = "Mute";
    // btnCall.disabled = false;
    // btnHangUp.disabled = true;
    if (window.btnBFCP) window.btnBFCP.disabled = true;

    setoSipSessionCall(null);

    stopRingbackTone();
    stopRingTone();

    // txtCallStatus.innerHTML = "<i>" + s_description + "</i>";
    toast.success(s_description, {
      autoClose: 2000,
    });
    uiVideoDisplayShowHide(false);
    divCallOptions.style.opacity = 0;

    if (oNotifICall) {
      oNotifICall.cancel();
      oNotifICall = null;
    }

    uiVideoDisplayEvent(false, false);
    uiVideoDisplayEvent(true, false);

    setTimeout(function () {
      if (!oSipSessionCall) {
        //txtCallStatus.innerHTML = "";
      }
    }, 2500);
  }

  // Callback function for SIP Stacks
  function onSipEventStack(e /*SIPml.Stack.Event*/) {
    tsk_utils_log_info("==stack event = " + e.type);
    switch (e.type) {
      case "started": {
        // catch exception for IE (DOM not ready)
        try {
          // LogIn (REGISTER) as soon as the stack finish starting
          oSipSessionRegister1 = this.newSession("register", {
            expires: 200,
            events_listener: { events: "*", listener: onSipEventSession },
            sip_caps: [
              { name: "+g.oma.sip-im", value: null },
              //{ name: '+sip.ice' }, // rfc5768: FIXME doesn't work with Polycom TelePresence
              { name: "+audio", value: null },
              { name: "language", value: '"en,fr"' },
            ],
          });
          oSipSessionRegister1.register();
          setoSipSessionRegister(oSipSessionRegister1);
        } catch (e) {
          // txtRegStatus.value = txtRegStatus.innerHTML = "<b>1:" + e + "</b>";
          toast.error("1:" + e + "", {
            autoClose: 2000,
          });
          setCallbtndisabled(false);
          // btnRegister.disabled = false;
        }
        break;
      }
      case "stopping":
      case "stopped":
      case "failed_to_start":
      case "failed_to_stop": {
        var bFailure =
          e.type == "failed_to_start" || e.type == "failed_to_stop";
        setoSipStack(null);
        setoSipSessionRegister(null);
        setoSipSessionCall(null);

        uiOnConnectionEvent(false, false);

        stopRingbackTone();
        stopRingTone();

        uiVideoDisplayShowHide(false);
        divCallOptions.style.opacity = 0;

        // txtCallStatus.innerHTML = "";
        // txtRegStatus.innerHTML = bFailure
        //   ? "<i>Disconnected: <b>" + e.description + "</b></i>"
        //   : "<i>Disconnected</i>";
        toast.error(
          bFailure ? "Disconnected: " + e.description + "" : "Disconnected",
          {
            autoClose: 2000,
          }
        );
        break;
      }

      case "i_new_call": {
        if (oSipSessionCall) {
          // do not accept the incoming call if we're already 'in call'
          e.newSession.hangup(); // comment this line for multi-line support
        } else {
          oSipSessionCall1 = e.newSession;
          // start listening for events
          oSipSessionCall1.setConfiguration(oConfigCall);
          setoSipSessionCall(oSipSessionCall1);

          uiBtnCallSetText("Answer");
          setHangupvalue("Reject");
          setBtnmakecalldisabled(false);
          setHangupdisabled(false);
          // btnHangUp.value = "Reject";
          // btnCall.disabled = false;
          // btnHangUp.disabled = false;

          startRingTone();
          
          var sRemoteNumber =
            oSipSessionCall1.getRemoteFriendlyName() || "unknown";
          // txtCallStatus.innerHTML =
          //   "<i>Incoming call from [<b>" + sRemoteNumber + "</b>]</i>";
          toast.success("Incoming call from [" + sRemoteNumber + "]", {
            autoClose: 2000,
          });
          showNotifICall(sRemoteNumber);
        }
        break;
      }

      case "m_permission_requested": {
        divGlassPanel.style.visibility = "visible";
        break;
      }
      case "m_permission_accepted":
      case "m_permission_refused": {
        divGlassPanel.style.visibility = "hidden";
        if (e.type == "m_permission_refused") {
          uiCallTerminated("Media stream permission denied");
        }
        break;
      }

      case "starting":
      default:
        break;
    }
  }

  // Callback function for SIP sessions (INVITE, REGISTER, MESSAGE...)
  function onSipEventSession(e /* SIPml.Session.Event */) {
    tsk_utils_log_info("==session event = " + e.type);
    
    switch (e.type) {
      case "connecting":
      case "connected": {
        var bConnected = e.type == "connected";
        if (e.session == (oSipSessionRegister || oSipSessionRegister1)) {
          uiOnConnectionEvent(bConnected, !bConnected);
          // txtRegStatus.innerHTML = "<i>" + e.description + "</i>";
          toast.error(e.description, {
            autoClose: 2000,
          });
        } else if (e.session == (oSipSessionCall || oSipSessionCall1)) {
          btnHangUp.value = "HangUp";
          setBtnmakecalldisabled(true);
          setHangupdisabled(false);
          // btnCall.disabled = true;
          // btnHangUp.disabled = false;
          btnTransfer.disabled = false;
          if (window.btnBFCP) window.btnBFCP.disabled = false;

          if (bConnected) {
            stopRingbackTone();
            stopRingTone();

            if (oNotifICall) {
              oNotifICall.cancel();
              oNotifICall = null;
            }
          }

          // txtCallStatus.innerHTML = "<i>" + e.description + "</i>";
          toast.success(e.description, {
            autoClose: 2000,
          });
          divCallOptions.style.opacity = bConnected ? 1 : 0;

          if (SIPml.isWebRtc4AllSupported()) {
            // IE don't provide stream callback
            uiVideoDisplayEvent(false, true);
            uiVideoDisplayEvent(true, true);
          }
        }
        break;
      } // 'connecting' | 'connected'
      case "terminating":
      case "terminated": {
        if (e.session == oSipSessionRegister) {
          uiOnConnectionEvent(false, false);

          setoSipSessionCall(null);
          setoSipSessionRegister(null);

          // txtRegStatus.innerHTML = "<i>" + e.description + "</i>";
          toast.error(e.description, {
            autoClose: 2000,
          });
        } else if (e.session == oSipSessionCall) {
          uiCallTerminated(e.description);
        }
        break;
      } // 'terminating' | 'terminated'

      case "m_stream_video_local_added": {
        if (e.session == oSipSessionCall) {
          uiVideoDisplayEvent(true, true);
        }
        break;
      }
      case "m_stream_video_local_removed": {
        if (e.session == oSipSessionCall) {
          uiVideoDisplayEvent(true, false);
        }
        break;
      }
      case "m_stream_video_remote_added": {
        if (e.session == oSipSessionCall) {
          uiVideoDisplayEvent(false, true);
        }
        break;
      }
      case "m_stream_video_remote_removed": {
        if (e.session == oSipSessionCall) {
          uiVideoDisplayEvent(false, false);
        }
        break;
      }

      case "m_stream_audio_local_added":
      case "m_stream_audio_local_removed":
      case "m_stream_audio_remote_added":
      case "m_stream_audio_remote_removed": {
        break;
      }

      case "i_ect_new_call": {
        setoSipSessionTransferCall(e.session);
        break;
      }

      case "i_ao_request": {
        if (e.session == oSipSessionCall) {
          var iSipResponseCode = e.getSipResponseCode();
          if (iSipResponseCode == 180 || iSipResponseCode == 183) {
            startRingbackTone();
            // txtCallStatus.innerHTML = "<i>Remote ringing...</i>";
            toast.success("Remote ringing...", {
              autoClose: 2000,
            });
          }
        }
        break;
      }

      case "m_early_media": {
        if (e.session == oSipSessionCall) {
          stopRingbackTone();
          stopRingTone();
          // txtCallStatus.innerHTML = "<i>Early media started</i>";
          toast.success("Early media started", {
            autoClose: 2000,
          });
        }
        break;
      }

      case "m_local_hold_ok": {
        if (e.session == oSipSessionCall) {
          if (oSipSessionCall.bTransfering) {
            oSipSessionCall.bTransfering = false;
            // this.AVSession.TransferCall(this.transferUri);
          }
          btnHoldResume.value = "Resume";
          btnHoldResume.disabled = false;
          // txtCallStatus.innerHTML = "<i>Call placed on hold</i>";
          toast.success("Call placed on hold", {
            autoClose: 2000,
          });
          oSipSessionCall.bHeld = true;
        }
        break;
      }
      case "m_local_hold_nok": {
        if (e.session == oSipSessionCall) {
          oSipSessionCall.bTransfering = false;
          btnHoldResume.value = "Hold";
          btnHoldResume.disabled = false;
          // txtCallStatus.innerHTML =
          //   "<i>Failed to place remote party on hold</i>";
          toast.success("Failed to place remote party on hold", {
            autoClose: 2000,
          });
        }
        break;
      }
      case "m_local_resume_ok": {
        if (e.session == oSipSessionCall) {
          oSipSessionCall.bTransfering = false;
          btnHoldResume.value = "Hold";
          btnHoldResume.disabled = false;
          // txtCallStatus.innerHTML = "<i>Call taken off hold</i>";
          toast.success("Call taken off hold", {
            autoClose: 2000,
          });
          oSipSessionCall.bHeld = false;

          if (SIPml.isWebRtc4AllSupported()) {
            // IE don't provide stream callback yet
            uiVideoDisplayEvent(false, true);
            uiVideoDisplayEvent(true, true);
          }
        }
        break;
      }
      case "m_local_resume_nok": {
        if (e.session == oSipSessionCall) {
          oSipSessionCall.bTransfering = false;
          btnHoldResume.disabled = false;
          // txtCallStatus.innerHTML = "<i>Failed to unhold call</i>";
          toast.error("Failed to unhold call", {
            autoClose: 2000,
          });
        }
        break;
      }
      case "m_remote_hold": {
        if (e.session == oSipSessionCall) {
          // txtCallStatus.innerHTML = "<i>Placed on hold by remote party</i>";
          toast.success("Placed on hold by remote party", {
            autoClose: 2000,
          });
        }
        break;
      }
      case "m_remote_resume": {
        if (e.session == oSipSessionCall) {
          // txtCallStatus.innerHTML = "<i>Taken off hold by remote party</i>";
          toast.success("Taken off hold by remote party", {
            autoClose: 2000,
          });
        }
        break;
      }
      case "m_bfcp_info": {
        if (e.session == oSipSessionCall) {
          // txtCallStatus.innerHTML = "BFCP Info: <i>" + e.description + "</i>";
          toast.success("BFCP Info: " + e.description, {
            autoClose: 2000,
          });
        }
        break;
      }

      case "o_ect_trying": {
        if (e.session == oSipSessionCall) {
          // txtCallStatus.innerHTML = "<i>Call transfer in progress...</i>";
          toast.success("Call transfer in progress...", {
            autoClose: 2000,
          });
        }
        break;
      }
      case "o_ect_accepted": {
        if (e.session == oSipSessionCall) {
          // txtCallStatus.innerHTML = "<i>Call transfer accepted</i>";
          toast.success("Call transfer accepted", {
            autoClose: 2000,
          });
        }
        break;
      }
      case "o_ect_completed":
      case "i_ect_completed": {
        if (e.session == oSipSessionCall) {
          //txtCallStatus.innerHTML = "<i>Call transfer completed</i>";
          toast.success("Call transfer completed", {
            autoClose: 2000,
          });
          btnTransfer.disabled = false;
          if (oSipSessionTransferCall) {
            setoSipSessionCall(oSipSessionTransferCall);
          }
          setoSipSessionTransferCall(null);
        }
        break;
      }
      case "o_ect_failed":
      case "i_ect_failed": {
        if (e.session == oSipSessionCall) {
          //txtCallStatus.innerHTML = "<i>Call transfer failed</i>";
          toast.success("Call transfer failed", {
            autoClose: 2000,
          });
          btnTransfer.disabled = false;
        }
        break;
      }
      case "o_ect_notify":
      case "i_ect_notify": {
        if (e.session == oSipSessionCall) {
          // txtCallStatus.innerHTML =
          //   "<i>Call Transfer: <b>" +
          //   e.getSipResponseCode() +
          //   " " +
          //   e.description +
          //   "</b></i>";
          toast.success(
            "Call Transfer: " + e.getSipResponseCode() + " " + e.description,
            {
              autoClose: 2000,
            }
          );
          if (e.getSipResponseCode() >= 300) {
            if (oSipSessionCall.bHeld) {
              oSipSessionCall.resume();
            }
            btnTransfer.disabled = false;
          }
        }
        break;
      }
      case "i_ect_requested": {
        if (e.session == oSipSessionCall) {
          var s_message =
            "Do you accept call transfer to [" +
            e.getTransferDestinationFriendlyName() +
            "]?"; //FIXME
          if (confirm(s_message)) {
            // txtCallStatus.innerHTML = "<i>Call transfer in progress...</i>";
            toast.success("Call transfer in progress...", {
              autoClose: 2000,
            });
            oSipSessionCall.acceptTransfer();
            break;
          }
          oSipSessionCall.rejectTransfer();
        }
        break;
      }
    }
  }

  return (
    <div style={{ overflow: "hidden" }}>
      <AppBar
        sx={{
          position: "fixed",
          top: "auto",
          bottom: 0,
          backgroundColor: "#fff",
          left: "70%",
          width: "30%",
          // display: value == 0 ? "none" : "block",
        }}
      >
        <Toolbar>
          <Box sx={{ flexGrow: 1 }}></Box>
          {value == 1 ? (
            <Stack direction="row" spacing={2}>
              <FormControl
                sx={{
                  minWidth: 120,
                }}
                size="small"
              >
                <Button
                  variant="outlined"
                  className="endcall-bttn"
                  color="error"
                  startIcon={<LockOutlinedIcon />}
                  onClick={() => {
                    sipUnRegister();
                  }}
                >
                  Logout
                </Button>
              </FormControl>
              <FormControl
                sx={{
                  minWidth: 120,
                }}
                size="small"
              >
                <Button
                  color="success"
                  variant="outlined"
                  className="call-bttn"
                  startIcon={<LockOpenOutlinedIcon />}
                  disabled={callbtndisabled}
                  onClick={() => {
                    saveCredentials();
                  }}
                >
                  {btnvalue}
                </Button>
              </FormControl>
            </Stack>
          ) : (
            <Stack direction="row" spacing={2}>
              <FormControl
                sx={{
                  minWidth: 120,
                }}
                size="small"
              >
                <Button
                  variant="outlined"
                  className="endcall-bttn"
                  color="error"
                  startIcon={<HistoryOutlinedIcon />}
                  onClick={settingsRevert}
                >
                  Revert
                </Button>
              </FormControl>
              <FormControl
                sx={{
                  minWidth: 120,
                }}
                size="small"
              >
                <Button
                  color="success"
                  variant="outlined"
                  className="call-bttn"
                  startIcon={<SaveOutlinedIcon />}
                  onClick={settingsSave}
                >
                  Save
                </Button>
              </FormControl>
            </Stack>
          )}
        </Toolbar>
      </AppBar>
      <AppBar
        sx={{
          position: "fixed",
          top: 0,
          bottom: "auto",
          backgroundColor: "#01c0c8",
          left: "70%",
          width: "30%",
          // color: "#333333",
        }}
      >
        <Toolbar>
          <Typography
            component={"span"}
            sx={{ ml: 2, flex: 1, fontSize: "1.25rem", fontWeight: "500" }}
          >
            Settings
          </Typography>
          <Box sx={{ flexGrow: 1 }}></Box>
          <IconButton
            edge="start"
            color="inherit"
            onClick={temphandleClose}
            aria-label="close"
          >
            <CloseIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Box
        sx={{
          display: "flex",
          "& > :not(style)": {
            mt: 8,
            ml: 5,
            mr: 5,
            width: "50%",
            height: "100%",
          },
        }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
          variant="fullWidth"
        >
          <Tab label="Expert settings" {...a11yProps(0)} />
          <Tab label="Make call" {...a11yProps(1)} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0} sx={{ mt: -1 }}>
        <Paper elevation={0}>
          <Stack direction="row" spacing={0} sx={{ mt: -2, ml: 0 }}>
            <FormControlLabel
              control={
                <Checkbox
                  size="small"
                  checked={disablevideo}
                  onChange={() => {
                    setDisablevideo(!disablevideo);
                  }}
                  name="disablevideo"
                />
              }
              label="Disable Video"
            />

            <FormControlLabel
              control={
                <Checkbox
                  size="small"
                  checked={enablertcweb}
                  onChange={() => {
                    setEnablertcweb(!enablertcweb);
                  }}
                  name="enablertcwebbreaker"
                />
              }
              label="Enable RTCWeb Breaker"
            />
          </Stack>
          <Stack direction="row" spacing={0} sx={{ mt: 1, ml: 0 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="WebSocket Server URL"
              variant="outlined"
              autoComplete="off"
              value={serverurl}
              onChange={(event) => {
                setServerurl(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 1, ml: 0 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="SIP outbound Proxy URL"
              variant="outlined"
              autoComplete="off"
              value={proxyurl}
              onChange={(event) => {
                setProxyurl(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 1, ml: 0 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="ICE Servers"
              variant="outlined"
              autoComplete="off"
              value={iceservers}
              onChange={(event) => {
                setIceservers(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 1, ml: 0 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="Max bandwidth (kbps)"
              variant="outlined"
              autoComplete="off"
              value={bandwidth}
              onChange={(event) => {
                setBandwidth(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 1, ml: 0 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="Video size"
              variant="outlined"
              autoComplete="off"
              value={videosize}
              onChange={(event) => {
                setVideosize(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 0.3, ml: 0 }}>
            <FormControlLabel
              control={
                <Checkbox
                  size="small"
                  checked={earlyims}
                  onChange={() => {
                    setEarlyims(!earlyims);
                  }}
                  name="disable3GPPearlyIMS"
                />
              }
              label="Disable 3GPP Early IMS"
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 0.3, ml: 0 }}>
            <FormControlLabel
              control={
                <Checkbox
                  size="small"
                  checked={debugmessages}
                  onChange={() => {
                    setDebugmessages(!debugmessages);
                  }}
                  name="disabledebugmessages"
                />
              }
              label="Disable debug messages"
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 0.3, ml: 0 }}>
            <FormControlLabel
              control={
                <Checkbox
                  size="small"
                  checked={mediastream}
                  onChange={() => {
                    setMediastream(!mediastream);
                  }}
                  name="Cachethemediastream"
                />
              }
              label="Cache the media stream"
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 0.3, ml: 0 }}>
            <FormControlLabel
              control={
                <Checkbox
                  size="small"
                  checked={disablebuttonoption}
                  onChange={() => {
                    setDisablebuttonoption(!disablebuttonoption);
                  }}
                  name="disableCallbuttonoptions"
                />
              }
              label="Disable Call button options"
            />
          </Stack>
        </Paper>
      </TabPanel>
      <TabPanel value={value} index={1}>
        <Paper elevation={0}>
          <Stack direction="row" spacing={0} sx={{ mt: 2, ml: 2 }}>
            <div
              id="divCallCtrl"
              className="span7 well"
              // isplay:"table-cell", vertical-align:"middle"
              sx={{ display: "table-cell" }}
            >
              <label
                sx={{ width: "100%" }}
                align="center"
                id="txtCallStatus"
              ></label>
              <h2>Call control</h2>
              <br />
              <table sx={{ width: "100%" }}>
                <tr>
                  <td>
                    <input
                      type="text"
                      sx={{ width: "100%", height: "100%" }}
                      id="txtPhoneNumber"
                      defaultValue={""}
                      placeholder="Enter phone number to call"
                    />
                  </td>
                </tr>
                <tr>
                  <td colspan="1" align="right">
                    <div className="btn-toolbar" sx={{ margin: 0 }}>
                      <div id="divBtnCallGroup" className="btn-group">
                        <button
                          className="btn btn-primary"
                          data-toggle="dropdown"
                          onClick={() => {
                            sipCall(
                              bDisableVideo ? "call-audio" : "call-audiovideo"
                            );
                          }}
                        >
                          {btnmakecallvalue}
                        </button>
                      </div>
                      &nbsp;&nbsp;
                      <div className="btn-group">
                        <input
                          type="button"
                          id="btnHangUp"
                          // style="margin: 0; vertical-align:middle; height: 100%;"
                          className="btn btn-primary"
                          defaultValue={"Hangup"}
                          // onclick="sipHangUp();"
                          onClick={() => {
                            sipHangUp();
                          }}
                        />
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td id="tdVideo" className="tab-video">
                    <div id="divVideo" className="div-video">
                      <div
                        id="divVideoRemote"
                        // style="position:relative; border:1px solid #009; height:100%; width:100%; z-index: auto; opacity: 1"
                      >
                        <video
                          className="video"
                          width="100%"
                          height="100%"
                          id="video_remote"
                          autoplay="autoplay"
                          // style="opacity: 0;
                          // background-color: #000000; -webkit-transition-property: opacity; -webkit-transition-duration: 2s;"
                        ></video>
                      </div>

                      <div
                        id="divVideoLocalWrapper"
                        // style="margin-left: 0px; border:0px solid #009; z-index: 1000"
                      >
                        <iframe
                          className="previewvideo"
                          // style="border:0px solid #009; z-index: 1000"
                        >
                          {" "}
                        </iframe>
                        <div
                          id="divVideoLocal"
                          className="previewvideo"
                          // style=" border:0px solid #009; z-index: 1000"
                        >
                          <video
                            className="video"
                            width="100%"
                            height="100%"
                            id="video_local"
                            autoplay="autoplay"
                            muted="true"
                            // style="opacity: 0;
                            //                 background-color: #000000; -webkit-transition-property: opacity;
                            //                 -webkit-transition-duration: 2s;"
                          ></video>
                        </div>
                      </div>
                      <div
                        id="divScreencastLocalWrapper"
                        // style="margin-left: 90px; border:0px solid #009; z-index: 1000"
                      >
                        <iframe
                          className="previewvideo"
                          // style="border:0px solid #009; z-index: 1000"
                        >
                          {" "}
                        </iframe>
                        <div
                          id="divScreencastLocal"
                          className="previewvideo"
                          // style=" border:0px solid #009; z-index: 1000"
                        ></div>
                      </div>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td align="center">
                    <div
                      id="divCallOptions"
                      className="call-options"
                      // style="opacity: 0; margin-top: 0px"
                    >
                      <input
                        type="button"
                        className="btn"
                        // style=""
                        id="btnFullScreen"
                        defaultValue={"FullScreen"}
                        disabled
                        onClick={() => {
                          toggleFullScreen();
                        }}
                      />
                      &nbsp;
                      <input
                        type="button"
                        className="btn"
                        // style=""
                        id="btnMute"
                        defaultValue={"Mute"}
                        onClick={() => {
                          sipToggleMute();
                        }}
                      />{" "}
                      &nbsp;
                      <input
                        type="button"
                        className="btn"
                        // style=""
                        id="btnHoldResume"
                        defaultValue={"Hold"}
                        onClick={() => {
                          sipToggleHoldResume();
                        }}
                      />
                      &nbsp;
                      <input
                        type="button"
                        className="btn"
                        // style=""
                        id="btnTransfer"
                        defaultValue={"Transfer"}
                        onClick={() => {
                          sipTransfer();
                        }}
                      />
                      &nbsp;
                      <input
                        type="button"
                        className="btn"
                        id="btnKeyPad"
                        defaultValue={"KeyPad"}
                        onClick={() => {
                          openKeyPad();
                        }}
                      />
                    </div>
                  </td>
                </tr>
              </table>
            </div>
            <div
              id="divGlassPanel"
              className="glass-panel"
              sx={{ visibility: "hidden" }}
            ></div>

            <div
              id="divKeyPad"
              className="span2 well div-keypad"
              sx={{
                left: "0px",
                top: "0px",
                width: 250,
                height: 240,
                visibility: "hidden",
              }}
            >
              <table sx={{ width: "100%", height: "100%" }}>
                <tr>
                  <td>
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"1"}
                      onClick={() => {
                        sipSendDTMF("1");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"2"}
                      onClick={() => {
                        sipSendDTMF("2");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"3"}
                      onClick={() => {
                        sipSendDTMF("3");
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <td>
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"4"}
                      onClick={() => {
                        sipSendDTMF("4");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"5"}
                      onClick={() => {
                        sipSendDTMF("5");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"6"}
                      onClick={() => {
                        sipSendDTMF("6");
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <td>
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"7"}
                      onClick={() => {
                        sipSendDTMF("7");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"8"}
                      onClick={() => {
                        sipSendDTMF("8");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"9"}
                      onClick={() => {
                        sipSendDTMF("9");
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <td>
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"*"}
                      onClick={() => {
                        sipSendDTMF("*");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"0"}
                      onClick={() => {
                        sipSendDTMF("0");
                      }}
                    />
                    <input
                      type="button"
                      sx={{ width: "33%" }}
                      className="btn"
                      defaultValue={"#"}
                      onClick={() => {
                        sipSendDTMF("#");
                      }}
                    />
                  </td>
                </tr>
                <tr>
                  <td>
                    <input
                      type="button"
                      sx={{ width: "100%" }}
                      className="btn btn-medium btn-danger"
                      defaultValue={"close"}
                      onClick={() => {
                        closeKeyPad();
                      }}
                    />
                  </td>
                </tr>
              </table>
            </div>

            <ul
              id="ulCallOptions"
              className="dropdown-menu"
              sx={{ visibility: "hidden" }}
            >
              <li>
                <a
                  href="#"
                  onClick={() => {
                    sipCall("call-audio");
                  }}
                >
                  Audio
                </a>
              </li>
              <li>
                <a
                  href="#"
                  onClick={() => {
                    sipCall("call-audiovideo");
                  }}
                >
                  Video
                </a>
              </li>
              <li id="liScreenShare">
                <a
                  href="#"
                  onClick={() => {
                    sipShareScreen();
                  }}
                >
                  Screen Share
                </a>
              </li>
              <li className="divider"></li>
              <li>
                <a
                  href="#"
                  onClick={() => {
                    uiDisableCallOptions();
                  }}
                >
                  <b>Disable these options</b>
                </a>
              </li>
            </ul>
          </Stack>
          <Stack direction="row" spacing={1} sx={{ ml: 2 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="Display Name"
              variant="outlined"
              autoComplete="off"
              value={displayname}
              onChange={(event) => {
                setDisplayname(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={0} sx={{ mt: 2, ml: 2 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              required
              label="Private Identity"
              variant="outlined"
              autoComplete="off"
              value={privateidentity}
              onChange={(event) => {
                setPrivateidentity(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={0} sx={{ mt: 2, ml: 2 }}>
            <TextField
              sx={{ minWidth: 300 }}
              required
              size="small"
              label="Public Identity"
              variant="outlined"
              autoComplete="off"
              value={publicidentity}
              onChange={(event) => {
                setPublicidentity(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 2, ml: 2 }}>
            <TextField
              sx={{ minWidth: 300 }}
              size="small"
              label="Password"
              variant="outlined"
              autoComplete="off"
              value={password}
              onChange={(event) => {
                setPassword(event.target.value);
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1} sx={{ mt: 2, ml: 2 }}>
            <TextField
              sx={{ minWidth: 300 }}
              required
              size="small"
              label="Realm"
              variant="outlined"
              autoComplete="off"
              value={realm}
              onChange={(event) => {
                setRealm(event.target.value);
              }}
            />
          </Stack>
        </Paper>
      </TabPanel>
      <ToastContainer theme="colored" />
    </div>
  );
};
const mapStateToProps = (state) => ({
  state: state,
});
const mapDispatchToProps = (dispatch) => ({
  // addCompany: (data) => dispatch(addCompany(data)),
});
export default Expertsettings;
