const registration = () => {
  return <div></div>;
};
export default registration;
