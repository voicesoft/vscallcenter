import React from "react";
import "./common.css";
import {
  Box,
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  Button,
  Stack,
  MenuItem,
  FormControl,
  Paper,
  TextField,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { useState } from "react";
import { Grid } from "./grid";
import { ToastContainer, toast } from "react-toastify";
// import { addCompany } from "../../store/action/index";

const Addcompany = ({ handleClose }) => {
  // const [companyname, setCompanyName] = useState(companydetail.companyname);
  // const [displayname, setDisplayName] = useState(companydetail.displayname);
  // const [address1, setAddress1] = useState(companydetail.address1);
  // const [address2, setAddress2] = useState(companydetail.address2);
  // const [cityname, setCityName] = useState(companydetail.city);
  // const [statename, setStateName] = useState(companydetail.state);
  // const [zipcode, setZipCode] = useState(companydetail.zipcode);
  // const [country, setCountry] = useState(companydetail.country);
  // const [email, setEmail] = useState(companydetail.email);
  // const [contactno, setContactNo] = useState(companydetail.contactnumber);
  // const [contactperson, setContactPerson] = useState(
  //   companydetail.contactperson
  // );
  // const [approvetype, setApprovetype] = useState(companydetail.approvetype);
  // const [currency, setCurrency] = useState(companydetail.defaultcurrencyid);
  // const [username, setUsername] = useState(companydetail.username);
  // const [validcompanyname, setValidCompanyName] = useState(true);
  // const [validdisplayname, setValidDisplayName] = useState(true);
  // const [validaddress1, setValidAddress1] = useState(true);
  // const [validaddress2, setValidAddress2] = useState(true);
  // const [validcityname, setValidCityName] = useState(true);
  // const [validstatename, setValidStateName] = useState(true);
  // const [validzipcode, setValidZipCode] = useState(true);
  // const [validcountry, setValidCountry] = useState(true);
  // const [validemail, setValidEmail] = useState(true);
  // const [validcontactno, setValidContactNo] = useState(true);
  // const [validcontactperson, setValidContactPerson] = useState(true);
  // const [validcurrency, setValidCurrency] = useState(true);
  // const [validusername, setValidUsername] = useState(true);
  // const [isValid, setIsValid] = useState(false);
  // const [message, setMessage] = useState("");
  // const [formsubmitoption, setFormSubmitOption] = useState(1);
  // Email validation

  // const handleChange = (event) => {
  //   setApprovetype(event.target.value);
  // };
  // Form input clear
  // const temphandleClear = () => {
  //   setCompanyName("");
  //   setDisplayName("");
  //   setAddress1("");
  //   setAddress2("");
  //   setCityName("");
  //   setStateName("");
  //   setZipCode("");
  //   setCountry("");
  //   setEmail("");
  //   setContactNo("");
  //   setContactPerson("");
  //   setCurrency("");
  //   setUsername("");
  //   setApprovetype(false);
  // };
  // Close form
  const temphandleClose = () => {
    handleClose();
  };
  return (
    <div style={{ overflow: "hidden" }}>
      <AppBar
        sx={{
          position: "fixed",
          top: "auto",
          bottom: 0,
          backgroundColor: "#fff",
        }}
      >
        <Toolbar>
          <Box sx={{ flexGrow: 1 }}></Box>
          <Stack direction="row" spacing={2}>
            <FormControl
              sx={{
                minWidth: 120,
              }}
              size="small"
            >
              <Button
                variant="outlined"
                className="clear-bttn"
                // onClick={temphandleClear}
              >
                Clear
              </Button>
            </FormControl>
            <FormControl
              sx={{
                minWidth: 120,
              }}
              size="small"
            >
              <Button
                color="success"
                variant="outlined"
                className="save-bttn"
                // onClick={handlesaveandclose}
              >
                Save
              </Button>
            </FormControl>
          </Stack>
        </Toolbar>
      </AppBar>
      <AppBar
        sx={{
          position: "fixed",
          top: 0,
          bottom: "auto",
          backgroundColor: "#01c0c8",
          // color: "#333333",
        }}
      >
        <Toolbar>
          <Typography
            sx={{ ml: 2, flex: 1, fontSize: "1.25rem", fontWeight: "500" }}
          >
            Company
          </Typography>
          <Box sx={{ flexGrow: 1 }}></Box>
          <IconButton
            edge="start"
            color="inherit"
            onClick={temphandleClose}
            aria-label="close"
          >
            <CloseIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
      <Box
        sx={{
          display: "flex",
          "& > :not(style)": {
            m: 7,
            width: "100%",
            height: "100%",
          },
        }}
      >
        <Grid container>
          <Grid item xs>
            <Paper elevation={0}>
              <Stack direction="row" spacing={2} sx={{ mt: 4, ml: 2 }}>
                <TextField
                  sx={{
                    minWidth: 300,
                  }}
                  label="Company name"
                  helperText="Please enter company name"
                  autoComplete="off"
                  // error={!validcompanyname}
                  // onChange={(event) => {
                  //   setCompanyName(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidCompanyName(true);
                  //   }
                  // }}
                  // value={companyname}
                ></TextField>
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Display name"
                  variant="outlined"
                  helperText="Please enter display name"
                  autoComplete="off"
                  // error={!validdisplayname}
                  // onChange={(event) => {
                  //   setDisplayName(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidDisplayName(true);
                  //   }
                  // }}
                  // value={displayname}
                />
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Username"
                  variant="outlined"
                  helperText="Please enter username"
                  autoComplete="off"
                  // error={!validusername}
                  // onChange={(event) => {
                  //   setUsername(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidUsername(true);
                  //   }
                  // }}
                  // value={username}
                />
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Email"
                  variant="outlined"
                  autoComplete="off"
                  // helperText={
                  //   email == ""
                  //     ? "Please enter email"
                  //     : [
                  //         <div
                  //           className={`message ${
                  //             isValid ? "success" : "error"
                  //           }`}
                  //         >
                  //           {message}
                  //         </div>,
                  //       ]
                  // }
                  // error={!validemail}
                  // onChange={emailvalidation}
                  // value={email}
                />
              </Stack>
              <Stack direction="row" spacing={2} sx={{ mt: 4, ml: 2 }}>
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Address-1"
                  variant="outlined"
                  helperText="Please enter address-1"
                  autoComplete="off"
                  // error={!validaddress1}
                  // onChange={(event) => {
                  //   setAddress1(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidAddress1(true);
                  //   }
                  // }}
                  // value={address1}
                />
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Address-2"
                  helperText="Please enter address-2"
                  autoComplete="off"
                  // error={!validaddress2}
                  // onChange={(event) => {
                  //   setAddress2(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidAddress2(true);
                  //   }
                  // }}
                  // value={address2}
                ></TextField>
                <TextField
                  sx={{ minWidth: 300 }}
                  label="City"
                  variant="outlined"
                  helperText="Please enter city"
                  autoComplete="off"
                  // error={!validcityname}
                  // onChange={(event) => {
                  //   setCityName(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidCityName(true);
                  //   }
                  // }}
                  // value={cityname}
                />
                <TextField
                  sx={{ minWidth: 300 }}
                  label="State"
                  variant="outlined"
                  helperText="Please enter state"
                  autoComplete="off"
                  // error={!validstatename}
                  // onChange={(event) => {
                  //   setStateName(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidStateName(true);
                  //   }
                  // }}
                  // value={statename}
                />
              </Stack>
              <Stack direction="row" spacing={2} sx={{ mt: 4, ml: 2 }}>
                <TextField
                  sx={{ minWidth: 300 }}
                  label="ZIP code"
                  variant="outlined"
                  helperText="Please enter ZIP code"
                  autoComplete="off"
                  // error={!validzipcode}
                  // onChange={(event) => {
                  //   setZipCode(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidZipCode(true);
                  //   }
                  // }}
                  // value={zipcode}
                />
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Country"
                  variant="outlined"
                  helperText="Please enter country"
                  autoComplete="off"
                  // error={!validcountry}
                  // onChange={(event) => {
                  //   setCountry(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidCountry(true);
                  //   }
                  // }}
                  // value={country}
                />
                <TextField
                  select
                  sx={{ minWidth: 300 }}
                  label="Currency"
                  variant="outlined"
                  helperText="Please select currency"
                  autoComplete="off"
                  // error={!validcurrency}
                  // onChange={(event) => {
                  //   setCurrency(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidCurrency(true);
                  //   }
                  // }}
                  // value={currency}
                >
                  <MenuItem value="1">--Select--</MenuItem>
                </TextField>
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Contact number"
                  variant="outlined"
                  helperText="Please enter contactno"
                  autoComplete="off"
                  // error={!validcontactno}
                  // onChange={(event) => {
                  //   setContactNo(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidContactNo(true);
                  //   }
                  // }}
                  // value={contactno}
                />
              </Stack>
              <Stack direction="row" spacing={2} sx={{ mt: 4, ml: 2 }}>
                <TextField
                  sx={{ minWidth: 300 }}
                  label="Contact person"
                  variant="outlined"
                  helperText="Please enter contact person"
                  autoComplete="off"
                  // error={!validcontactperson}
                  // onChange={(event) => {
                  //   setContactPerson(event.target.value);
                  //   if (event.target.value != 0) {
                  //     setValidContactPerson(true);
                  //   }
                  // }}
                  // value={contactperson}
                />
              </Stack>
            </Paper>
          </Grid>
        </Grid>
      </Box>
      <ToastContainer theme="colored" />
    </div>
  );
};
const mapStateToProps = (state) => ({
  state: state,
});
const mapDispatchToProps = (dispatch) => ({
  // addCompany: (data) => dispatch(addCompany(data)),
});
export default Addcompany;
