import { LOG_IN } from "../types";

import axios from "axios";
let jsonconfig = {
  headers: {
    "Content-Type": "application/json",
  },
};
// const loginUrl =
//   "https://callorder.voicesnap.com/callcenter/api/AgentmonitorWebAPI/";

// const loginUrl =
//   "https://ap.voicehuddle.com/callcenter/api/AgentmonitorWebAPI/";
// const adminUrl = "https://ap.voicehuddle.com/callcenter/api/VSRAdmin/";

const loginUrl = "https://phoneorder.co/callcenter/api/AgentmonitorWebAPI/";
const adminUrl = "https://phoneorder.co/callcenter/api/VSRAdmin/";

export const Validatelogin = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "ValidateLogin",
      JSON.stringify(ipval),
      jsonconfig
    );
    dispatch({
      type: LOG_IN,
      payload: response.data,
    });
    return response.data;
  } catch (ex) {}
};
export const LoadCompany = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "Loadagentcallstatus",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const LoadagentDDL = (ipval) => async (dispatch) => {
  try {
    const response = await axios.get(
      loginUrl +
        "Loadagentbyrmddl?reportingmanagerid=" +
        ipval.reportingmanagerid
    );
    return response.data;
  } catch (ex) {}
};
export const downloadAgentstatusReport = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "downloadagentcallstatus",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const downloadSummaryReport = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "Loadagentcallsummary",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const downloadDetailReport = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "Loadagentcalldetail",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const loadSummaryreport = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "Loadagentcallsummarystatus",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};
export const loadDetailedreport = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      loginUrl + "Loadagentcalldetailstatus",
      JSON.stringify(ipval),
      jsonconfig
    );
    return response.data;
  } catch (ex) {}
};

export const Agentlogout = (ipval) => async (dispatch) => {
  try {
    const response = await axios.post(
      adminUrl + "updateagentavailability?extension=" + ipval
    );
    return response.data;
  } catch (ex) {}
};
