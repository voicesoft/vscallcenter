import { combineReducers } from "redux";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import loginreducer from "./loginreducer";

const persistConfig = {
  key: "root",
  storage,
  whitelist: ["loginreducer"],
};
const rootReducer = combineReducers({
  loginreducer: loginreducer,
});

export default persistReducer(persistConfig, rootReducer);
