import React from "react";
import "./common.css";
import { useEffect, useState, useMemo } from "react";
import Avatar from "@mui/material/Avatar";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import {
  Box,
  Button,
  MenuItem,
  FormLabel,
  TextField,
  Tooltip,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import IconButton from "@mui/material/IconButton";
import TableContainer from "@mui/material/TableContainer";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TableCell from "@mui/material/TableCell";
import Paper from "@mui/material/Paper";
import { stringAvatar } from "./avatar";
import { Overlay, Popover } from "react-bootstrap";
import istudiologo from "../../images/vslogo.png";
import { ToastContainer, toast } from "react-toastify";
import Pagination from "./tablepagination";
import RefreshIcon from "@mui/icons-material/Refresh";
import {
  LoadCompany,
  LoadagentDDL,
  loadSummaryreport,
  loadDetailedreport,
  downloadSummaryReport,
  downloadDetailReport,
  downloadAgentstatusReport,
  Agentlogout,
} from "../../store/action/index";
import { connect } from "react-redux";
import { useNavigate } from "react-router-dom";
import Loader from "../common/loader";
import DatePicker, { DateObject } from "react-multi-date-picker";
import PhoneDisabledOutlinedIcon from "@mui/icons-material/PhoneDisabledOutlined";
import PhoneLockedOutlinedIcon from "@mui/icons-material/PhoneLockedOutlined";
import PersonOffOutlinedIcon from "@mui/icons-material/PersonOffOutlined";
import OutputOutlinedIcon from "@mui/icons-material/OutputOutlined";

const Home = ({
  loadCompany,
  LoadagentddL,
  loadsummaryreport,
  loaddetailedreport,
  downloadsummaryReport,
  downloaddetailReport,
  downloadagentstatusReport,
  agentlogout,
  state,
}) => {
  /* Declarations */
  let navigate = useNavigate();
  const menuId = "primary-search-account-menu";
  const [agentid, setAgentid] = useState("0");
  const [agentinfo, setAgentinfo] = useState([]);
  const [agentdata, setAgentdata] = useState([]);
  const [summaryinfo, setSummaryinfo] = useState([]);
  const [detailedinfo, setDetailedinfo] = useState([]);
  const [totalrow, setTotalrow] = useState(0);
  const [totalcount, setTotalcount] = useState(0);
  const [totalinfo, setTotalinfo] = useState(0);
  const [show, setShow] = useState(false);
  const [target, setTarget] = useState(null);
  const [agentfromdate, setAgentFromdate] = useState(
    new DateObject().subtract(0, "days")
  );
  const [agenttodate, setAgentTodate] = useState(
    new DateObject().add(0, "days")
  );
  const [fromdate, setFromdate] = useState(
    new DateObject().subtract(7, "days")
  );
  const [todate, setTodate] = useState(new DateObject().add(0, "days"));
  const [openloading, setOpenloading] = useState(false);

  /* TOTAL CALCULATION */
  const cantidad = useMemo(() => {
    return new Array(summaryinfo.length).fill(1);
  }, [summaryinfo]);

  // TOTAL CONNECTED
  const total = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.connected * cantidad[index];
    }, 0);
  }, [cantidad]);

  // TOTAL MISSED
  const missedCount = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.missed * cantidad[index];
    }, 0);
  }, [cantidad]);

  // TOTAL CALLS
  const totalCall = useMemo(() => {
    return total + missedCount;
  }, [cantidad]);

  // CALCULATE TOTAL CALLTIME
  const totalHour = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.duration.split(":")[0] * cantidad[index];
    }, 0);
  }, [cantidad]);

  const totalMin = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.duration.split(":")[1] * cantidad[index];
    }, 0);
  }, [cantidad]);

  const totalSec = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.duration.split(":")[2] * cantidad[index];
    }, 0);
  }, [cantidad]);

  const totalTime = useMemo(() => {
    var sec = +totalHour * 60 * 60 + +totalMin * 60 + +totalSec;
    let hours = Math.floor(sec / 3600);
    sec %= 3600;
    let minutes = Math.floor(sec / 60);
    let seconds = sec % 60;
    return hours + ":" + minutes + ":" + seconds;
  }, [cantidad]);
  // END TOTAL TIME

  // CALCULATE AVERAGE CALLTIME
  const avgHour = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.avgcalltime.split(":")[0] * cantidad[index];
    }, 0);
  }, [cantidad]);

  const avgMin = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.avgcalltime.split(":")[1] * cantidad[index];
    }, 0);
  }, [cantidad]);

  const avgSec = useMemo(() => {
    return summaryinfo.reduce((sum, data, index) => {
      return sum + data.avgcalltime.split(":")[2] * cantidad[index];
    }, 0);
  }, [cantidad]);

  const totalAvg = useMemo(() => {
    var sec = +avgHour * 60 * 60 + +avgMin * 60 + +avgSec;
    let hours = Math.floor(sec / 3600);
    sec %= 3600;
    let minutes = Math.floor(sec / 60);
    let seconds = sec % 60;
    return hours + ":" + minutes + ":" + seconds;
  }, [cantidad]);
  // END AVERAGE TIME
  /* END TOTAL CALCULATION */

  useEffect(() => {
    handlelistagent();
    let params = {
      reportingmanagerid: state.loginreducer.logininfo.data.resultset[0].userid,
    };
    LoadagentddL(params)
      .then((response) => {
        setAgentdata(response.data.resultset);
      })
      .catch((error) => {
        console.log("error: ", error);
      });
    handlelistsummary();
    handlelistdetailed();
  }, [agentid]);

  // LIST COMPANY
  const handlelistagent = () => {
    let params = {
      reportingmanagerid: state.loginreducer.logininfo.data.resultset[0].userid,
      agentid: parseInt(agentid),
    };
    loadCompany(params)
      .then((response) => {
        setAgentinfo(response.data.resultset);
        setTotalrow(response.data.resultset.length);
      })
      .catch((error) => {
        console.log("error: ", error);
      });
  };
  // SUMMARY REPORT LIST
  const handlelistsummary = () => {
    setOpenloading(true);
    let params = {
      reportingmanagerid: state.loginreducer.logininfo.data.resultset[0].userid,
      agentid: parseInt(agentid),
      fromdate: fromdate.toString(),
      todate: todate.toString(),
    };
    loadsummaryreport(params)
      .then((response) => {
        setSummaryinfo(response.data.resultset);
        setTotalcount(response.data.resultset.length);
        setTimeout(() => {
          setOpenloading(false);
        }, 100);
      })
      .catch((error) => {
        console.log("error: ", error);
        setTimeout(() => {
          setOpenloading(false);
        }, 100);
      });
  };
  // DETAILED REPORT LIST
  const handlelistdetailed = () => {
    setOpenloading(true);
    let params = {
      reportingmanagerid: state.loginreducer.logininfo.data.resultset[0].userid,
      agentid: parseInt(agentid),
      fromdate: fromdate.toString(),
      todate: todate.toString(),
    };
    loaddetailedreport(params)
      .then((response) => {
        setDetailedinfo(response.data.resultset);
        setTotalinfo(response.data.resultset.length);
        setTimeout(() => {
          setOpenloading(false);
        }, 100);
      })
      .catch((error) => {
        console.log("error: ", error);
        setTimeout(() => {
          setOpenloading(false);
        }, 100);
      });
  };
  // PROFILE MENU POPOVER
  const handleProfileMenuOpen = (event) => {
    setShow(!show);
    setTarget(event.target);
  };

  // DOWNLOAD AGENT STATUS REPORT
  const handledownloadAgentstatus = () => {
    let params = {
      agentid: parseInt(agentid),
      fromdate: agentfromdate.toString(),
      todate: agenttodate.toString(),
    };
    downloadagentstatusReport(params)
      .then((response) => {
        if (response.data.status === 1) {
          if (response.data.message.split("¶").length > 0) {
            window.open(response.data.message, "_self");
          }
        } else {
          toast.error(response.data.message, {
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log("error: ", error);
      });
  };

  // DOWNLOAD SUMMARY REPORT
  const handledownloadSummary = () => {
    let params = {
      reportingmanagerid: state.loginreducer.logininfo.data.resultset[0].userid,
      agentid: parseInt(agentid),
      fromdate: fromdate.toString(),
      todate: todate.toString(),
    };
    downloadsummaryReport(params)
      .then((response) => {
        if (response.data.status === 1) {
          if (response.data.message.split("¶").length > 0) {
            window.open(response.data.message, "_self");
          }
        } else {
          toast.error(response.data.message, {
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log("error: ", error);
      });
  };

  // DOWNLOAD DETAILED REPORT
  const handledownloadDetailed = () => {
    let params = {
      reportingmanagerid: state.loginreducer.logininfo.data.resultset[0].userid,
      agentid: parseInt(agentid),
      fromdate: fromdate.toString(),
      todate: todate.toString(),
    };
    downloaddetailReport(params)
      .then((response) => {
        if (response.data.status === 1) {
          if (response.data.message.split("¶").length > 0) {
            window.open(response.data.message, "_self");
          }
        } else {
          toast.error(response.data.message, {
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log("error: ", error);
      });
  };

  // FORCE AGENT LOGOUT
  const handleLogout = (row) => {
    agentlogout(row.agentextension)
      .then((response) => {
        if (response.data.data[0].status === 1) {
          toast.success(response.data.data[0].message, {
            autoClose: 1000,
          });
          handlelistagent();
        } else {
          toast.error(response.data.data[0].message, {
            autoClose: 1000,
          });
        }
      })
      .catch((error) => {
        console.log("error: ", error);
      });
  };

  // CLIENT SIDE PAGINATION FOR LIVE MONITOR
  const [pageItems, setPageItems] = useState(0);
  const usersPerPage = 10;
  const pagesVisited = pageItems * usersPerPage;
  const pageCount = Math.ceil(agentinfo.length / usersPerPage);
  const handlePageClick = ({ selected }) => {
    setPageItems(selected);
  };
  const signouthandler = () => {
    navigate("/");
  };

  return (
    <div className="dashboard-page">
      <div className="dashboard-header">
        <img
          alt="logo"
          src={istudiologo}
          style={{ marginLeft: "20px", height: "50px" }}
        />
        <div className="col-6">
          <IconButton
            sx={{ float: "right", p: 2 }}
            size="large"
            aria-label="account of current user"
            aria-controls={menuId}
            aria-haspopup="true"
            onClick={handleProfileMenuOpen}
          >
            <Avatar
              {...stringAvatar(
                state.loginreducer.logininfo.data.resultset[0].username
              )}
              sx={{ bgcolor: "#fff", color: "#1976d2" }}
            ></Avatar>
          </IconButton>
        </div>
      </div>
      <div className="dashboard-container">
        <Tabs defaultActiveKey="live monitor" id="tabs-list" className="mt-2">
          <Tab eventKey="live monitor" title="Live monitor">
            <div className="dashboard-items">
              {/* <h5>Live call status</h5> */}
              <FormLabel htmlFor="disabledTextInput">From date :</FormLabel>
              <DatePicker
                placeholder="From date"
                format="YYYY-MM-DD"
                calendarPosition="bottom"
                style={{
                  width: "13rem",
                  padding: "10px",
                  height: "40px",
                  fontSize: "15px",
                  fontFamily: "sans-serif",
                }}
                value={agentfromdate}
                onChange={setAgentFromdate}
              />
              <FormLabel htmlFor="disabledTextInput">To date :</FormLabel>
              <DatePicker
                placeholder="To date"
                format="YYYY-MM-DD"
                calendarPosition="bottom"
                style={{
                  width: "13rem",
                  padding: "10px",
                  height: "40px",
                  fontSize: "15px",
                  fontFamily: "sans-serif",
                }}
                value={agenttodate}
                onChange={setAgentTodate}
              />
              <TextField
                sx={{
                  minWidth: 250,
                }}
                select
                size="small"
                label="Agent"
                onChange={(event) => {
                  setAgentid(event.target.value);
                }}
                value={agentid}
              >
                <MenuItem value="0">All</MenuItem>
                {agentdata.map((data, i) => (
                  <MenuItem value={data.agentid} key={i}>
                    {data.agentname}
                  </MenuItem>
                ))}
              </TextField>
              <Button
                variant="contained"
                color="primary"
                sx={{ textTransform: "none" }}
                onClick={handledownloadAgentstatus}
              >
                Download
              </Button>
              <Button
                variant="outlined"
                color="success"
                size="medium"
                startIcon={<RefreshIcon />}
                sx={{
                  ml: 4,
                  fontSize: "15px",
                  textTransform: "none",
                  ":hover": { backgroundColor: "green", color: "white" },
                }}
                onClick={() => {
                  handlelistagent();
                  setAgentid("0");
                }}
              >
                Refresh
              </Button>
            </div>
            <Box
              sx={{
                height: "calc(100vh - 230px)",
                mt: 1,
              }}
            >
              <TableContainer
                component={Paper}
                sx={{
                  maxHeight: "calc(100vh - 260px)",
                }}
              >
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      <TableCell align="right" className="headerstyle">
                        SNo.
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Agent Name
                      </TableCell>
                      {/* <TableCell align="left" className="headerstyle">
                        Agent Extension
                      </TableCell> */}
                      <TableCell align="left" className="headerstyle">
                        Last call date
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Last call time
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Last call duration
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Last call status
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Current status
                      </TableCell>
                      <TableCell align="left" className="headerstyle">
                        Action
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {agentinfo
                      .slice(pagesVisited, pagesVisited + usersPerPage)
                      .map((row) => (
                        <TableRow key={row.sno}>
                          <TableCell
                            className="headerstyle"
                            component="th"
                            scope="row"
                            align="right"
                            width="8%"
                          >
                            {row.rno}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {row.agentname}
                          </TableCell>
                          {/* <TableCell align="left" className="headerstyle">
                            {row.agentextension}
                          </TableCell> */}
                          <TableCell align="left" className="headerstyle">
                            {row.logdate}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {row.starttime} - {row.endtime}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {row.duration}
                          </TableCell>
                          <TableCell
                            align="left"
                            className="headerstyle"
                            sx={
                              row.callstatus.split("¶")[0] === "NO ANSWER"
                                ? "color:red"
                                : "color:green"
                            }
                          >
                            {row.callstatus.split("¶")[0]}
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            {row.callstatus.split("¶")[1] === "Idle"
                              ? [
                                  <a
                                    style={{
                                      color: "green",
                                      fontWeight: "600",
                                    }}
                                  >
                                    Available
                                  </a>,
                                  // <Tooltip title={row.callstatus.split("¶")[1]}>
                                  //   <IconButton
                                  //     color="warning"
                                  //     aria-label="increase"
                                  //     component="label"
                                  //     size="small"
                                  //   >
                                  //     <PhoneDisabledOutlinedIcon
                                  //       sx={{
                                  //         fontSize: 30,
                                  //         width: "0.9em",
                                  //         height: "0.9em",
                                  //       }}
                                  //     />
                                  //   </IconButton>
                                  // </Tooltip>,
                                ]
                              : row.callstatus.split("¶")[1] === "Not logged in"
                              ? [
                                  <a
                                    style={{ color: "red", fontWeight: "600" }}
                                  >
                                    Not Available
                                  </a>,
                                  // <Tooltip title={row.callstatus.split("¶")[1]}>
                                  //   <IconButton
                                  //     color="error"
                                  //     aria-label="increase"
                                  //     component="label"
                                  //     size="small"
                                  //   >
                                  //     <PersonOffOutlinedIcon
                                  //       sx={{
                                  //         fontSize: 30,
                                  //         width: "0.9em",
                                  //         height: "0.9em",
                                  //       }}
                                  //     />
                                  //   </IconButton>
                                  // </Tooltip>,
                                ]
                              : row.callstatus.split("¶")[1] === "Logged out"
                              ? [
                                  <a
                                    style={{ color: "red", fontWeight: "600" }}
                                  >
                                    Not Available
                                  </a>,
                                  // <Tooltip title={row.callstatus.split("¶")[1]}>
                                  //   <IconButton
                                  //     color="error"
                                  //     aria-label="increase"
                                  //     component="label"
                                  //     size="small"
                                  //   >
                                  //     <OutputOutlinedIcon
                                  //       sx={{
                                  //         fontSize: 30,
                                  //         width: "0.9em",
                                  //         height: "0.9em",
                                  //       }}
                                  //     />
                                  //   </IconButton>
                                  // </Tooltip>,
                                ]
                              : [
                                  <a
                                    style={{
                                      color: "green",
                                      fontWeight: "600",
                                    }}
                                  >
                                    Available
                                  </a>,
                                  // <Tooltip title={row.callstatus.split("¶")[1]}>
                                  //   <IconButton
                                  //     color="success"
                                  //     aria-label="increase"
                                  //     component="label"
                                  //     size="small"
                                  //   >
                                  //     <PhoneLockedOutlinedIcon
                                  //       sx={{
                                  //         fontSize: 30,
                                  //         width: "0.9em",
                                  //         height: "0.9em",
                                  //       }}
                                  //     />
                                  //   </IconButton>
                                  // </Tooltip>,
                                ]}
                          </TableCell>
                          <TableCell align="center" className="headerstyle">
                            {row.callstatus.split("¶")[1] === "Logged out" ||
                            row.callstatus.split("¶")[1] === "Not logged in"
                              ? [
                                  <Tooltip title="Logged out">
                                    <IconButton
                                      color="error"
                                      aria-label="increase"
                                      component="label"
                                      size="small"
                                    >
                                      <PersonOffOutlinedIcon
                                        sx={{
                                          fontSize: 30,
                                          width: "0.9em",
                                          height: "0.9em",
                                        }}
                                      />
                                    </IconButton>
                                  </Tooltip>,
                                ]
                              : [
                                  <Tooltip title="Logout">
                                    <IconButton
                                      color="error"
                                      aria-label="increase"
                                      component="label"
                                      size="small"
                                    >
                                      <OutputOutlinedIcon
                                        sx={{
                                          fontSize: 30,
                                          width: "0.9em",
                                          height: "0.9em",
                                        }}
                                        onClick={() => {
                                          handleLogout(row);
                                        }}
                                      />
                                    </IconButton>
                                  </Tooltip>,
                                ]}
                          </TableCell>
                        </TableRow>
                      ))}
                    {totalrow === 0
                      ? [
                          <TableRow>
                            <TableCell
                              className="headerstyle"
                              align="center"
                              colSpan={10}
                            >
                              No Records Found
                            </TableCell>
                          </TableRow>,
                        ]
                      : [""]}
                  </TableBody>
                </Table>
              </TableContainer>
              <Pagination
                handlePageClick={handlePageClick}
                pageCount={pageCount}
              />
            </Box>
          </Tab>
          <Tab eventKey="reports" title="Reports">
            <Tabs
              defaultActiveKey="summary report"
              id="tabs-list"
              className="mt-0 mb-1 report-tabs"
            >
              <Tab eventKey="summary report" title="Summary Report">
                <div className="dashboard-items">
                  <FormLabel htmlFor="disabledTextInput">From date :</FormLabel>
                  <DatePicker
                    placeholder="From date"
                    format="YYYY-MM-DD"
                    calendarPosition="bottom"
                    style={{
                      width: "14.5rem",
                      padding: "10px",
                      height: "40px",
                      fontSize: "15px",
                      fontFamily: "sans-serif",
                    }}
                    value={fromdate}
                    onChange={setFromdate}
                  />
                  <FormLabel htmlFor="disabledTextInput">To date :</FormLabel>
                  <DatePicker
                    placeholder="To date"
                    format="YYYY-MM-DD"
                    calendarPosition="bottom"
                    style={{
                      width: "14.5rem",
                      padding: "10px",
                      height: "40px",
                      fontSize: "15px",
                      fontFamily: "sans-serif",
                    }}
                    value={todate}
                    onChange={setTodate}
                  />
                  <TextField
                    sx={{
                      minWidth: 300,
                    }}
                    select
                    size="small"
                    label="Agent"
                    onChange={(event) => {
                      setAgentid(event.target.value);
                    }}
                    value={agentid}
                  >
                    <MenuItem value="0">All</MenuItem>
                    {agentdata.map((data, i) => (
                      <MenuItem value={data.agentid} key={i}>
                        {data.agentname}
                      </MenuItem>
                    ))}
                  </TextField>
                  <Button
                    sx={{ ml: 1, textTransform: "none" }}
                    variant="outlined"
                    color="primary"
                    startIcon={<SearchIcon />}
                    onClick={() => {
                      handlelistsummary();
                    }}
                  >
                    Search
                  </Button>
                  <Button
                    variant="contained"
                    color="primary"
                    sx={{
                      textTransform: "none",
                    }}
                    onClick={handledownloadSummary}
                  >
                    Download
                  </Button>
                </div>
                <Box
                  sx={{
                    height: "calc(100vh - 260px)",
                    mt: 1,
                  }}
                >
                  <TableContainer
                    component={Paper}
                    sx={{
                      maxHeight: "calc(100vh - 270px)",
                    }}
                  >
                    <Table stickyHeader aria-label="sticky table">
                      <TableHead>
                        <TableRow>
                          <TableCell align="right" className="headerstyle">
                            SNo.
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Agent name
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Agent extension
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Log date
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Total call
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Connected
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Missed
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Total duration
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Average calltime
                          </TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {summaryinfo.map((row, index) => (
                          <TableRow key={index}>
                            <TableCell
                              className="headerstyle"
                              component="th"
                              scope="row"
                              align="right"
                              width="8%"
                            >
                              {index + 1}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.agentname}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.agentextension}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.logdate}
                            </TableCell>
                            <TableCell align="right" className="headerstyle">
                              {parseInt(row.connected) + parseInt(row.missed)}
                            </TableCell>
                            <TableCell align="right" className="headerstyle">
                              {row.connected}
                            </TableCell>
                            <TableCell align="right" className="headerstyle">
                              {row.missed}
                            </TableCell>
                            <TableCell align="right" className="headerstyle">
                              {row.duration}
                            </TableCell>
                            <TableCell align="right" className="headerstyle">
                              {row.avgcalltime}
                            </TableCell>
                          </TableRow>
                        ))}
                        {totalcount === 0
                          ? [
                              <TableRow>
                                <TableCell
                                  className="headerstyle"
                                  align="center"
                                  colSpan={10}
                                >
                                  No Records Found
                                </TableCell>
                              </TableRow>,
                            ]
                          : [""]}
                      </TableBody>
                      <TableRow
                        style={{
                          position: "sticky",
                          bottom: 0,
                          background: "#fff",
                        }}
                      >
                        <TableCell
                          colSpan={4}
                          className="headerstyle"
                        ></TableCell>
                        <TableCell
                          align="right"
                          colSpan={1}
                          className="headerstyle"
                        >
                          <b>Total : {totalCall}</b>
                        </TableCell>
                        <TableCell
                          align="right"
                          colSpan={1}
                          className="headerstyle"
                        >
                          <b>Total : {total}</b>&nbsp;
                          <b style={{ color: "green" }}>
                            ({((total / totalCall) * 100).toFixed(2)}%)
                          </b>
                        </TableCell>
                        <TableCell
                          align="right"
                          colSpan={1}
                          className="headerstyle"
                        >
                          <b>Total : {missedCount}</b>&nbsp;
                          <b style={{ color: "red" }}>
                            ({((missedCount / totalCall) * 100).toFixed(2)}%)
                          </b>
                        </TableCell>
                        <TableCell
                          align="right"
                          className="headerstyle"
                          colSpan={1}
                        >
                          <b>Total : {totalTime}</b>
                        </TableCell>
                        <TableCell
                          align="right"
                          className="headerstyle"
                          colSpan={1}
                        >
                          <b>Total : {totalAvg}</b>
                        </TableCell>
                      </TableRow>
                    </Table>
                  </TableContainer>
                </Box>
              </Tab>
              <Tab eventKey="detailed report" title="Detailed Report">
                <div className="dashboard-items">
                  <FormLabel htmlFor="disabledTextInput">From date</FormLabel>
                  <DatePicker
                    placeholder="From date"
                    format="YYYY-MM-DD"
                    calendarPosition="bottom"
                    style={{
                      width: "14.5rem",
                      padding: "10px",
                      height: "40px",
                      fontSize: "15px",
                      fontFamily: "sans-serif",
                    }}
                    value={fromdate}
                    onChange={setFromdate}
                  />
                  <FormLabel htmlFor="disabledTextInput">To date</FormLabel>
                  <DatePicker
                    placeholder="To date"
                    format="YYYY-MM-DD"
                    calendarPosition="bottom"
                    style={{
                      width: "14.5rem",
                      padding: "10px",
                      height: "40px",
                      fontSize: "15px",
                      fontFamily: "sans-serif",
                    }}
                    value={todate}
                    onChange={setTodate}
                  />
                  <TextField
                    sx={{
                      minWidth: 300,
                    }}
                    select
                    size="small"
                    label="Agent"
                    onChange={(event) => {
                      setAgentid(event.target.value);
                    }}
                    value={agentid}
                  >
                    <MenuItem value="0">All</MenuItem>
                    {agentdata.map((data, i) => (
                      <MenuItem value={data.agentid} key={i}>
                        {data.agentname}
                      </MenuItem>
                    ))}
                  </TextField>
                  <Button
                    sx={{ ml: 1, textTransform: "none" }}
                    variant="outlined"
                    color="primary"
                    startIcon={<SearchIcon />}
                    onClick={() => {
                      handlelistdetailed();
                    }}
                  >
                    Search
                  </Button>
                  <Button
                    variant="contained"
                    color="primary"
                    sx={{
                      textTransform: "none",
                    }}
                    onClick={handledownloadDetailed}
                  >
                    Download
                  </Button>
                </div>
                <Box
                  sx={{
                    height: "calc(100vh - 260px)",
                    mt: 1,
                  }}
                >
                  <TableContainer
                    component={Paper}
                    sx={{
                      maxHeight: "calc(100vh - 280px)",
                    }}
                  >
                    <Table stickyHeader aria-label="sticky table">
                      <TableHead>
                        <TableRow>
                          <TableCell align="right" className="headerstyle">
                            SNo.
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Agent name
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Agent extension
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Log date
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Start time
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            End time
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Duration
                          </TableCell>
                          <TableCell align="left" className="headerstyle">
                            Call status
                          </TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {detailedinfo.map((row) => (
                          <TableRow key={row.sno}>
                            <TableCell
                              className="headerstyle"
                              component="th"
                              scope="row"
                              align="right"
                              width="8%"
                            >
                              {row.rno}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.agentname}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.agentextension}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.logdate}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.starttime}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.endtime}
                            </TableCell>
                            <TableCell align="left" className="headerstyle">
                              {row.duration}
                            </TableCell>
                            <TableCell
                              align="left"
                              className="headerstyle"
                              sx={
                                row.callstatus === "NO ANSWER"
                                  ? "color:red"
                                  : "color:green"
                              }
                            >
                              {row.callstatus}
                            </TableCell>
                          </TableRow>
                        ))}
                        {totalinfo === 0
                          ? [
                              <TableRow>
                                <TableCell
                                  className="headerstyle"
                                  align="center"
                                  colSpan={10}
                                >
                                  No Records Found
                                </TableCell>
                              </TableRow>,
                            ]
                          : [""]}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              </Tab>
            </Tabs>
          </Tab>
        </Tabs>
        <Overlay
          show={show}
          target={target}
          placement="bottom"
          containerPadding={10}
          rootClose
          onHide={() => setShow(false)}
        >
          <Popover className="profile-menu" id="popover-contained">
            <Popover.Body>
              <h5>{state.loginreducer.logininfo.data.resultset[0].username}</h5>
              <p className="email_name">
                {state.loginreducer.logininfo.data.resultset[0].userrole}
              </p>
              <Button
                variant="outlined"
                color="error"
                size="small"
                style={{
                  fontSize: "15px",
                  textTransform: "none",
                }}
                onClick={signouthandler}
              >
                Sign out
              </Button>
            </Popover.Body>
          </Popover>
        </Overlay>
      </div>
      <ToastContainer theme="colored" />
      <Loader loading={openloading} />
    </div>
  );
};
const mapStateToProps = (state) => ({
  state: state,
});
const mapDispatchToProps = (dispatch) => ({
  loadCompany: (data) => dispatch(LoadCompany(data)),
  LoadagentddL: (data) => dispatch(LoadagentDDL(data)),
  loadsummaryreport: (data) => dispatch(loadSummaryreport(data)),
  loaddetailedreport: (data) => dispatch(loadDetailedreport(data)),
  downloadsummaryReport: (data) => dispatch(downloadSummaryReport(data)),
  downloaddetailReport: (data) => dispatch(downloadDetailReport(data)),
  downloadagentstatusReport: (data) =>
    dispatch(downloadAgentstatusReport(data)),
  agentlogout: (data) => dispatch(Agentlogout(data)),
});
export default connect(mapStateToProps, mapDispatchToProps)(Home);
