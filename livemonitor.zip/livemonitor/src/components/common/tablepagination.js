import React from "react";
import ReactPaginate from "react-paginate";
import { Box } from "@mui/material";

const tablepagination = ({ handlePageClick, pageCount }) => {
  return (
    <div>
      {pageCount > 1
        ? [
            <Box
              sx={{
                paddingRight: 2,
                paddingTop: 2,
                paddingBottom: 0.5,
                bottom: 0,
                right: 0,
                position: "fixed",
              }}
            >
              <ReactPaginate
                previousLabel={"<"}
                nextLabel={">"}
                breakLabel={"..."}
                breakClassName={"break-me"}
                pageCount={pageCount}
                marginPagesDisplayed={2}
                pageRangeDisplayed={5}
                onPageChange={handlePageClick}
                containerClassName={"pagination"}
                subContainerClassName={"pages pagination"}
                activeClassName={"active"}
                id="pagination"
                activeLinkClassName={"active-button"}
              />
            </Box>,
          ]
        : []}
    </div>
  );
};

export default tablepagination;
